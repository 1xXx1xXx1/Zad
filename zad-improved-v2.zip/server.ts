/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import dotenv from 'dotenv';
import {
  getPublicConfig,
  updateCredentials,
  removeCredentials,
  testConnection,
  executeAIRequest,
  analyzeIngredientImage,
} from './server/aiProvider.ts';
import {
  searchGlobalRecipes,
  importRecipeFromUrl,
} from './server/recipeService.ts';

dotenv.config();

/* ✅ حماية بسيطة: حد للطلبات على مسارات الذكاء الاصطناعي (20 طلب/دقيقة لكل IP) */
const rateBuckets = new Map<string, { count: number; resetAt: number }>();
function aiRateLimit(req: any, res: Response, next: () => void) {
  const ip = (req.ip || req.socket?.remoteAddress || 'anon') as string;
  const now = Date.now();
  const bucket = rateBuckets.get(ip);
  if (!bucket || bucket.resetAt < now) {
    rateBuckets.set(ip, { count: 1, resetAt: now + 60000 });
    next();
    return;
  }
  bucket.count++;
  if (bucket.count > 20) {
    res.status(429).json({
      success: false,
      message: 'طلبات كتير في دقيقة واحدة — خد نفس شوية وجرب بعد لحظات 🌿',
    });
    return;
  }
  next();
}

setInterval(() => {
  const now = Date.now();
  rateBuckets.forEach((v, k) => {
    if (v.resetAt < now) rateBuckets.delete(k);
  });
}, 120000).unref();

const app = express();
app.use(express.json({ limit: '15mb' }));

// 1. AI Provider Management Endpoints
app.get('/api/ai/config', (req: Request, res: Response) => {
  res.json({ success: true, data: getPublicConfig() });
});

app.post('/api/ai/config', (req: Request, res: Response) => {
  const { provider, apiKey, model, fallbackModel, customEndpoint, isByokActive } = req.body;
  updateCredentials({
    provider,
    apiKey,
    model,
    fallbackModel,
    customEndpoint,
    isByokActive,
  });
  res.json({
    success: true,
    message: 'تم تحديث إعدادات نماذج الذكاء الاصطناعي بنجاح.',
    data: getPublicConfig(),
  });
});

app.delete('/api/ai/credentials', (req: Request, res: Response) => {
  removeCredentials();
  res.json({
    success: true,
    message: 'تم حذف المفتاح الشخصي والعودة للإعدادات الأساسية.',
    data: getPublicConfig(),
  });
});

app.post('/api/ai/test-connection', aiRateLimit, async (req: Request, res: Response) => {
  const { provider, apiKey, model, customEndpoint } = req.body;
  try {
    const result = await testConnection({
      provider,
      apiKey,
      model,
      customEndpoint,
    });
    res.json({ success: result.ok, ...result });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      ok: false,
      latencyMs: 0,
      message: err?.message || 'تعذر استكمال فحص الاتصال.',
    });
  }
});

// 2. "Ask ZAD" & Meal Rescue AI Assistant
app.post('/api/ai/ask', aiRateLimit, async (req: Request, res: Response) => {
  const { query, pantryItems, equipmentMode, budget, language } = req.body;
  const isArabic = language !== 'en';

  const systemInstruction = `أنت "ذاد" (ZAD)، رفيق ذكي وحنون للطعام والطهي والتسوق والميزانية.
شعارك الأساسي: "ذاد — الخير في اللي عندك".
وعدك: "ذاد معك، من أول فكرة لحد آخر لقمة".
قيمك: الكرامة (لا تشعر المستخدم بالحرج أبداً من ضيق ميزانيته أو قلة إمكانياته)، حسن التدبير واستغلال المتاح، اللطف، البساطة، الصدق والوضوح.
تجنب التهويل والمبالغات والتسويق الزائف، واستخدم عبارات دافئة مثل:
- "خلّينا نشوف الموجود عندك."
- "نقدر نعمل حاجة حلوة بالمكونات دي."
- "دي فكرة بسيطة ومناسبة لميزانيتك."
- "خلّينا نستخدم المكونات دي قبل ما تضيع."

وضع المعدات الحالي لدى المستخدم: ${equipmentMode || 'عادي / مطبخ متاح'}.
المكونات المتوفرة في المخزن: ${(pantryItems || []).join(', ') || 'لم يحدد بعد'}.
سقف الميزانية: ${budget || 'غير مقيد'}.

إذا طلب المستخدم وجبة أو فكرة طبخ، قدّم له اقتراحاً عملياً يركز على استغلال الموجود أولاً، مع تحديد الوقت، والتكلفة التقريبية، والخطوات الواضحة.
أجب بصيغة واضحة وودية.`;

  try {
    const result = await executeAIRequest(query, systemInstruction);
    res.json({
      success: true,
      reply: result.text,
      provider: result.provider,
      model: result.model,
      isCuratedFallback: result.isCuratedFallback,
    });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      message: 'نعتذر، تعذر الرد الآن. خلّينا نعتمد على اقتراحات الوصفات المحفوظة.',
      error: err?.message,
    });
  }
});

// 3. Photo-assisted Ingredient Recognition
app.post('/api/ai/scan-ingredients', aiRateLimit, async (req: Request, res: Response) => {
  const { imageBase64, mimeType } = req.body;
  if (!imageBase64) {
    return res.status(400).json({ success: false, message: 'الصورة مطلوبة للتحليل.' });
  }

  try {
    const result = await analyzeIngredientImage(imageBase64, mimeType || 'image/jpeg');
    res.json({ success: true, ...result });
  } catch (err: any) {
    res.status(500).json({
      success: false,
      message: 'تعذر تحليل الصورة، يرجى المحاولة يدوياً.',
      error: err?.message,
    });
  }
});

// 4. Global Recipe Library & External Platforms Integration (TheMealDB & Schema.org)
app.get('/api/recipes/global', async (req: Request, res: Response) => {
  const query = (req.query.q as string) || '';
  const cuisine = (req.query.cuisine as string) || '';
  try {
    const recipes = await searchGlobalRecipes(query, cuisine);
    res.json({ success: true, count: recipes.length, recipes });
  } catch (err: any) {
    res.status(500).json({ success: false, message: 'تعذر جلب الوصفات العالمية.', error: err?.message });
  }
});

app.post('/api/recipes/import-url', async (req: Request, res: Response) => {
  const { url } = req.body;
  if (!url || typeof url !== 'string') {
    return res.status(400).json({ success: false, message: 'الرابط مطلوب لاستيراد الوصفة.' });
  }

  try {
    const recipe = await importRecipeFromUrl(url);
    res.json({ success: true, message: 'تم استيراد الوصفة بنجاح وتجهيزها للتطبيق!', recipe });
  } catch (err: any) {
    res.status(500).json({ success: false, message: err?.message || 'تعذر استيراد الوصفة من هذا الرابط.', error: err?.message });
  }
});

// 5. Vite Dev Middleware & Static Production Serving
async function startServer() {
  const PORT = 3000;
  const isProd = process.env.NODE_ENV === 'production';

  if (isProd) {
    app.use(express.static(path.resolve('dist')));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.resolve('dist/index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[ZAD Server] ذاد يعمل بنجاح على المنفذ: http://0.0.0.0:${PORT}`);
  });
}

startServer();
