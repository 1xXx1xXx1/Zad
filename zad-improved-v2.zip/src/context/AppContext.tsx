/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import {
  Recipe,
  PantryItemData,
  ShoppingItem,
  ExpenseRecord,
  StoreLocation,
  MealPlanDay,
  UserPreferences,
  EquipmentMode,
} from '../types';
import {
  SEED_RECIPES,
  getFreshSeedPantry,
  getFreshSeedExpenses,
  getFreshSeedStores,
} from '../data/seedData';
import { computeMissingIngredients, checkPantryExpiry, currencySymbol } from '../utils/rules';

/* ────────────────────────────────────────────────────────────
 * Storage: مفاتيح مُصدَرة بنسخة (v2) لكسر الكاش القديم بأمان.
 * لو عند المستخدم بيانات أقدم (v1) نستوردها مرة واحدة ثم نحفظ بالنسخة الجديدة.
 * ──────────────────────────────────────────────────────────── */
const STORAGE_VERSION = 'v2';
const KEY = (name: string) => `zad_${STORAGE_VERSION}_${name}`;
const LEGACY_KEY = (name: string) => `zad_${name}`;

function loadJSON<T>(name: string, fallback: T, legacyName?: string): T {
  try {
    const saved = localStorage.getItem(KEY(name));
    if (saved) return JSON.parse(saved) as T;
    // ترقية من النسخة القديمة إن وُجدت
    const legacy = localStorage.getItem(LEGACY_KEY(legacyName || name));
    if (legacy) {
      const parsed = JSON.parse(legacy);
      localStorage.setItem(KEY(name), JSON.stringify(parsed));
      return parsed as T;
    }
  } catch {
    /* تجاهل البيانات التالفة وارجع للافتراضي */
  }
  return fallback;
}

function saveJSON(name: string, value: unknown) {
  try {
    localStorage.setItem(KEY(name), JSON.stringify(value));
  } catch {
    /* التخزين ممتلئ أو محجوب */
  }
}

export interface ZadStats {
  rescuedItems: number; // عدد المكونات التي استُخدمت قبل انتهائها
  savedMoney: number; // تقدير المبلغ الموفَّر (بعملة المستخدم)
  cookedMeals: number; // عدد الوجبات المكتملة عبر وضع الطاهي
  wasteAvoidedKg: number; // تقدير تقريبي للهدر المتجنَّب
}

export type ThemeMode = 'light' | 'dark';

interface AIConfigState {
  provider: 'gemini' | 'openai' | 'custom';
  model: string;
  fallbackModel?: string;
  customEndpoint?: string;
  isByokActive: boolean;
  hasCustomKey: boolean;
  maskedKey?: string;
  lastTestedAt?: string;
  lastStatus?: 'connected' | 'error' | 'unconfigured';
  lastLatencyMs?: number;
  totalRequests: number;
  successfulRequests: number;
}

interface AppContextType {
  language: 'ar' | 'en';
  setLanguage: (lang: 'ar' | 'en') => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;

  // Theme (داكن/فاتح)
  theme: ThemeMode;
  toggleTheme: () => void;

  // Modals & Drawers
  isCookModeOpen: boolean;
  activeCookRecipe: Recipe | null;
  openCookMode: (recipe: Recipe) => void;
  closeCookMode: (completed?: boolean) => void;

  isAISettingsOpen: boolean;
  setIsAISettingsOpen: (open: boolean) => void;

  isStoreMapOpen: boolean;
  setIsStoreMapOpen: (open: boolean) => void;

  isDeliverablesOpen: boolean;
  setIsDeliverablesOpen: (open: boolean) => void;

  // Data
  pantry: PantryItemData[];
  addPantryItem: (item: Omit<PantryItemData, 'id'>) => void;
  updatePantryItem: (id: string, updates: Partial<PantryItemData>) => void;
  deletePantryItem: (id: string) => void;
  markItemUsedUp: (id: string) => void; // ✅ جديد: «استخدمته بالكامل» يحسب في محفظة الإنقاذ

  shoppingList: ShoppingItem[];
  addShoppingItem: (item: Omit<ShoppingItem, 'id' | 'checked'>) => void;
  toggleShoppingItem: (id: string) => void;
  deleteShoppingItem: (id: string) => void;
  clearPurchasedShoppingItems: () => void;
  addRecipeMissingToShoppingList: (recipe: Recipe) => number;
  estimateShoppingTotal: number; // ✅ جديد: تكلفة تقديرية للقائمة

  recipes: Recipe[];
  addRecipe: (recipe: Recipe) => void;
  toggleFavoriteRecipe: (id: string) => void;
  rateRecipe: (id: string, rating: number) => void;

  expenses: ExpenseRecord[];
  addExpense: (expense: Omit<ExpenseRecord, 'id'>) => void;
  deleteExpense: (id: string) => void;
  sumExpensesInPeriod: (period: 'daily' | 'weekly' | 'monthly') => number; // ✅ إصلاح فلترة الفترة

  stores: StoreLocation[];
  mealPlan: MealPlanDay[];
  generateMealPlan: (daysCount: number) => void; // ✅ خطة متجددة فعلاً

  userPreferences: UserPreferences;
  updatePreferences: (updates: Partial<UserPreferences>) => void;

  // ✅ جديد: إحصائيات التوفير ومحاربة الهدر
  stats: ZadStats;
  recordCookedMeal: () => void;

  // AI & Server
  aiConfig: AIConfigState | null;
  refreshAIConfig: () => Promise<void>;
  testConnection: (params: {
    provider: 'gemini' | 'openai' | 'custom';
    apiKey?: string;
    model: string;
    customEndpoint?: string;
  }) => Promise<{ ok: boolean; message: string; latencyMs: number }>;
  saveAIConfig: (params: {
    provider: 'gemini' | 'openai' | 'custom';
    apiKey?: string;
    model: string;
    fallbackModel?: string;
    customEndpoint?: string;
    isByokActive: boolean;
  }) => Promise<{ ok: boolean; message: string }>;
  removeAICredentials: () => Promise<void>;
  askZadAssistant: (query: string) => Promise<{ reply: string; provider: string; model: string; isCuratedFallback: boolean }>;
  scanIngredientsPhoto: (base64: string, mime?: string) => Promise<{ ingredients: string[]; notes: string; source: string }>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const todayISO = () => {
  const d = new Date();
  const y = d.getFullYear();
  const m = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${y}-${m}-${day}`;
};

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguageState] = useState<'ar' | 'en'>(() => {
    return (localStorage.getItem('zad_lang') as 'ar' | 'en') || 'ar';
  });

  const [activeTab, setActiveTab] = useState<string>('home');

  // ✅ الثيم: فاتح/داكن مع حفظ الاختيار
  const [theme, setTheme] = useState<ThemeMode>(() => {
    return (localStorage.getItem(KEY('theme')) as ThemeMode) || 'light';
  });

  const [isCookModeOpen, setIsCookModeOpen] = useState(false);
  const [activeCookRecipe, setActiveCookRecipe] = useState<Recipe | null>(null);
  const [isAISettingsOpen, setIsAISettingsOpen] = useState(false);
  const [isStoreMapOpen, setIsStoreMapOpen] = useState(false);
  const [isDeliverablesOpen, setIsDeliverablesOpen] = useState(false);

  // Core Data
  const [pantry, setPantry] = useState<PantryItemData[]>(() =>
    loadJSON<PantryItemData[]>('pantry', getFreshSeedPantry())
  );

  const [shoppingList, setShoppingList] = useState<ShoppingItem[]>(() =>
    loadJSON<ShoppingItem[]>('shopping', [
      { id: 's1', name: 'خبز بلدي', quantity: 5, unit: 'رغيف', category: 'مخبوزات', checked: false, estimatedPrice: 10 },
      { id: 's2', name: 'خيار طازج', quantity: 500, unit: 'جرام', category: 'خضروات', checked: false, estimatedPrice: 10 },
      { id: 's3', name: 'ليمون', quantity: 3, unit: 'حبة', category: 'خضروات', checked: false, estimatedPrice: 5 },
    ])
  );

  const [recipes, setRecipes] = useState<Recipe[]>(() => {
    // ✅ إصلاح: الوصفات المحفوظة قديماً كانت تمنع ظهور وصفات جديدة في التحديثات.
    // ندمج: المحفوظات + أي وصفات أساسية جديدة غير موجودة بعد.
    const saved = loadJSON<Recipe[] | null>('recipes', null);
    if (!saved || !Array.isArray(saved) || saved.length === 0) return SEED_RECIPES;
    const savedIds = new Set(saved.map((r) => r.id));
    const missingSeeds = SEED_RECIPES.filter((r) => !savedIds.has(r.id));
    return [...missingSeeds, ...saved];
  });

  const [expenses, setExpenses] = useState<ExpenseRecord[]>(() =>
    loadJSON<ExpenseRecord[]>('expenses', getFreshSeedExpenses())
  );

  const [stores] = useState<StoreLocation[]>(getFreshSeedStores());

  const [stats, setStats] = useState<ZadStats>(() =>
    loadJSON<ZadStats>('stats', { rescuedItems: 0, savedMoney: 0, cookedMeals: 0, wasteAvoidedKg: 0 })
  );

  const [userPreferences, setUserPreferences] = useState<UserPreferences>(() => {
    const saved = loadJSON<UserPreferences | null>('preferences', null);
    if (saved) return saved;
    return {
      household: 'solo',
      equipment: 'limited_equipment',
      dietaryRestrictions: [],
      preferredCuisines: ['مصري', 'شامي', 'سريع وخفيف'],
      maxPrepTime: 25,
      currency: 'EGP',
      budgetDaily: 80,
      budgetWeekly: 500,
      budgetMonthly: 2000,
    };
  });

  /* ── خطة الوجبات: تُبنى ديناميكياً حول تاريخ اليوم (إصلاح التواريخ الثابتة) ── */
  const buildInitialMealPlan = (): MealPlanDay[] => buildMealPlan(3, SEED_RECIPES);

  const [mealPlan, setMealPlan] = useState<MealPlanDay[]>(() => {
    const saved = loadJSON<MealPlanDay[] | null>('mealplan', null);
    // لو الخطة المحفوظة لا تغطي اليوم الحالي → نعيد التوليد تلقائياً
    if (saved && saved.length > 0) {
      const today = todayISO();
      const coversToday = saved.some((d) => d.date === today);
      if (coversToday) return saved;
    }
    return buildInitialMealPlan();
  });

  const [aiConfig, setAiConfig] = useState<AIConfigState | null>(null);

  // Sync to localStorage
  useEffect(() => saveJSON('pantry', pantry), [pantry]);
  useEffect(() => saveJSON('shopping', shoppingList), [shoppingList]);
  useEffect(() => saveJSON('recipes', recipes), [recipes]);
  useEffect(() => saveJSON('expenses', expenses), [expenses]);
  useEffect(() => saveJSON('preferences', userPreferences), [userPreferences]);
  useEffect(() => saveJSON('stats', stats), [stats]);
  useEffect(() => saveJSON('mealplan', mealPlan), [mealPlan]);

  // ✅ الثيم يُطبق على <html> ككلاس (والمتغيرات CSS تتكفل بالباقي)
  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    localStorage.setItem(KEY('theme'), theme);
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', theme === 'dark' ? '#16130E' : '#FAF7F2');
  }, [theme]);

  const toggleTheme = () => setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));

  const setLanguage = (lang: 'ar' | 'en') => {
    setLanguageState(lang);
    localStorage.setItem('zad_lang', lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === 'ar' ? 'rtl' : 'ltr';
  };

  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  const refreshAIConfig = async () => {
    try {
      const res = await fetch('/api/ai/config');
      const json = await res.json();
      if (json.success && json.data) setAiConfig(json.data);
    } catch (e) {
      console.warn('Failed to fetch AI configuration from server', e);
    }
  };

  useEffect(() => {
    refreshAIConfig();
  }, []);

  const openCookMode = (recipe: Recipe) => {
    setActiveCookRecipe(recipe);
    setIsCookModeOpen(true);
  };

  // ✅ closeCookMode الآن يستقبل completed ليحصي الوجبة المطبوخة
  const closeCookMode = (completed = false) => {
    setIsCookModeOpen(false);
    setActiveCookRecipe(null);
    if (completed) {
      setStats((prev) => ({ ...prev, cookedMeals: prev.cookedMeals + 1 }));
    }
  };

  const recordCookedMeal = () => setStats((prev) => ({ ...prev, cookedMeals: prev.cookedMeals + 1 }));

  /* ─────────── Pantry handlers ─────────── */

  const addPantryItem = (item: Omit<PantryItemData, 'id'>) => {
    const newItem: PantryItemData = { ...item, id: 'p_' + Date.now() + Math.random().toString(36).slice(2, 6) };
    setPantry((prev) => [newItem, ...prev]);
  };

  const updatePantryItem = (id: string, updates: Partial<PantryItemData>) => {
    setPantry((prev) =>
      prev.map((item) => {
        if (item.id !== id) return item;
        const updated = { ...item, ...updates };
        // ✅ التخزين وصل صفراً وهو قرب الانتهاء؟ نحسبه «إنقاذاً» في محفظة التوفير
        if (updates.quantity !== undefined && updates.quantity <= 0 && item.quantity > 0) {
          const { status } = checkPantryExpiry(item.expiryDate);
          if (status === 'expiring_soon') {
            setTimeout(() => {
              setStats((s) => ({
                ...s,
                rescuedItems: s.rescuedItems + 1,
                savedMoney: s.savedMoney + (item.purchasePrice || 0),
                wasteAvoidedKg: Math.round((s.wasteAvoidedKg + 0.3) * 10) / 10,
              }));
            }, 0);
          }
        }
        return updated;
      })
    );
  };

  const markItemUsedUp = (id: string) => {
    setPantry((prev) =>
      prev.filter((item) => {
        if (item.id !== id) return true;
        const { status } = checkPantryExpiry(item.expiryDate);
        if (status !== 'expired') {
          setStats((s) => ({
            ...s,
            rescuedItems: s.rescuedItems + 1,
            savedMoney: s.savedMoney + (item.purchasePrice || 0),
            wasteAvoidedKg: Math.round((s.wasteAvoidedKg + 0.3) * 10) / 10,
          }));
        }
        return false; // أُكِل → يخرج من المخزن
      })
    );
  };

  const deletePantryItem = (id: string) => {
    setPantry((prev) => prev.filter((item) => item.id !== id));
  };

  /* ─────────── Shopping list handlers ─────────── */

  const addShoppingItem = (item: Omit<ShoppingItem, 'id' | 'checked'>) => {
    const newItem: ShoppingItem = {
      ...item,
      id: 'sh_' + Date.now() + Math.random().toString(36).slice(2, 6),
      checked: false,
    };
    setShoppingList((prev) => [newItem, ...prev]);
  };

  const toggleShoppingItem = (id: string) => {
    setShoppingList((prev) => prev.map((item) => (item.id === id ? { ...item, checked: !item.checked } : item)));
  };

  const deleteShoppingItem = (id: string) => {
    setShoppingList((prev) => prev.filter((item) => item.id !== id));
  };

  const clearPurchasedShoppingItems = () => {
    setShoppingList((prev) => prev.filter((item) => !item.checked));
  };

  const addRecipeMissingToShoppingList = (recipe: Recipe): number => {
    const pantryNames = pantry.map((p) => p.name);
    const recipeIngNames = recipe.ingredients.map((i) => i.name);
    const { missing } = computeMissingIngredients(recipeIngNames, pantryNames);
    if (missing.length === 0) return 0;

    let addedCount = 0;
    const newItems: ShoppingItem[] = [];

    for (const missingName of missing) {
      const ing = recipe.ingredients.find((i) => i.name === missingName);
      const alreadyInList = shoppingList.some((s) => s.name === missingName && !s.checked);
      if (!alreadyInList) {
        newItems.push({
          id: 'sh_' + Math.random().toString(36).substring(2, 9),
          name: missingName,
          quantity: ing ? ing.quantity : 1,
          unit: ing ? ing.unit : 'حبة',
          category: 'مكونات وصفة',
          checked: false,
          recipeSource: recipe.title,
        });
        addedCount++;
      }
    }

    if (newItems.length > 0) setShoppingList((prev) => [...newItems, ...prev]);
    return addedCount;
  };

  const estimateShoppingTotal = shoppingList
    .filter((i) => !i.checked)
    .reduce((sum, i) => sum + (i.estimatedPrice || 0), 0);

  /* ─────────── Recipes ─────────── */

  const addRecipe = (recipe: Recipe) => {
    setRecipes((prev) => {
      const exists = prev.some((r) => r.id === recipe.id);
      return exists ? prev.map((r) => (r.id === recipe.id ? recipe : r)) : [recipe, ...prev];
    });
  };

  const toggleFavoriteRecipe = (id: string) => {
    setRecipes((prev) => prev.map((r) => (r.id === id ? { ...r, isFavorite: !r.isFavorite } : r)));
  };

  const rateRecipe = (id: string, rating: number) => {
    setRecipes((prev) => prev.map((r) => (r.id === id ? { ...r, userRating: rating } : r)));
  };

  /* ─────────── Expenses ─────────── */

  const addExpense = (expense: Omit<ExpenseRecord, 'id'>) => {
    const newExp: ExpenseRecord = { ...expense, id: 'e_' + Date.now() + Math.random().toString(36).slice(2, 6) };
    setExpenses((prev) => [newExp, ...prev]);
  };

  const deleteExpense = (id: string) => {
    setExpenses((prev) => prev.filter((e) => e.id !== id));
  };

  /**
   * ✅ إصلاح جوهري: كانت الميزانية تُحسب من كل المصروفات مهما كانت الفترة.
   * الآن نفلتر فعلياً حسب اليوم/الأسبوع/الشهر المنقضي.
   */
  const sumExpensesInPeriod = (period: 'daily' | 'weekly' | 'monthly') => {
    const now = new Date();
    now.setHours(23, 59, 59, 999);
    const days = period === 'daily' ? 1 : period === 'weekly' ? 7 : 30;
    const cutoff = new Date(now.getTime() - days * 86400000);
    cutoff.setHours(0, 0, 0, 0);

    return expenses
      .filter((e) => {
        const d = new Date(e.date + 'T00:00:00');
        return d >= cutoff && d <= now;
      })
      .reduce((sum, e) => sum + e.amount, 0);
  };

  const updatePreferences = (updates: Partial<UserPreferences>) => {
    setUserPreferences((prev) => ({ ...prev, ...updates }));
  };

  /* ─────────── Meal Plan (خطة متنوعة فعلاً) ─────────── */

  function buildMealPlan(daysCount: number, pool: Recipe[]): MealPlanDay[] {
    const days: MealPlanDay[] = [];
    const dayNamesAr = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
    const dayNamesEn = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    const byCategory = (cat: string) => pool.filter((r) => r.category === cat);
    const breakfasts = byCategory('breakfast');
    const lunches = byCategory('lunch');
    const dinners = byCategory('dinner');
    const snacks = pool.filter((r) => r.category === 'drink' || r.category === 'dessert' || r.category === 'snack');

    const pick = (arr: Recipe[], i: number, fb: Recipe[]) =>
      arr.length > 0 ? arr[i % arr.length] : fb[i % Math.max(1, fb.length)] || pool[0];

    // مزاحمة مختلفة لكل فئة حتى تتنوع الأيام ولا تتكرر نفس الوجبة يومياً
    for (let i = 0; i < daysCount; i++) {
      const d = new Date();
      d.setDate(d.getDate() + i);
      const iso = todayISOof(d);
      const dayIndex = d.getDay();

      days.push({
        date: iso,
        dayName: i === 0 ? 'اليوم' : i === 1 ? 'غداً' : dayNamesAr[dayIndex],
        dayNameEn: i === 0 ? 'Today' : i === 1 ? 'Tomorrow' : dayNamesEn[dayIndex],
        breakfast: pick(breakfasts, i, pool),
        lunch: pick(lunches, i * 2 + 1, pool),
        dinner: pick(dinners, i * 3 + 2, pool),
        snack: pick(snacks, i, pool),
      });
    }
    return days;
  }

  function todayISOof(d: Date) {
    const y = d.getFullYear();
    const m = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${y}-${m}-${day}`;
  }

  const generateMealPlan = (daysCount: number = 3) => {
    setMealPlan(buildMealPlan(daysCount, recipes));
  };

  /* ─────────── AI Actions ─────────── */

  const testConnection = async (params: {
    provider: 'gemini' | 'openai' | 'custom';
    apiKey?: string;
    model: string;
    customEndpoint?: string;
  }) => {
    const res = await fetch('/api/ai/test-connection', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    const data = await res.json();
    await refreshAIConfig();
    return { ok: Boolean(data.ok), message: data.message || '', latencyMs: data.latencyMs || 0 };
  };

  const saveAIConfig = async (params: {
    provider: 'gemini' | 'openai' | 'custom';
    apiKey?: string;
    model: string;
    fallbackModel?: string;
    customEndpoint?: string;
    isByokActive: boolean;
  }) => {
    const res = await fetch('/api/ai/config', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(params),
    });
    const data = await res.json();
    await refreshAIConfig();
    return { ok: Boolean(data.success), message: data.message || '' };
  };

  const removeAICredentials = async () => {
    await fetch('/api/ai/credentials', { method: 'DELETE' });
    await refreshAIConfig();
  };

  const askZadAssistant = async (query: string) => {
    const res = await fetch('/api/ai/ask', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query,
        pantryItems: pantry.map((p) => p.name),
        equipmentMode: userPreferences.equipment,
        budget: `${userPreferences.budgetDaily} ${currencySymbol(userPreferences.currency)}`,
        language,
      }),
    });
    const data = await res.json();
    return {
      reply: data.reply || '',
      provider: data.provider || 'ذاد',
      model: data.model || '',
      isCuratedFallback: Boolean(data.isCuratedFallback),
    };
  };

  const scanIngredientsPhoto = async (base64: string, mime?: string) => {
    const res = await fetch('/api/ai/scan-ingredients', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ imageBase64: base64, mimeType: mime }),
    });
    const data = await res.json();
    return {
      ingredients: data.ingredients || [],
      notes: data.notes || '',
      source: data.source || '',
    };
  };

  return (
    <AppContext.Provider
      value={{
        language,
        setLanguage,
        activeTab,
        setActiveTab,
        theme,
        toggleTheme,
        isCookModeOpen,
        activeCookRecipe,
        openCookMode,
        closeCookMode,
        isAISettingsOpen,
        setIsAISettingsOpen,
        isStoreMapOpen,
        setIsStoreMapOpen,
        isDeliverablesOpen,
        setIsDeliverablesOpen,
        pantry,
        addPantryItem,
        updatePantryItem,
        deletePantryItem,
        markItemUsedUp,
        shoppingList,
        addShoppingItem,
        toggleShoppingItem,
        deleteShoppingItem,
        clearPurchasedShoppingItems,
        addRecipeMissingToShoppingList,
        estimateShoppingTotal,
        recipes,
        addRecipe,
        toggleFavoriteRecipe,
        rateRecipe,
        expenses,
        addExpense,
        deleteExpense,
        sumExpensesInPeriod,
        stores,
        mealPlan,
        generateMealPlan,
        userPreferences,
        updatePreferences,
        stats,
        recordCookedMeal,
        aiConfig,
        refreshAIConfig,
        testConnection,
        saveAIConfig,
        removeAICredentials,
        askZadAssistant,
        scanIngredientsPhoto,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
