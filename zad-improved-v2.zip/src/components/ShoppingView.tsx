/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  ShoppingBag,
  Plus,
  Trash2,
  CheckCircle2,
  Circle,
  Share2,
  Layers,
  Maximize2,
  Minimize2,
  MapPin,
  Wallet,
  Sparkles,
} from 'lucide-react';
import { ShoppingItem } from '../types';
import { currencySymbol } from '../utils/rules';

export const ShoppingView: React.FC = () => {
  const {
    language,
    shoppingList,
    addShoppingItem,
    toggleShoppingItem,
    deleteShoppingItem,
    clearPurchasedShoppingItems,
    userPreferences,
    setIsStoreMapOpen,
    estimateShoppingTotal,
    pantry,
  } = useApp();

  const isAr = language === 'ar';

  const [newItemName, setNewItemName] = useState('');
  const [newItemQty, setNewItemQty] = useState(1);
  const [newItemUnit, setNewItemUnit] = useState('كجم');
  const [newItemCat, setNewItemCat] = useState('خضروات وفاكهة');
  const [isInStoreMode, setIsInStoreMode] = useState(false);
  const [shareSuccess, setShareSuccess] = useState(false);

  const handleAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newItemName.trim()) return;

    addShoppingItem({
      name: newItemName.trim(),
      quantity: Number(newItemQty) || 1,
      unit: newItemUnit,
      category: newItemCat,
    });

    setNewItemName('');
  };

  const handleShareList = async () => {
    const textToShare =
      `🛒 ${isAr ? 'قائمة تسوق ذاد' : 'ZAD Shopping List'}:\n` +
      shoppingList
        .map((item) => `${item.checked ? '✓' : '•'} ${item.name} (${item.quantity} ${item.unit})`)
        .join('\n') +
      `\n\n${isAr ? 'ذاد — الخير في اللي عندك' : 'ZAD — Goodness in what you have'}`;

    if (navigator.share) {
      try {
        await navigator.share({ title: isAr ? 'قائمة تسوق ذاد' : 'ZAD list', text: textToShare });
        return;
      } catch {
        /* fallback to clipboard */
      }
    }

    try {
      await navigator.clipboard.writeText(textToShare);
      setShareSuccess(true);
      setTimeout(() => setShareSuccess(false), 2500);
    } catch {
      /* clipboard unavailable */
    }
  };

  /* ✅ اقتراح ذكي: عناصر في قائمة التسوق موجودة فعلاً في المخزن */
  const normalize = (s: string) => s.toLowerCase().replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').trim();
  const pantryNormal = pantry.map((p) => normalize(p.name));
  const duplicatesWithPantry = shoppingList.filter(
    (i) => !i.checked && pantryNormal.some((pn) => pn.includes(normalize(i.name)) || normalize(i.name).includes(pn))
  );

  const groupedCategories: { [cat: string]: ShoppingItem[] } = {};
  shoppingList.forEach((item) => {
    const cat = item.category || (isAr ? 'عام' : 'General');
    if (!groupedCategories[cat]) groupedCategories[cat] = [];
    groupedCategories[cat].push(item);
  });

  const unpurchasedCount = shoppingList.filter((i) => !i.checked).length;
  const purchasedCount = shoppingList.length - unpurchasedCount;
  const progressPercent = shoppingList.length > 0 ? Math.round((purchasedCount / shoppingList.length) * 100) : 0;

  return (
    <div
      className={`space-y-5 pb-24 pt-1 animate-fade-in ${
        isInStoreMode ? 'rounded-3xl border-2 border-[var(--brand)] bg-[var(--surface)] p-4' : ''
      }`}
    >
      {/* الهيدر */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-[var(--brand-ink)] tracking-tight flex items-center gap-2 flex-wrap">
            <ShoppingBag className="w-5 h-5" />
            <span>{isAr ? 'قائمة التسوق الذكية' : 'Smart Shopping List'}</span>
            {isInStoreMode && (
              <span className="text-[10px] bg-[var(--accent)] text-white px-2 py-0.5 rounded-lg border-2 border-[var(--line-strong)] font-black">
                {isAr ? 'وضع المتجر' : 'In-Store'}
              </span>
            )}
          </h2>
          <p className="text-xs text-[var(--muted)] font-semibold">
            {unpurchasedCount > 0
              ? isAr
                ? `متبقي ${unpurchasedCount} (${purchasedCount} اشتريت) — تقدير التكلفة: ${estimateShoppingTotal} ${currencySymbol(userPreferences.currency)}`
                : `${unpurchasedCount} left — est. total: ${estimateShoppingTotal} ${currencySymbol(userPreferences.currency)}`
              : isAr
              ? 'أحسنت! اكتملت القائمة كلها 🎉'
              : 'All purchased! 🎉'}
          </p>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={() => setIsStoreMapOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-2 rounded-xl bg-[var(--brand-soft)] text-[var(--brand-ink)] border-2 border-[var(--line-strong)] text-xs font-extrabold"
            title={isAr ? 'مقارنة سعر السلة' : 'Compare basket prices'}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isAr ? 'مقارنة المتاجر' : 'Compare'}</span>
          </button>

          <button
            onClick={handleShareList}
            className="p-2 rounded-xl bg-[var(--surface)] border-2 border-[var(--line-strong)] text-[var(--muted)] hover:text-[var(--brand-ink)] transition-colors"
            aria-label={isAr ? 'مشاركة القائمة' : 'Share list'}
          >
            <Share2 className="w-4 h-4" />
          </button>

          <button
            onClick={() => setIsInStoreMode(!isInStoreMode)}
            className={`flex items-center gap-1 px-3 py-2 rounded-xl text-xs font-extrabold border-2 border-[var(--line-strong)] transition-all ${
              isInStoreMode ? 'bg-[var(--brand)] text-white' : 'bg-[var(--surface)] text-[var(--brand-ink)]'
            }`}
          >
            {isInStoreMode ? <Minimize2 className="w-3.5 h-3.5" /> : <Maximize2 className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{isInStoreMode ? (isAr ? 'عادي' : 'Normal') : isAr ? 'وضع المتجر' : 'Store mode'}</span>
          </button>
        </div>
      </div>

      {/* شريط التقدم */}
      {shoppingList.length > 0 && (
        <div className="flex items-center gap-3">
          <div className="flex-1 h-3 rounded-full bg-[var(--surface-2)] border-2 border-[var(--line-strong)] overflow-hidden">
            <div
              className="h-full rounded-full bg-[var(--brand)] transition-all duration-500"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <span className="text-xs font-black text-[var(--brand-ink)] w-10">{progressPercent}%</span>
        </div>
      )}

      {shareSuccess && (
        <div className="p-2.5 rounded-xl bg-[var(--brand-soft)] border-2 border-[var(--brand-line)] text-[var(--brand-ink)] text-xs font-extrabold text-center">
          {isAr ? 'تم نسخ القائمة!' : 'List copied!'}
        </div>
      )}

      {/* ✅ تنبيه ذكي: عنصر في القائمة موجود أصلاً في المخزن */}
      {duplicatesWithPantry.length > 0 && (
        <div className="rounded-2xl border-2 border-[var(--brand-line)] bg-[var(--brand-soft)] p-3 flex items-start gap-2 animate-pop">
          <Sparkles className="w-4 h-4 text-[var(--brand-ink)] flex-shrink-0 mt-0.5" />
          <p className="text-[11px] font-extrabold text-[var(--brand-ink)] leading-relaxed">
            {isAr
              ? `ذاد لاحظ: «${duplicatesWithPantry.map((d) => d.name).join('، ')}» موجودة عندك في المخزن أصلاً — راجع قبل ما تشتري وتوفر فلوسك!`
              : `Heads up: "${duplicatesWithPantry.map((d) => d.name).join(', ')}" already in your pantry — check before buying!`}
          </p>
        </div>
      )}

      {/* إضافة عنصر */}
      {!isInStoreMode && (
        <form
          onSubmit={handleAddItem}
          className="rounded-3xl border-2 border-[var(--line-strong)] bg-[var(--surface)] p-3 space-y-2 shadow-[3px_3px_0_0_var(--shadow-card)]"
        >
          <div className="flex gap-2">
            <input
              type="text"
              required
              value={newItemName}
              onChange={(e) => setNewItemName(e.target.value)}
              placeholder={isAr ? 'أضف غرضاً (مثال: لبن، جبن، ليمون...)' : 'Add new item...'}
              className="flex-1 text-xs sm:text-sm bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-xl px-3 py-2 text-[var(--ink)] font-medium"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-xl bg-[var(--brand)] text-white text-xs font-extrabold border-2 border-[var(--line-strong)] flex items-center gap-1"
            >
              <Plus className="w-4 h-4" />
              <span>{isAr ? 'إضافة' : 'Add'}</span>
            </button>
          </div>

          <div className="flex items-center gap-2 pt-1 text-xs">
            <input
              type="number"
              min="0.1"
              step="any"
              value={newItemQty}
              onChange={(e) => setNewItemQty(parseFloat(e.target.value) || 1)}
              className="w-16 bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-lg px-2 py-1.5 text-center text-xs font-bold text-[var(--ink)]"
            />
            <select
              value={newItemUnit}
              onChange={(e) => setNewItemUnit(e.target.value)}
              className="bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-lg px-2 py-1.5 text-xs font-bold text-[var(--ink)]"
            >
              <option value="حبة">{isAr ? 'حبة' : 'pc'}</option>
              <option value="كجم">{isAr ? 'كجم' : 'kg'}</option>
              <option value="جرام">{isAr ? 'جرام' : 'g'}</option>
              <option value="علبة">{isAr ? 'علبة' : 'pack'}</option>
              <option value="لتر">{isAr ? 'لتر' : 'L'}</option>
            </select>
            <select
              value={newItemCat}
              onChange={(e) => setNewItemCat(e.target.value)}
              className="flex-1 bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-lg px-2 py-1.5 text-xs font-bold text-[var(--ink)]"
            >
              <option value="خضروات وفاكهة">{isAr ? 'خضروات وفاكهة' : 'Produce'}</option>
              <option value="ألبان وبيض">{isAr ? 'ألبان وبيض' : 'Dairy & Eggs'}</option>
              <option value="مخبوزات">{isAr ? 'مخبوزات' : 'Bakery'}</option>
              <option value="بقوليات وحبوب">{isAr ? 'بقوليات وحبوب' : 'Grains'}</option>
              <option value="لحوم ودواجن">{isAr ? 'لحوم ودواجن' : 'Meat & Poultry'}</option>
            </select>
          </div>
        </form>
      )}

      {/* العناصر */}
      <div className="space-y-4">
        {Object.keys(groupedCategories).length > 0 ? (
          Object.keys(groupedCategories).map((categoryName) => (
            <div key={categoryName} className="space-y-2">
              <h3 className="text-xs font-black text-[var(--muted)] px-1 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5 text-[var(--brand-ink)]" />
                <span>{categoryName}</span>
              </h3>

              <div className="rounded-2xl border-2 border-[var(--line-strong)] bg-[var(--surface)] divide-y-2 divide-[var(--line)] shadow-[3px_3px_0_0_var(--shadow-card)] overflow-hidden">
                {groupedCategories[categoryName].map((item) => (
                  <div
                    key={item.id}
                    onClick={() => toggleShoppingItem(item.id)}
                    className={`flex items-center justify-between p-3.5 transition-colors cursor-pointer hover:bg-[var(--surface-2)] ${
                      item.checked ? 'opacity-55' : ''
                    } ${isInStoreMode ? 'py-4 sm:py-5' : ''}`}
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleShoppingItem(item.id);
                        }}
                        aria-label={isAr ? `تحديد ${item.name}` : `Check ${item.name}`}
                      >
                        {item.checked ? (
                          <CheckCircle2 className={`text-[var(--brand)] ${isInStoreMode ? 'w-7 h-7' : 'w-5 h-5'}`} />
                        ) : (
                          <Circle className={`text-[var(--line)] ${isInStoreMode ? 'w-7 h-7' : 'w-5 h-5'}`} />
                        )}
                      </button>

                      <div className="flex flex-col min-w-0">
                        <span
                          className={`font-extrabold ${isInStoreMode ? 'text-base sm:text-lg' : 'text-xs sm:text-sm'} ${
                            item.checked ? 'line-through text-[var(--faint)]' : 'text-[var(--ink)]'
                          }`}
                        >
                          {item.name}
                        </span>
                        {item.recipeSource && (
                          <span className="text-[10px] text-[var(--faint)] font-bold truncate">
                            {isAr ? 'من وصفة:' : 'From:'} {item.recipeSource}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2.5 flex-shrink-0">
                      <span className={`font-black text-[var(--brand-ink)] ${isInStoreMode ? 'text-base' : 'text-xs'}`}>
                        {item.quantity} {item.unit}
                      </span>
                      {!isInStoreMode && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteShoppingItem(item.id);
                          }}
                          className="text-[var(--faint)] hover:text-[var(--danger-ink)] p-1 transition-colors"
                          aria-label={isAr ? `حذف ${item.name}` : `Delete ${item.name}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-12 rounded-3xl border-2 border-[var(--line-strong)] bg-[var(--surface)] p-6 space-y-2 shadow-[4px_4px_0_0_var(--shadow-card)]">
            <ShoppingBag className="w-10 h-10 text-[var(--faint)] mx-auto opacity-50" />
            <h3 className="font-black text-sm text-[var(--ink)]">
              {isAr ? 'القائمة فاضية تماماً' : 'Your list is empty'}
            </h3>
            <p className="text-xs text-[var(--muted)] font-semibold">
              {isAr
                ? 'تصفح الوصفات واضغط «أضف النواقص»، أو أضف الأغراض يدوياً فوق.'
                : 'Browse recipes and tap "Add missing" or add items above.'}
            </p>
          </div>
        )}
      </div>

      {/* مسح المشتريات */}
      {purchasedCount > 0 && (
        <div className="pt-1 text-center">
          <button
            onClick={clearPurchasedShoppingItems}
            className="text-xs font-extrabold text-[var(--muted)] hover:text-[var(--danger-ink)] hover:underline inline-flex items-center gap-1.5"
          >
            <Trash2 className="w-3.5 h-3.5" />
            {isAr ? `امسح المشتريات (${purchasedCount})` : `Clear purchased (${purchasedCount})`}
          </button>
        </div>
      )}

      {/* تلميح الميزانية */}
      {estimateShoppingTotal > 0 && (
        <div className="rounded-2xl border-2 border-[var(--line)] bg-[var(--surface-2)] p-3 flex items-center gap-2">
          <Wallet className="w-4 h-4 text-[var(--brand-ink)] flex-shrink-0" />
          <p className="text-[11px] font-extrabold text-[var(--muted)]">
            {isAr
              ? `التكلفة التقديرية للنواقص: ~${estimateShoppingTotal} ${currencySymbol(userPreferences.currency)} — قارن الأسعار من «مقارنة المتاجر» قبل الشراء.`
              : `Estimated total: ~${estimateShoppingTotal} ${currencySymbol(userPreferences.currency)} — compare stores before buying.`}
          </p>
        </div>
      )}
    </div>
  );
};
