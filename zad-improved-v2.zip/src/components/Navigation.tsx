/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { motion } from 'motion/react';
import { useApp } from '../context/AppContext';
import { Home, BookOpen, Sparkles, ShoppingBag, PieChart } from 'lucide-react';

export const Navigation: React.FC = () => {
  const { activeTab, setActiveTab, language, shoppingList } = useApp();
  const isAr = language === 'ar';

  const unpurchasedCount = shoppingList.filter((i) => !i.checked).length;

  const tabs = [
    { id: 'home', label: isAr ? 'الرئيسية' : 'Home', icon: Home },
    { id: 'recipes', label: isAr ? 'الوصفات' : 'Recipes', icon: BookOpen },
    { id: 'ask_zad', label: isAr ? 'اسأل ذاد' : 'Ask ZAD', icon: Sparkles, isPrimary: true },
    { id: 'shopping', label: isAr ? 'التسوق' : 'Shop', icon: ShoppingBag, badge: unpurchasedCount > 0 ? unpurchasedCount : undefined },
    { id: 'budget', label: isAr ? 'الميزانية' : 'Budget', icon: PieChart },
  ];

  return (
    <nav
      className="fixed bottom-3 left-0 right-0 z-40 px-3 zad-nav-safe"
      role="navigation"
      aria-label={isAr ? 'شريط التنقل الرئيسي' : 'Main navigation'}
    >
      <div className="max-w-md mx-auto">
        <div className="flex items-center justify-around rounded-3xl border-2 border-[var(--line-strong)] bg-[var(--surface)] px-2 py-1.5 shadow-[0_6px_0_0_var(--shadow-card)]">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;

            if (tab.isPrimary) {
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className="relative -mt-8 flex flex-col items-center focus:outline-none group"
                  aria-label={tab.label}
                >
                  <motion.div
                    whileTap={{ scale: 0.9 }}
                    className={`w-14 h-14 rounded-2xl flex items-center justify-center border-2 border-[var(--line-strong)] transition-colors ${
                      isActive
                        ? 'bg-[var(--accent)] text-white animate-pulse-ring'
                        : 'bg-[var(--brand)] text-white group-hover:-rotate-6'
                    }`}
                    style={{ boxShadow: '4px 4px 0 0 var(--shadow-card)' }}
                  >
                    <Sparkles className="w-6 h-6" />
                  </motion.div>
                  <span
                    className={`text-[10px] font-extrabold mt-0.5 px-1.5 rounded-md ${
                      isActive ? 'text-[var(--accent)]' : 'text-[var(--muted)]'
                    }`}
                  >
                    {tab.label}
                  </span>
                </button>
              );
            }

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className="relative flex flex-col items-center justify-center py-1.5 px-2.5 rounded-2xl focus:outline-none"
                aria-label={tab.label}
                aria-current={isActive ? 'page' : undefined}
              >
                {isActive && (
                  <motion.span
                    layoutId="zad-nav-pill"
                    className="absolute inset-0 rounded-2xl bg-[var(--brand-soft)] border-2 border-[var(--brand)]"
                    transition={{ type: 'spring', stiffness: 500, damping: 38 }}
                  />
                )}
                <div className="relative z-10 flex flex-col items-center">
                  <div className="relative">
                    <Icon
                      className={`w-5 h-5 transition-colors ${
                        isActive ? 'text-[var(--brand-ink)]' : 'text-[var(--faint)]'
                      }`}
                      strokeWidth={isActive ? 2.6 : 2}
                    />
                    {tab.badge !== undefined && (
                      <span className="absolute -top-1.5 -left-2 bg-[var(--accent)] text-white text-[9px] font-bold min-w-[16px] h-4 px-1 rounded-full flex items-center justify-center border border-[var(--surface)]">
                        {tab.badge}
                      </span>
                    )}
                  </div>
                  <span
                    className={`text-[10px] mt-0.5 font-bold transition-colors ${
                      isActive ? 'text-[var(--brand-ink)]' : 'text-[var(--faint)]'
                    }`}
                  >
                    {tab.label}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
};
