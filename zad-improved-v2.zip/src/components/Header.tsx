/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useApp } from '../context/AppContext';
import { Sparkles, Package, Moon, Sun, Globe, FileText } from 'lucide-react';
import { checkPantryExpiry } from '../utils/rules';

export const Header: React.FC = () => {
  const {
    language,
    setLanguage,
    theme,
    toggleTheme,
    aiConfig,
    setIsAISettingsOpen,
    setActiveTab,
    setIsDeliverablesOpen,
    pantry,
  } = useApp();

  const isAr = language === 'ar';

  const expiringCount = pantry.filter((p) => {
    const { status } = checkPantryExpiry(p.expiryDate);
    return status === 'expiring_soon' || status === 'expired';
  }).length;

  const aiOk = aiConfig?.lastStatus === 'connected';

  return (
    <header className="sticky top-0 z-40 px-3 pt-3 pb-2">
      <div className="max-w-5xl mx-auto flex items-center justify-between gap-2 rounded-2xl border-2 border-[var(--line-strong)] bg-[var(--surface)] px-3 py-2 shadow-[4px_4px_0_0_var(--shadow-card)]">
        {/* الهوية */}
        <div
          onClick={() => setActiveTab('home')}
          className="flex items-center gap-2.5 cursor-pointer group select-none"
          role="button"
          tabIndex={0}
          aria-label={isAr ? 'الصفحة الرئيسية لذاد' : 'ZAD Home'}
          onKeyDown={(e) => e.key === 'Enter' && setActiveTab('home')}
        >
          <div className="w-10 h-10 rounded-xl bg-[var(--brand)] text-white flex items-center justify-center font-bold text-xl border-2 border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)] group-hover:-rotate-6 transition-transform">
            ذ
          </div>
          <div className="leading-tight">
            <div className="flex items-baseline gap-1.5">
              <span className="font-extrabold text-lg tracking-tight text-[var(--ink)]">ذاد</span>
              <span className="text-[10px] font-extrabold text-[var(--accent)] tracking-[0.2em]">ZAD</span>
            </div>
            <p className="text-[10px] text-[var(--muted)] font-semibold hidden sm:block">
              {isAr ? 'الخير في اللي عندك' : 'Goodness in what you have'}
            </p>
          </div>
        </div>

        {/* الأدوات */}
        <div className="flex items-center gap-1.5">
          {/* مؤشر الذكاء الاصطناعي */}
          <button
            onClick={() => setIsAISettingsOpen(true)}
            className={`relative w-9 h-9 rounded-xl border-2 border-[var(--line-strong)] flex items-center justify-center transition-transform hover:-translate-y-0.5 ${
              aiOk ? 'bg-[var(--brand-soft)]' : 'bg-[var(--warn-soft)]'
            }`}
            title={isAr ? 'إعدادات نماذج الذكاء الاصطناعي' : 'AI Settings'}
            aria-label={isAr ? 'إعدادات نماذج الذكاء الاصطناعي' : 'AI Settings'}
          >
            <Sparkles className={`w-4 h-4 ${aiOk ? 'text-[var(--brand-ink)]' : 'text-[var(--warn-ink)]'}`} />
            <span
              className={`absolute -top-1 -left-1 w-2.5 h-2.5 rounded-full border-2 border-[var(--surface)] ${
                aiOk ? 'bg-[var(--brand)] animate-pulse' : 'bg-[var(--warn-line)]'
              }`}
            />
          </button>

          {/* المخزن مع عداد التنبيه */}
          <button
            onClick={() => setActiveTab('pantry')}
            className="relative w-9 h-9 rounded-xl border-2 border-[var(--line-strong)] bg-[var(--surface-2)] flex items-center justify-center transition-transform hover:-translate-y-0.5"
            aria-label={isAr ? 'المخزن' : 'Pantry'}
            title={isAr ? 'المخزن وتقليل الهدر' : 'Pantry'}
          >
            <Package className="w-4 h-4 text-[var(--brand-ink)]" />
            {expiringCount > 0 && (
              <span className="absolute -top-1.5 -left-1.5 bg-[var(--accent)] text-white text-[9px] font-bold w-4.5 h-4.5 min-w-[18px] min-h-[18px] rounded-full flex items-center justify-center border-2 border-[var(--surface)] px-0.5">
                {expiringCount}
              </span>
            )}
          </button>

          {/* الوثائق */}
          <button
            onClick={() => setIsDeliverablesOpen(true)}
            className="w-9 h-9 rounded-xl border-2 border-[var(--line-strong)] bg-[var(--surface)] flex items-center justify-center transition-transform hover:-translate-y-0.5 hidden sm:flex"
            title={isAr ? 'توثيق المنتج' : 'Product docs'}
            aria-label={isAr ? 'مستندات المشروع' : 'Product docs'}
          >
            <FileText className="w-4 h-4 text-[var(--muted)]" />
          </button>

          {/* الوضع الليلي ✨ جديد */}
          <button
            onClick={toggleTheme}
            className="w-9 h-9 rounded-xl border-2 border-[var(--line-strong)] bg-[var(--surface)] flex items-center justify-center transition-all hover:-translate-y-0.5 hover:rotate-12"
            title={isAr ? (theme === 'dark' ? 'الوضع النهاري' : 'الوضع الليلي') : 'Toggle theme'}
            aria-label={isAr ? 'تبديل الوضع الليلي' : 'Toggle dark mode'}
          >
            {theme === 'dark' ? (
              <Sun className="w-4 h-4 text-[var(--warn-ink)]" />
            ) : (
              <Moon className="w-4 h-4 text-[var(--muted)]" />
            )}
          </button>

          {/* اللغة */}
          <button
            onClick={() => setLanguage(isAr ? 'en' : 'ar')}
            className="h-9 px-2.5 rounded-xl border-2 border-[var(--line-strong)] bg-[var(--surface)] flex items-center gap-1 text-xs font-extrabold text-[var(--muted)] hover:text-[var(--ink)] transition-all hover:-translate-y-0.5"
            aria-label={isAr ? 'تبديل للإنجليزية' : 'Switch to Arabic'}
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{isAr ? 'EN' : 'ع'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
