/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  Package,
  Plus,
  Trash2,
  Calendar,
  AlertTriangle,
  Sparkles,
  Camera,
  Refrigerator,
  Archive,
  Snowflake,
  CookingPot,
  CheckCircle2,
} from 'lucide-react';
import { checkPantryExpiry, currencySymbol } from '../utils/rules';

export const PantryView: React.FC = () => {
  const {
    language,
    pantry,
    addPantryItem,
    updatePantryItem,
    deletePantryItem,
    markItemUsedUp,
    addShoppingItem,
    userPreferences,
    setActiveTab,
    scanIngredientsPhoto,
    stats,
  } = useApp();

  const isAr = language === 'ar';
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [activeLocationFilter, setActiveLocationFilter] = useState<string>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isPhotoScanning, setIsPhotoScanning] = useState(false);
  const [scanFeedback, setScanFeedback] = useState<string | null>(null);

  // Form state
  const [name, setName] = useState('');
  const [quantity, setQuantity] = useState<number>(1);
  const [unit, setUnit] = useState('كجم');
  const [category, setCategory] = useState('خضروات');
  const [storageLocation, setStorageLocation] = useState<'fridge' | 'pantry' | 'freezer'>('fridge');
  const [expiryDays, setExpiryDays] = useState<number>(5);
  const [purchasePrice, setPurchasePrice] = useState<number>(20);

  const quickStaples = [
    { name: 'بيض', unit: 'حبة', defaultDays: 14, cat: 'ألبان وبيض', loc: 'fridge', price: 35 },
    { name: 'طماطم', unit: 'كجم', defaultDays: 5, cat: 'خضروات', loc: 'fridge', price: 18 },
    { name: 'بصل', unit: 'كجم', defaultDays: 20, cat: 'خضروات', loc: 'pantry', price: 14 },
    { name: 'أرز', unit: 'كجم', defaultDays: 180, cat: 'حبوب', loc: 'pantry', price: 32 },
    { name: 'عدس', unit: 'كجم', defaultDays: 180, cat: 'حبوب', loc: 'pantry', price: 28 },
    { name: 'تونة', unit: 'علبة', defaultDays: 365, cat: 'معلبات', loc: 'pantry', price: 25 },
    { name: 'زبادي', unit: 'علبة', defaultDays: 7, cat: 'ألبان', loc: 'fridge', price: 8 },
  ];

  const handleQuickAdd = (staple: (typeof quickStaples)[0]) => {
    const expDate = new Date();
    expDate.setDate(expDate.getDate() + staple.defaultDays);

    addPantryItem({
      name: staple.name,
      category: staple.cat,
      quantity: 1,
      unit: staple.unit,
      purchaseDate: new Date().toISOString().split('T')[0],
      expiryDate: expDate.toISOString().split('T')[0],
      storageLocation: staple.loc as any,
      purchasePrice: staple.price,
    });
  };

  const handleAddSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const expDate = new Date();
    expDate.setDate(expDate.getDate() + (expiryDays || 7));

    addPantryItem({
      name: name.trim(),
      category,
      quantity: Number(quantity) || 1,
      unit,
      purchaseDate: new Date().toISOString().split('T')[0],
      expiryDate: expDate.toISOString().split('T')[0],
      storageLocation,
      purchasePrice: Number(purchasePrice) || 0,
    });

    setName('');
    setIsAddModalOpen(false);
  };

  /* ✅ الإصلاح الجوهري: تصوير حقيقي — الملف يُحوَّل base64 فعلياً ويُرسل للتحليل */
  const handlePhotoSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsPhotoScanning(true);
    setScanFeedback(null);
    try {
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const result = String(reader.result || '');
          resolve(result.includes(',') ? result.split(',')[1] : result);
        };
        reader.onerror = () => reject(new Error('read-error'));
        reader.readAsDataURL(file);
      });

      const result = await scanIngredientsPhoto(base64, file.type || 'image/jpeg');

      if (result.ingredients.length === 0) {
        setScanFeedback(isAr ? 'ماقدرناش نحدد مكونات من الصورة — جرب صورة أوضح للثلاجة.' : 'No ingredients detected — try a clearer photo.');
        return;
      }

      result.ingredients.forEach((ing) => {
        const expDate = new Date();
        expDate.setDate(expDate.getDate() + 5);
        addPantryItem({
          name: ing,
          category: isAr ? 'مكتشف بالصورة' : 'Photo scan',
          quantity: 1,
          unit: 'حبة',
          purchaseDate: new Date().toISOString().split('T')[0],
          expiryDate: expDate.toISOString().split('T')[0],
          storageLocation: 'fridge',
          notes: result.source,
        });
      });
      setScanFeedback(
        isAr
          ? `تم اكتشاف ${result.ingredients.length} مكونات وإضافتها للمخزن: ${result.ingredients.join('، ')}`
          : `Detected ${result.ingredients.length} ingredients: ${result.ingredients.join(', ')}`
      );
    } catch (err) {
      setScanFeedback(isAr ? 'تعذر تحليل الصورة — جرب مرة أخرى أو أضف المكونات يدوياً.' : 'Could not analyze the photo — try again.');
    } finally {
      setIsPhotoScanning(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const filteredItems = pantry.filter((item) => {
    if (activeLocationFilter === 'all') return true;
    return item.storageLocation === activeLocationFilter;
  });

  const expiringItems = pantry.filter((item) => {
    const { status } = checkPantryExpiry(item.expiryDate);
    return status === 'expiring_soon' || status === 'expired';
  });

  const zeroItems = pantry.filter((item) => item.quantity <= 0);

  const locationTabs = [
    { id: 'all', label: isAr ? 'الكل' : 'All', icon: Package, count: pantry.length },
    { id: 'fridge', label: isAr ? 'الثلاجة' : 'Fridge', icon: Refrigerator, count: pantry.filter((i) => i.storageLocation === 'fridge').length },
    { id: 'pantry', label: isAr ? 'الخزانة' : 'Shelf', icon: Archive, count: pantry.filter((i) => i.storageLocation === 'pantry').length },
    { id: 'freezer', label: isAr ? 'الفريزر' : 'Freezer', icon: Snowflake, count: pantry.filter((i) => i.storageLocation === 'freezer').length },
  ];

  return (
    <div className="space-y-5 pb-24 pt-1 animate-fade-in">
      {/* الهيدر */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-[var(--brand-ink)] tracking-tight">
            {isAr ? 'مخزن البيت' : 'Home Pantry'}
          </h2>
          <p className="text-xs text-[var(--muted)] font-semibold">
            {isAr
              ? `${pantry.length} مكونات — ${expiringItems.length} تحتاج استخداماً أولاً`
              : `${pantry.length} items — ${expiringItems.length} need attention`}
          </p>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          {/* ✅ كاميرا حقيقية */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={handlePhotoSelected}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={isPhotoScanning}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3 py-2 rounded-xl bg-[var(--surface)] text-[var(--brand-ink)] border-2 border-[var(--line-strong)] text-xs font-extrabold shadow-[2px_2px_0_0_var(--shadow-card)] hover:-translate-y-0.5 transition-transform disabled:opacity-60"
          >
            <Camera className={`w-4 h-4 text-[var(--accent)] ${isPhotoScanning ? 'animate-pulse' : ''}`} />
            <span>
              {isPhotoScanning ? (isAr ? 'جارِ التحليل...' : 'Analyzing...') : isAr ? 'صوّر الثلاجة' : 'Scan Fridge'}
            </span>
          </button>

          <button
            onClick={() => setIsAddModalOpen(true)}
            className="flex-1 sm:flex-initial flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-xl bg-[var(--brand)] text-white text-xs font-extrabold border-2 border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)]"
          >
            <Plus className="w-4 h-4" />
            <span>{isAr ? 'إضافة يدوي' : 'Add item'}</span>
          </button>
        </div>
      </div>

      {scanFeedback && (
        <div className="p-3 rounded-2xl border-2 border-[var(--brand-line)] bg-[var(--brand-soft)] text-[var(--brand-ink)] text-xs font-extrabold flex items-center gap-2 animate-pop">
          <CheckCircle2 className="w-4 h-4 flex-shrink-0" />
          <span>{scanFeedback}</span>
        </div>
      )}

      {/* تنبيه القرب من الانتهاء */}
      {expiringItems.length > 0 && (
        <div className="rounded-3xl border-2 border-[var(--warn-line)] bg-[var(--warn-soft)] p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 shadow-[3px_3px_0_0_var(--shadow-card)]">
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-[var(--warn-ink)] flex-shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs sm:text-sm font-black text-[var(--warn-ink)]">
                {isAr
                  ? `${expiringItems.length} مكونات توشك على الانتهاء`
                  : `${expiringItems.length} items expiring soon`}
              </h4>
              <p className="text-[11px] text-[var(--warn-ink)] opacity-80 mt-0.5 font-semibold">
                {isAr
                  ? '«الخير في اللي عندك» — وظّفها في وجبة اليوم قبل ما تضيع.'
                  : "Turn them into a meal today before they go to waste."}
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('ask_zad')}
            className="px-3.5 py-1.5 rounded-xl bg-[var(--accent)] text-white text-xs font-extrabold border-2 border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)] flex items-center gap-1 flex-shrink-0"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isAr ? 'اقترح وصفة' : 'Suggest recipes'}</span>
          </button>
        </div>
      )}

      {/* عناصر وصلت صفر — إضافة ذكية */}
      {zeroItems.length > 0 && (
        <div className="rounded-2xl border-2 border-[var(--line)] bg-[var(--surface-2)] p-3 flex flex-wrap items-center gap-2">
          <span className="text-[11px] font-extrabold text-[var(--muted)]">
            {isAr ? 'خلص عندك:' : 'Ran out of:'}
          </span>
          {zeroItems.map((it) => (
            <button
              key={it.id}
              onClick={() => {
                addShoppingItem({
                  name: it.name,
                  quantity: 1,
                  unit: it.unit,
                  category: it.category,
                });
                deletePantryItem(it.id);
                setActiveTab('shopping');
              }}
              className="text-[11px] font-extrabold px-2 py-0.5 rounded-lg bg-[var(--surface)] border-2 border-[var(--line-strong)] text-[var(--ink)] hover:-translate-y-0.5 transition-transform"
              title={isAr ? 'أضفه لقائمة التسوق' : 'Add to shopping list'}
            >
              🛒 {it.name}
            </button>
          ))}
        </div>
      )}

      {/* الأساسيات السريعة */}
      <div className="rounded-3xl border-2 border-[var(--line-strong)] bg-[var(--surface)] p-3 space-y-2 shadow-[3px_3px_0_0_var(--shadow-card)]">
        <span className="text-[11px] font-extrabold text-[var(--muted)] block">
          {isAr ? 'إضافة سريعة بضغطة واحدة:' : 'Quick staple add:'}
        </span>
        <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none">
          {quickStaples.map((st, i) => (
            <button
              key={i}
              onClick={() => handleQuickAdd(st)}
              className="flex-shrink-0 text-xs px-2.5 py-1.5 rounded-lg bg-[var(--surface-2)] border-2 border-[var(--line-strong)] text-[var(--ink)] hover:-translate-y-0.5 transition-transform font-extrabold"
            >
              + {st.name}
            </button>
          ))}
        </div>
      </div>

      {/* تبويبات المكان */}
      <div className="flex gap-2 flex-wrap">
        {locationTabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeLocationFilter === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveLocationFilter(tab.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-extrabold border-2 transition-all ${
                isActive
                  ? 'bg-[var(--brand)] text-white border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)]'
                  : 'bg-[var(--surface)] text-[var(--muted)] border-[var(--line-strong)]'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
              <span className={`text-[9px] px-1 rounded ${isActive ? 'bg-white/20' : 'bg-[var(--surface-2)]'}`}>
                {tab.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* شبكة العناصر */}
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
        {filteredItems.map((item) => {
          const { status, daysRemaining } = checkPantryExpiry(item.expiryDate);

          return (
            <div
              key={item.id}
              className={`rounded-2xl border-2 p-4 space-y-3 transition-all shadow-[3px_3px_0_0_var(--shadow-card)] ${
                status === 'expired'
                  ? 'border-[var(--danger-line)] bg-[var(--danger-soft)]'
                  : status === 'expiring_soon'
                  ? 'border-[var(--warn-line)] bg-[var(--warn-soft)]'
                  : 'border-[var(--line-strong)] bg-[var(--surface)]'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <h4 className="font-black text-sm text-[var(--ink)]">{item.name}</h4>
                  <span className="text-[11px] text-[var(--muted)] font-bold">{item.category}</span>
                </div>
                <button
                  onClick={() => deletePantryItem(item.id)}
                  className="text-[var(--faint)] hover:text-[var(--danger-ink)] transition-colors p-1"
                  aria-label={isAr ? `حذف ${item.name}` : `Delete ${item.name}`}
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              <div className="flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="font-black text-[var(--brand-ink)] text-base">{item.quantity}</span>
                  <span className="text-[var(--muted)] font-bold">{item.unit}</span>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => updatePantryItem(item.id, { quantity: Math.max(0, item.quantity - 1) })}
                    className="w-6 h-6 rounded-md bg-[var(--surface)] border-2 border-[var(--line-strong)] font-black flex items-center justify-center text-[var(--ink)]"
                  >
                    −
                  </button>
                  <button
                    onClick={() => updatePantryItem(item.id, { quantity: item.quantity + 1 })}
                    className="w-6 h-6 rounded-md bg-[var(--surface)] border-2 border-[var(--line-strong)] font-black flex items-center justify-center text-[var(--ink)]"
                  >
                    +
                  </button>
                </div>
              </div>

              <div className="pt-2 border-t-2 border-[var(--line)] flex items-center justify-between gap-1 text-[11px]">
                <div className="flex items-center gap-1 text-[var(--faint)] font-bold">
                  <Calendar className="w-3 h-3" />
                  <span>{item.expiryDate}</span>
                </div>
                <span
                  className={`font-extrabold px-2 py-0.5 rounded-lg ${
                    status === 'expired'
                      ? 'bg-[var(--danger-line)] text-[var(--danger-ink)]'
                      : status === 'expiring_soon'
                      ? 'bg-[var(--warn-mid)] text-[var(--warn-ink)]'
                      : 'bg-[var(--brand-soft)] text-[var(--brand-ink)]'
                  }`}
                >
                  {status === 'expired'
                    ? isAr ? 'انتهت الصلاحية' : 'Expired'
                    : status === 'expiring_soon'
                    ? isAr ? `متبقي ${daysRemaining} يوم` : `${daysRemaining}d left`
                    : isAr ? `طازج (${daysRemaining} يوم)` : `Fresh (${daysRemaining}d)`}
                </span>
              </div>

              {/* ✅ زر «استخدمته» — يحسب في محفظة الإنقاذ */}
              <button
                onClick={() => markItemUsedUp(item.id)}
                className={`w-full py-1.5 rounded-lg border-2 border-[var(--line-strong)] text-[11px] font-extrabold flex items-center justify-center gap-1.5 transition-transform hover:-translate-y-0.5 ${
                  status === 'expired'
                    ? 'bg-[var(--surface-2)] text-[var(--muted)]'
                    : 'bg-[var(--brand-soft-strong)] text-[var(--brand-ink)]'
                }`}
                title={isAr ? 'استخدمته بالكامل — يسجل في محفظة التوفير' : 'Used it up — counts in rescue wallet'}
              >
                <CookingPot className="w-3.5 h-3.5" />
                <span>{isAr ? 'استخدمته بالكامل ✨' : 'Used it up ✨'}</span>
              </button>
            </div>
          );
        })}
      </div>

      {filteredItems.length === 0 && (
        <div className="text-center py-12 rounded-3xl border-2 border-[var(--line-strong)] bg-[var(--surface)] p-6 space-y-2 shadow-[4px_4px_0_0_var(--shadow-card)]">
          <Package className="w-10 h-10 text-[var(--faint)] mx-auto opacity-50" />
          <h3 className="font-black text-sm text-[var(--ink)]">
            {isAr ? 'القسم ده فاضي' : 'No items in this section'}
          </h3>
          <p className="text-xs text-[var(--muted)] font-semibold">
            {isAr ? 'أضف مكوناتك أو صوّر الثلاجة بالكاميرا.' : 'Add items or scan your fridge.'}
          </p>
        </div>
      )}

      {/* شريط محفظة التوفير */}
      <div className="rounded-3xl border-2 border-[var(--brand-line)] bg-[var(--brand-soft)] p-4 flex items-center justify-between gap-3 shadow-[3px_3px_0_0_var(--shadow-card)]">
        <div>
          <h4 className="text-xs font-black text-[var(--brand-ink)]">
            {isAr ? '💰 محفظة الإنقاذ' : 'Rescue wallet'}
          </h4>
          <p className="text-[11px] text-[var(--muted)] font-bold mt-0.5">
            {isAr
              ? `أنقذت ${stats.rescuedItems} مكونات ووفّرت ~${Math.round(stats.savedMoney)} ${currencySymbol(userPreferences.currency)} من الهدر`
              : `Rescued ${stats.rescuedItems} items, saved ~${Math.round(stats.savedMoney)} ${userPreferences.currency}`}
          </p>
        </div>
        <button
          onClick={() => setActiveTab('ask_zad')}
          className="flex-shrink-0 px-3 py-1.5 rounded-xl bg-[var(--brand)] text-white text-[11px] font-extrabold border-2 border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)]"
        >
          {isAr ? 'أنقذ المتبقي' : 'Rescue more'}
        </button>
      </div>

      {/* مودال الإضافة */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="rounded-3xl max-w-md w-full p-5 space-y-4 border-2 border-[var(--line-strong)] bg-[var(--surface)] shadow-[6px_6px_0_0_var(--shadow-card)] animate-pop">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-[var(--brand-ink)]">
                {isAr ? 'إضافة مكون جديد' : 'Add new pantry item'}
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="w-7 h-7 rounded-lg bg-[var(--surface-2)] border-2 border-[var(--line-strong)] text-[var(--muted)] flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleAddSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-extrabold text-[var(--muted)] block mb-1">
                  {isAr ? 'اسم المكون:' : 'Ingredient name:'}
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder={isAr ? 'مثال: أرز بسمتي، جبنة بيضاء...' : 'e.g. Basmati rice'}
                  className="w-full text-xs sm:text-sm bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-xl px-3 py-2 text-[var(--ink)]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-xs font-extrabold text-[var(--muted)] block mb-1">
                    {isAr ? 'الكمية:' : 'Quantity:'}
                  </label>
                  <input
                    type="number"
                    min="0.1"
                    step="any"
                    value={quantity}
                    onChange={(e) => setQuantity(parseFloat(e.target.value) || 1)}
                    className="w-full text-xs sm:text-sm bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-xl px-3 py-2 text-[var(--ink)]"
                  />
                </div>
                <div>
                  <label className="text-xs font-extrabold text-[var(--muted)] block mb-1">
                    {isAr ? 'الوحدة:' : 'Unit:'}
                  </label>
                  <select
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="w-full text-xs sm:text-sm bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-xl px-3 py-2 text-[var(--ink)]"
                  >
                    <option value="حبة">{isAr ? 'حبة' : 'Piece'}</option>
                    <option value="كجم">{isAr ? 'كجم' : 'kg'}</option>
                    <option value="جرام">{isAr ? 'جرام' : 'Gram'}</option>
                    <option value="علبة">{isAr ? 'علبة' : 'Pack'}</option>
                    <option value="لتر">{isAr ? 'لتر' : 'Liter'}</option>
                    <option value="مل">{isAr ? 'مل' : 'ml'}</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-xs font-extrabold text-[var(--muted)] block mb-1">
                    {isAr ? 'مكان الحفظ:' : 'Storage:'}
                  </label>
                  <select
                    value={storageLocation}
                    onChange={(e) => setStorageLocation(e.target.value as any)}
                    className="w-full text-xs sm:text-sm bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-xl px-3 py-2 text-[var(--ink)]"
                  >
                    <option value="fridge">{isAr ? 'الثلاجة' : 'Fridge'}</option>
                    <option value="pantry">{isAr ? 'خزانة / رف' : 'Pantry'}</option>
                    <option value="freezer">{isAr ? 'الفريزر' : 'Freezer'}</option>
                  </select>
                </div>
                <div>
                  <label className="text-xs font-extrabold text-[var(--muted)] block mb-1">
                    {isAr ? 'صلاحية تقديرية (أيام):' : 'Shelf-life (days):'}
                  </label>
                  <input
                    type="number"
                    min="1"
                    value={expiryDays}
                    onChange={(e) => setExpiryDays(parseInt(e.target.value) || 7)}
                    className="w-full text-xs sm:text-sm bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-xl px-3 py-2 text-[var(--ink)]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-extrabold text-[var(--muted)] block mb-1">
                  {isAr ? 'سعر الشراء (اختياري — يغذي محفظة التوفير):' : 'Purchase price (optional):'}
                </label>
                <input
                  type="number"
                  min="0"
                  value={purchasePrice}
                  onChange={(e) => setPurchasePrice(parseFloat(e.target.value) || 0)}
                  className="w-full text-xs sm:text-sm bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-xl px-3 py-2 text-[var(--ink)]"
                />
              </div>

              <div className="pt-1 flex items-center gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[var(--brand)] text-white text-xs font-extrabold border-2 border-[var(--line-strong)]"
                >
                  {isAr ? 'حفظ في المخزن' : 'Save to pantry'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="py-2.5 px-4 rounded-xl border-2 border-[var(--line-strong)] bg-[var(--surface-2)] text-[var(--muted)] text-xs font-extrabold"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
