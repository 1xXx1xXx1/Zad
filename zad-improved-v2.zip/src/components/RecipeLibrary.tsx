/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Search,
  Filter,
  Flame,
  Clock,
  Coins,
  Heart,
  Plus,
  Utensils,
  CheckCircle2,
  Sparkles,
  ChevronDown,
  ShoppingBag,
  Star,
  Users,
  Globe,
  Link as LinkIcon,
  BookOpen,
  ExternalLink,
  Youtube,
  ChefHat,
  Bookmark,
  AlertCircle,
  ArrowRight,
  ArrowLeft,
  Share2,
} from 'lucide-react';
import { Recipe, MealType, EquipmentMode } from '../types';
import { computeMissingIngredients, currencySymbol } from '../utils/rules';

export const RecipeLibrary: React.FC = () => {
  const {
    language,
    recipes,
    addRecipe,
    pantry,
    userPreferences,
    openCookMode,
    toggleFavoriteRecipe,
    rateRecipe,
    addRecipeMissingToShoppingList,
  } = useApp();

  const isAr = language === 'ar';
  const Arrow = isAr ? ArrowLeft : ArrowRight;

  // Primary Tabs
  const [activeTab, setActiveTab] = useState<'zad' | 'global' | 'importer' | 'platforms'>('zad');

  // Tab 1 (ZAD Curated) Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedEquipmentFilter, setSelectedEquipmentFilter] = useState<string>('all');
  const [showOnlyFavorites, setShowOnlyFavorites] = useState(false);
  const [activeRecipeDetail, setActiveRecipeDetail] = useState<Recipe | null>(null);
  const [servingsScale, setServingsScale] = useState<number>(2);
  const [feedbackToast, setFeedbackToast] = useState<string | null>(null);

  // Tab 2 (Global Recipe Explorer - TheMealDB)
  const [globalSearchQuery, setGlobalSearchQuery] = useState('');
  const [selectedCuisine, setSelectedCuisine] = useState<string>('all');
  const [globalRecipes, setGlobalRecipes] = useState<Recipe[]>([]);
  const [isLoadingGlobal, setIsLoadingGlobal] = useState(false);
  const [globalError, setGlobalError] = useState<string | null>(null);

  // Tab 3 (Recipe Importer from URL)
  const [importUrl, setImportUrl] = useState('');
  const [isImporting, setIsImporting] = useState(false);
  const [importedPreview, setImportedPreview] = useState<Recipe | null>(null);
  const [importError, setImportError] = useState<string | null>(null);

  const categories = [
    { id: 'all', label: isAr ? 'الكل' : 'All' },
    { id: 'breakfast', label: isAr ? 'فطور' : 'Breakfast' },
    { id: 'lunch', label: isAr ? 'غداء' : 'Lunch' },
    { id: 'dinner', label: isAr ? 'عشاء' : 'Dinner' },
    { id: 'snack', label: isAr ? 'سناك' : 'Snack' },
    { id: 'drink', label: isAr ? 'مشروبات' : 'Drinks' },
    { id: 'dessert', label: isAr ? 'حلويات' : 'Dessert' },
  ];

  const equipmentFilters = [
    { id: 'all', label: isAr ? 'كل المعدات' : 'All Equipment' },
    { id: 'no_fire', label: isAr ? 'بدون نار' : 'No Fire' },
    { id: 'no_kitchen', label: isAr ? 'بدون مطبخ' : 'No Kitchen' },
    { id: 'limited_equipment', label: isAr ? 'أواني محدودة' : 'Single Pot/Pan' },
  ];

  const cuisinesList = [
    { id: 'all', label: isAr ? 'جميع المطابخ' : 'All Cuisines', flag: '🌍' },
    { id: 'Egyptian', label: isAr ? 'المصرية' : 'Egyptian', flag: '🇪🇬' },
    { id: 'Italian', label: isAr ? 'الإيطالية' : 'Italian', flag: '🇮🇹' },
    { id: 'Indian', label: isAr ? 'الهندية' : 'Indian', flag: '🇮🇳' },
    { id: 'Mexican', label: isAr ? 'المكسيكية' : 'Mexican', flag: '🇲🇽' },
    { id: 'Moroccan', label: isAr ? 'المغربية' : 'Moroccan', flag: '🇲🇦' },
    { id: 'Japanese', label: isAr ? 'اليابانية' : 'Japanese', flag: '🇯🇵' },
    { id: 'American', label: isAr ? 'الأمريكية' : 'American', flag: '🇺🇸' },
    { id: 'Greek', label: isAr ? 'اليونانية' : 'Greek', flag: '🇬🇷' },
  ];

  // Famous Platforms Catalog
  const platformsCatalog = [
    {
      name: 'TheMealDB',
      nameAr: 'مكتبة TheMealDB العالمية المفتوحة',
      description: 'أضخم مكتبة برمجية مفتوحة لملايين وصفات العالم متصلة مباشرة بتطبيق ذاد بالصور والفيديوهات.',
      url: 'https://www.themealdb.com',
      badge: isAr ? 'متصلة بالتطبيق مباشرة' : 'Directly Integrated',
      features: ['بحث فوري', 'صور عالية الدقة', 'فيديوهات يوتيوب'],
    },
    {
      name: 'Allrecipes',
      nameAr: 'أول ريسبيز (Allrecipes)',
      description: 'أكبر مجتمع طهاة منزلي في العالم يضم ملايين الوصفات العائلية المجرّبة مع تقييمات الملايين.',
      url: 'https://www.allrecipes.com',
      badge: isAr ? 'يدعم الاستيراد التلقائي' : 'Auto-Importable',
      features: ['تقييمات واقعية', 'وجبات سريعة وموفرة', 'مقادير منزلية'],
    },
    {
      name: 'BBC Good Food',
      nameAr: 'بي بي سي جود فود (BBC Good Food)',
      description: 'المرجع البريطاني والعالمي الأكثر ثقة واختباراً في مطابخ الطهاة المحترفين ومعهد الصحة.',
      url: 'https://www.bbcgoodfood.com',
      badge: isAr ? 'موثوق بنسبة 100%' : 'Triple-Tested',
      features: ['قيم غذائية دقيقة', 'وصفات لميزانيات محددة', 'أطباق عالمية'],
    },
    {
      name: 'Tasty by BuzzFeed',
      nameAr: 'تيستي (Tasty)',
      description: 'أشهر منصة فيديوهات طهي مبتكرة ومرحة لوجبات سريعة بمكونات قليلة وأفكار غير تقليدية.',
      url: 'https://tasty.co',
      badge: isAr ? 'وجبات سهلة وسريعة' : 'Easy & Quick',
      features: ['أفكار الـ 3 مكونات', 'حلويات بدون فرن', 'وجبات الطلاب'],
    },
    {
      name: 'SuperCook',
      nameAr: 'سوبر كوك (SuperCook)',
      description: 'المحرك الشهير المتخصص في استخراج وصفات من المكونات المتوفرة في ثلاجتك فقط دون هدر.',
      url: 'https://www.supercook.com',
      badge: isAr ? 'بدون هدر طعام' : 'Zero Food Waste',
      features: ['طبخ بالمتاح', 'أفكار بواقي الطعام', 'توفير الميزانية'],
    },
    {
      name: 'Serious Eats',
      nameAr: 'سيريوس إيتس (Serious Eats)',
      description: 'موقع الطهي العلمي المتقدم الذي يشرح لك "لماذا" تنجح الوصفة وكيفية تحسين النكهات بأبسط تقنية.',
      url: 'https://www.seriouseats.com',
      badge: isAr ? 'علم وفن الطهي' : 'Food Science',
      features: ['أسرار الطهي', 'بدائل المكونات', 'تقنيات المقلاة الواحدة'],
    },
    {
      name: 'Cookpad (كوكباد)',
      nameAr: 'كوكباد (Cookpad)',
      description: 'أكبر شبكة لوصفات البيوت والمطابخ العربية والمحلية مع تبادل الخبرات بين ربات البيوت والشباب.',
      url: 'https://cookpad.com/eg',
      badge: isAr ? 'مطابخ عربية ومحلية' : 'Arabic Home Cooks',
      features: ['أكلات شعبية مصرية وعربية', 'حلويات سهلة', 'تجارب حقيقية'],
    },
    {
      name: 'CBC Sofra & Manal Alalem',
      nameAr: 'سي بي سي سفرة ومنال العالم',
      description: 'أشهر المراجع والقنوات التلفزيونية العربية لتعليم فنون الطبخ المصري والعربي بأدق التفاصيل.',
      url: 'https://sofra.cbc-eg.com',
      badge: isAr ? 'تراث المطبخ العربي' : 'Arab Culinary Heritage',
      features: ['الشيف الشربيني ونجلاء الشرشابي', 'وصفات "على قد الإيد"', 'عزومات ومناسبات'],
    },
  ];

  // Fetch Global Recipes (TheMealDB)
  const fetchGlobal = async (query = '', cuisine = '') => {
    setIsLoadingGlobal(true);
    setGlobalError(null);
    try {
      let endpoint = `/api/recipes/global?q=${encodeURIComponent(query)}`;
      if (cuisine && cuisine !== 'all') {
        endpoint += `&cuisine=${encodeURIComponent(cuisine)}`;
      }
      const res = await fetch(endpoint);
      if (res.ok) {
        const data = await res.json();
        setGlobalRecipes(data.recipes || []);
      } else {
        setGlobalError(isAr ? 'تعذر جلب الوصفات العالمية حالياً.' : 'Failed to fetch global recipes.');
      }
    } catch {
      setGlobalError(isAr ? 'تعذر الاتصال بخدمة الوصفات العالمية.' : 'Connection error.');
    } finally {
      setIsLoadingGlobal(false);
    }
  };

  // Load initial global recipes when switching to global tab
  useEffect(() => {
    if (activeTab === 'global' && globalRecipes.length === 0) {
      fetchGlobal('', 'Egyptian');
    }
  }, [activeTab]);

  // Handle Global Search Form
  const handleGlobalSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchGlobal(globalSearchQuery, selectedCuisine);
  };

  // Handle URL Import
  const handleImportUrl = async (e?: React.FormEvent, customUrl?: string) => {
    if (e) e.preventDefault();
    const targetUrl = customUrl || importUrl;
    if (!targetUrl.trim()) return;

    setIsImporting(true);
    setImportError(null);
    setImportedPreview(null);

    try {
      const res = await fetch('/api/recipes/import-url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: targetUrl.trim() }),
      });
      const data = await res.json();
      if (res.ok && data.success && data.recipe) {
        setImportedPreview(data.recipe);
      } else {
        setImportError(data.message || (isAr ? 'تعذر استيراد الوصفة من هذا الرابط.' : 'Failed to import recipe.'));
      }
    } catch {
      setImportError(isAr ? 'حدث خطأ أثناء الاتصال بالخادم للاستيراد.' : 'Network error during import.');
    } finally {
      setIsImporting(false);
    }
  };

  // Save imported recipe to collection
  const handleSaveImportedRecipe = (recipe: Recipe) => {
    addRecipe(recipe);
    setFeedbackToast(
      isAr
        ? `تم حفظ "${recipe.title}" في مكتبة وصفاتك بنجاح!`
        : `Saved "${recipe.titleEn}" to your recipe library!`
    );
    setTimeout(() => setFeedbackToast(null), 3000);
  };

  // Pantry names for matching
  const pantryNames = pantry.map((p) => p.name);

  // Filter recipes for ZAD tab
  const filteredRecipes = recipes.filter((r) => {
    if (selectedCategory !== 'all' && r.category !== selectedCategory) return false;
    if (selectedEquipmentFilter !== 'all' && r.equipmentMode !== selectedEquipmentFilter) return false;
    if (showOnlyFavorites && !r.isFavorite) return false;

    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      const inTitle = r.title.toLowerCase().includes(q) || r.titleEn.toLowerCase().includes(q);
      const inTags = r.tags.some((t) => t.toLowerCase().includes(q));
      const inIngredients = r.ingredients.some((i) => i.name.toLowerCase().includes(q));
      if (!inTitle && !inTags && !inIngredients) return false;
    }

    return true;
  });

  const handleOpenDetail = (recipe: Recipe) => {
    setActiveRecipeDetail(recipe);
    setServingsScale(recipe.servings);
  };

  const handleAddMissing = (recipe: Recipe) => {
    const count = addRecipeMissingToShoppingList(recipe);
    setFeedbackToast(
      count > 0
        ? isAr
          ? `تمت إضافة ${count} مكونات ناقصة إلى قائمة التسوق بنجاح!`
          : `Added ${count} missing ingredients to shopping list!`
        : isAr
        ? 'جميع مكونات هذه الوصفة متوفرة بالفعل بمخزنك!'
        : 'All ingredients are already in your pantry!'
    );
    setTimeout(() => setFeedbackToast(null), 3000);
  };

  return (
    <div className="space-y-5 pb-20 pt-2 animate-fade-in">
      {/* Toast Notification */}
      {feedbackToast && (
        <div className="fixed top-16 left-1/2 transform -translate-x-1/2 z-50 bg-[var(--brand)] text-white text-xs font-bold px-4 py-2.5 rounded-2xl shadow-xl flex items-center gap-2 border border-[var(--brand-line)] animate-slide-down">
          <CheckCircle2 className="w-4 h-4 text-emerald-300" />
          <span>{feedbackToast}</span>
        </div>
      )}

      {/* Main Header & Section Introduction */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-extrabold text-[var(--brand)] tracking-tight">
              {isAr ? 'عالم وصفات ذاد والملايين العالمية' : 'ZAD Recipes & Global World Catalog'}
            </h2>
            <p className="text-xs text-[var(--muted)]">
              {isAr
                ? 'استكشف ملايين الوصفات من أشهر المنصات العالمية، أو استورد أي رابط، أو اطبخ مما لديك'
                : 'Explore millions of recipes from world databases, import any link, or cook with what you have'}
            </p>
          </div>
        </div>

        {/* Master Navigation Tabs */}
        <div className="flex gap-1.5 p-1.5 rounded-2xl border-2 border-[var(--line-strong)] bg-[var(--surface-2)] overflow-x-auto scrollbar-none shadow-[3px_3px_0_0_var(--shadow-card)]">
          <button
            onClick={() => setActiveTab('zad')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'zad'
                ? 'bg-[var(--brand)] text-white border-2 border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)]'
                : 'bg-[var(--surface)] text-[var(--muted)] border-2 border-[var(--line)] hover:border-[var(--line-strong)]'
            }`}
          >
            <ChefHat className="w-3.5 h-3.5" />
            <span>{isAr ? 'وصفات ذاد المختارة' : 'ZAD Curated'}</span>
            <span className="text-[10px] bg-[var(--brand-soft-strong)] text-[var(--brand-ink)] px-1.5 py-0.2 rounded-full">
              {recipes.length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('global')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'global'
                ? 'bg-[var(--brand)] text-white border-2 border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)]'
                : 'bg-[var(--surface)] text-[var(--muted)] border-2 border-[var(--line)] hover:border-[var(--line-strong)]'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-blue-600" />
            <span>{isAr ? 'المكتبة العالمية (TheMealDB والملايين)' : 'Global Library (Millions)'}</span>
            <span className="text-[10px] bg-blue-100 text-blue-800 px-1.5 py-0.2 rounded-full">
              API
            </span>
          </button>

          <button
            onClick={() => setActiveTab('importer')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'importer'
                ? 'bg-[var(--brand)] text-white border-2 border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)]'
                : 'bg-[var(--surface)] text-[var(--muted)] border-2 border-[var(--line)] hover:border-[var(--line-strong)]'
            }`}
          >
            <LinkIcon className="w-3.5 h-3.5 text-[var(--accent)]" />
            <span>{isAr ? 'استيراد وصفة من أي موقع أو تطبيق' : 'Universal Web Importer'}</span>
            <span className="text-[10px] bg-orange-100 text-[var(--accent)] px-1.5 py-0.2 rounded-full">
              {isAr ? 'ذكي' : 'Smart'}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('platforms')}
            className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
              activeTab === 'platforms'
                ? 'bg-[var(--brand)] text-white border-2 border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)]'
                : 'bg-[var(--surface)] text-[var(--muted)] border-2 border-[var(--line)] hover:border-[var(--line-strong)]'
            }`}
          >
            <BookOpen className="w-3.5 h-3.5 text-purple-600" />
            <span>{isAr ? 'دليل أشهر مواقع ومكتبات الطهي' : 'Famous Platforms Directory'}</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: ZAD CURATED RECIPES                                               */}
      {/* ========================================================================= */}
      {activeTab === 'zad' && (
        <div className="space-y-4">
          {/* Search & Favorites Controls */}
          <div className="flex flex-col sm:flex-row gap-2.5">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[var(--faint)] absolute top-1/2 -translate-y-1/2 right-3 pointer-events-none" />
              <input
                type="text"
                placeholder={isAr ? 'ابحث في وصفاتك المحفوظة، مكونات، أو تصنيفات...' : 'Search recipes, ingredients...'}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pr-9 pl-4 py-2.5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] text-xs text-[var(--ink)] focus:outline-none focus:ring-1 focus:ring-[var(--brand)]"
              />
            </div>

            <button
              onClick={() => setShowOnlyFavorites(!showOnlyFavorites)}
              className={`flex items-center justify-center gap-1.5 px-3.5 py-2 rounded-2xl text-xs font-bold border transition-colors flex-shrink-0 ${
                showOnlyFavorites
                  ? 'bg-[var(--danger-soft)] text-red-600 border-[var(--danger-line)]'
                  : 'bg-[var(--surface)] text-[var(--muted)] border-[var(--line)] hover:bg-[var(--bg)]'
              }`}
            >
              <Heart className={`w-3.5 h-3.5 ${showOnlyFavorites ? 'fill-red-500 text-red-500' : ''}`} />
              <span>{isAr ? 'المفضلة' : 'Favorites'}</span>
            </button>
          </div>

          {/* Category Chips */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-[var(--brand)] text-white shadow-xs'
                    : 'bg-[var(--surface)] text-[var(--muted)] border border-[var(--line)] hover:bg-[var(--bg)]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          {/* Equipment Mode Filter Chips */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {equipmentFilters.map((eq) => (
              <button
                key={eq.id}
                onClick={() => setSelectedEquipmentFilter(eq.id)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-semibold whitespace-nowrap transition-all ${
                  selectedEquipmentFilter === eq.id
                    ? 'bg-[var(--accent)] text-white'
                    : 'bg-[var(--surface-2)] text-[var(--muted)] hover:bg-[var(--line)]'
                }`}
              >
                {eq.label}
              </button>
            ))}
          </div>

          {/* Recipe Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
            {filteredRecipes.map((recipe) => {
              const ingNames = recipe.ingredients.map((i) => i.name);
              const missingIngs = computeMissingIngredients(ingNames, pantryNames).missing;
              const missingCount = missingIngs.length;

              return (
                <div
                  key={recipe.id}
                  className="bg-[var(--surface)] rounded-2xl border border-[var(--line)] overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col group"
                >
                  {/* Image & Badges */}
                  <div className="h-40 relative overflow-hidden bg-[var(--surface-2)] cursor-pointer" onClick={() => handleOpenDetail(recipe)}>
                    <img
                      src={recipe.imageUrl}
                      alt={recipe.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      loading="lazy"
                    />
                    <div className="absolute top-2.5 right-2.5 flex items-center gap-1 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                      <Clock className="w-3 h-3 text-[var(--accent)]" />
                      <span>{recipe.prepTimeMinutes + recipe.cookTimeMinutes} د</span>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavoriteRecipe(recipe.id);
                      }}
                      className="absolute top-2.5 left-2.5 w-7 h-7 rounded-full bg-[var(--surface)]/80 backdrop-blur-md flex items-center justify-center text-[var(--ink)] hover:text-red-500 transition-colors"
                      aria-label="Favorite"
                    >
                      <Heart className={`w-3.5 h-3.5 ${recipe.isFavorite ? 'fill-red-500 text-red-500' : ''}`} />
                    </button>

                    {/* Source / Imported Tag */}
                    {recipe.sourcePlatform && (
                      <div className="absolute bottom-2 right-2 bg-emerald-900/80 backdrop-blur-md text-emerald-100 text-[9px] font-bold px-2 py-0.5 rounded-md">
                        {recipe.sourcePlatform}
                      </div>
                    )}
                  </div>

                  {/* Body */}
                  <div className="p-3.5 flex-1 flex flex-col justify-between space-y-3">
                    <div>
                      <div className="flex items-center justify-between gap-1 mb-1">
                        <span className="text-[10px] font-bold text-[var(--accent)] bg-orange-50 px-2 py-0.5 rounded-md">
                          {recipe.equipmentMode === 'no_fire'
                            ? (isAr ? 'بدون نار' : 'No Fire')
                            : recipe.equipmentMode === 'limited_equipment'
                            ? (isAr ? 'مقلاة/وعاء واحد' : 'Single Pot')
                            : (isAr ? 'مطبخ متاح' : 'Kitchen')}
                        </span>
                        <span className="text-[10px] text-[var(--faint)] font-semibold">
                          ~{recipe.estimatedCost} {currencySymbol(userPreferences.currency)}
                        </span>
                      </div>

                      <h3
                        onClick={() => handleOpenDetail(recipe)}
                        className="font-extrabold text-sm text-[var(--ink)] line-clamp-1 hover:text-[var(--brand)] cursor-pointer"
                      >
                        {isAr ? recipe.title : recipe.titleEn}
                      </h3>
                      <p className="text-[11px] text-[var(--muted)] line-clamp-2 mt-1">
                        {recipe.description}
                      </p>
                    </div>

                    {/* Pantry Match Indicator */}
                    <div className="pt-2 border-t border-[var(--bg)] flex items-center justify-between text-[11px]">
                      {missingCount === 0 ? (
                        <span className="text-[var(--brand-ink)] font-bold flex items-center gap-1">
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{isAr ? 'كل المكونات متوفرة' : 'Ready to cook'}</span>
                        </span>
                      ) : (
                        <span className="text-[var(--warn-ink)] font-semibold flex items-center gap-1">
                          <ShoppingBag className="w-3.5 h-3.5 text-[var(--warn-ink)]" />
                          <span>
                            {isAr ? `ينقصك ${missingCount} مكونات` : `${missingCount} missing`}
                          </span>
                        </span>
                      )}

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleOpenDetail(recipe)}
                          className="px-2.5 py-1 rounded-lg bg-[var(--bg)] text-[var(--brand)] hover:bg-[var(--line)] text-xs font-bold transition-colors"
                        >
                          {isAr ? 'التفاصيل' : 'Details'}
                        </button>
                        <button
                          onClick={() => openCookMode(recipe)}
                          className="px-2.5 py-1 rounded-lg bg-[var(--brand)] text-white hover:bg-[var(--brand-deep)] text-xs font-bold shadow-xs transition-colors flex items-center gap-1"
                        >
                          <Flame className="w-3 h-3 text-[var(--accent)]" />
                          <span>{isAr ? 'اطبخ' : 'Cook'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: GLOBAL RECIPE EXPLORER (TheMealDB API & Millions)                  */}
      {/* ========================================================================= */}
      {activeTab === 'global' && (
        <div className="space-y-4">
          {/* Global Search Bar */}
          <form onSubmit={handleGlobalSearch} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[var(--faint)] absolute top-1/2 -translate-y-1/2 right-3 pointer-events-none" />
              <input
                type="text"
                placeholder={isAr ? 'ابحث في ملايين الوصفات العالمية (مثال: Chicken, Pasta, Shawarma, Koshari, Salad)...' : 'Search millions of global recipes...'}
                value={globalSearchQuery}
                onChange={(e) => setGlobalSearchQuery(e.target.value)}
                className="w-full pr-9 pl-4 py-2.5 rounded-2xl bg-[var(--surface)] border border-[var(--line)] text-xs text-[var(--ink)] focus:outline-none focus:ring-1 focus:ring-[var(--brand)]"
              />
            </div>
            <button
              type="submit"
              disabled={isLoadingGlobal}
              className="px-4 py-2.5 rounded-2xl bg-[var(--brand)] text-white text-xs font-bold hover:bg-[var(--brand-deep)] shadow-xs transition-colors disabled:opacity-60 flex items-center gap-1 flex-shrink-0"
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{isLoadingGlobal ? (isAr ? 'جاري البحث...' : 'Searching...') : (isAr ? 'بحث عالمي' : 'Search')}</span>
            </button>
          </form>

          {/* Cuisine Selector Chips */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 no-scrollbar">
            {cuisinesList.map((c) => (
              <button
                key={c.id}
                onClick={() => {
                  setSelectedCuisine(c.id);
                  fetchGlobal(globalSearchQuery, c.id);
                }}
                className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
                  selectedCuisine === c.id
                    ? 'bg-[var(--brand)] text-white shadow-xs'
                    : 'bg-[var(--surface)] text-[var(--muted)] border border-[var(--line)] hover:bg-[var(--bg)]'
                }`}
              >
                <span>{c.flag}</span>
                <span>{c.label}</span>
              </button>
            ))}
          </div>

          {/* Integration Status Bar */}
          <div className="bg-blue-50 border border-blue-200 rounded-2xl p-3 flex items-center justify-between text-xs text-blue-900">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-blue-600 flex-shrink-0" />
              <span>
                {isAr
                  ? 'متصل بمكتبة TheMealDB العالمية المفتوحة — يمكنك حفظ أي وصفة بضغطة زر لمجموعتك أو تشغيل وضع الطبخ فوراً.'
                  : 'Connected to TheMealDB Open API — Save any recipe to your ZAD library or start cooking instantly.'}
              </span>
            </div>
          </div>

          {globalError && (
            <div className="p-3 rounded-xl bg-[var(--warn-soft)] border border-[var(--warn-line)] text-[var(--warn-ink)] text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-[var(--warn-ink)] flex-shrink-0" />
              <span>{globalError}</span>
            </div>
          )}

          {/* Global Recipe Grid */}
          {isLoadingGlobal ? (
            <div className="py-16 text-center space-y-3">
              <div className="w-8 h-8 border-3 border-[var(--brand)] border-t-transparent rounded-full animate-spin mx-auto"></div>
              <p className="text-xs text-[var(--muted)]">
                {isAr ? 'جاري استدعاء أشهى الوصفات العالمية من المكتبة المفتوحة...' : 'Retrieving global recipes from API...'}
              </p>
            </div>
          ) : globalRecipes.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3.5">
              {globalRecipes.map((gRecipe) => {
                const isAlreadySaved = recipes.some((r) => r.id === gRecipe.id || r.title === gRecipe.title);

                return (
                  <div
                    key={gRecipe.id}
                    className="bg-[var(--surface)] rounded-2xl border border-[var(--line)] overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col group"
                  >
                    <div className="h-40 relative overflow-hidden bg-[var(--surface-2)] cursor-pointer" onClick={() => handleOpenDetail(gRecipe)}>
                      <img
                        src={gRecipe.imageUrl}
                        alt={gRecipe.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                        loading="lazy"
                      />
                      <div className="absolute top-2.5 right-2.5 bg-black/60 backdrop-blur-md text-white text-[10px] font-bold px-2 py-0.5 rounded-full">
                        {gRecipe.cuisine || 'عالمي'}
                      </div>

                      {gRecipe.youtubeUrl && (
                        <a
                          href={gRecipe.youtubeUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-full bg-red-600/90 text-white text-[10px] font-bold flex items-center gap-1 hover:bg-red-700"
                          title="Watch on YouTube"
                        >
                          <Youtube className="w-3 h-3" />
                          <span>فيديو</span>
                        </a>
                      )}
                    </div>

                    <div className="p-3.5 flex-1 flex flex-col justify-between space-y-3">
                      <div>
                        <h4
                          onClick={() => handleOpenDetail(gRecipe)}
                          className="font-extrabold text-sm text-[var(--ink)] line-clamp-1 hover:text-[var(--brand)] cursor-pointer"
                        >
                          {gRecipe.title}
                        </h4>
                        <p className="text-[10px] text-[var(--faint)] mt-0.5">
                          {gRecipe.ingredients.length} {isAr ? 'مكونات' : 'ingredients'} • {gRecipe.steps.length} {isAr ? 'خطوات' : 'steps'}
                        </p>
                      </div>

                      <div className="pt-2 border-t border-[var(--bg)] flex items-center justify-between gap-1">
                        <button
                          onClick={() => handleSaveImportedRecipe(gRecipe)}
                          disabled={isAlreadySaved}
                          className={`flex-1 py-1.5 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1 transition-colors ${
                            isAlreadySaved
                              ? 'bg-[var(--brand-soft)] text-[var(--brand-ink)] border border-[var(--brand-line)]'
                              : 'bg-[var(--bg)] text-[var(--brand)] hover:bg-[var(--line)]'
                          }`}
                        >
                          <Bookmark className="w-3 h-3" />
                          <span>{isAlreadySaved ? (isAr ? 'محفوظة لديك' : 'Saved') : (isAr ? 'حفظ في ذاد' : 'Save')}</span>
                        </button>

                        <button
                          onClick={() => openCookMode(gRecipe)}
                          className="py-1.5 px-3 rounded-xl bg-[var(--brand)] text-white hover:bg-[var(--brand-deep)] text-xs font-bold shadow-xs transition-colors flex items-center gap-1"
                        >
                          <Flame className="w-3 h-3 text-[var(--accent)]" />
                          <span>{isAr ? 'اطبخ' : 'Cook'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="py-12 text-center text-xs text-[var(--muted)]">
              {isAr ? 'لم يتم العثور على نتائج. جرب كتابة اسم طعام آخر مثل Chicken أو Beef.' : 'No recipes found. Try another search.'}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 3: SMART RECIPE WEB IMPORTER                                         */}
      {/* ========================================================================= */}
      {activeTab === 'importer' && (
        <div className="space-y-4">
          <div className="bg-gradient-to-r from-orange-50 to-amber-50 rounded-2xl p-4 border border-orange-200 space-y-2">
            <div className="flex items-center gap-2 text-sm font-extrabold text-[var(--brand)]">
              <Sparkles className="w-4 h-4 text-[var(--accent)]" />
              <span>{isAr ? 'مستورد الوصفات الذكي من أي موقع أو تطبيق عالمي' : 'Universal Smart Recipe Web Importer'}</span>
            </div>
            <p className="text-xs text-[var(--muted)]">
              {isAr
                ? 'انسخ رابط أي وصفة تعجبك من أي موقع أو تطبيق في العالم (Allrecipes, BBC Good Food, Serious Eats, Tasty, Cookpad, منال العالم, سي بي سي سفرة)، والصقه هنا لتحويلها فوراً إلى وصفة ذاد المنظمة مع حساب المكونات الناقصة في مخزنك وتشغيل وضع الطبخ التفاعلي!'
                : 'Paste any recipe URL from anywhere on the web. ZAD automatically parses ingredients, instructions, and integrates them with your pantry and cook mode!'}
            </p>
          </div>

          {/* URL Input Form */}
          <form onSubmit={(e) => handleImportUrl(e)} className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <LinkIcon className="w-4 h-4 text-[var(--faint)] absolute top-1/2 -translate-y-1/2 right-3 pointer-events-none" />
              <input
                type="url"
                placeholder={isAr ? 'https://www.allrecipes.com/recipe/... أو أي موقع طهي' : 'https://www.bbcgoodfood.com/recipes/...'}
                value={importUrl}
                onChange={(e) => setImportUrl(e.target.value)}
                className="w-full pr-9 pl-4 py-3 rounded-2xl bg-[var(--surface)] border border-[var(--line)] text-xs text-[var(--ink)] focus:outline-none focus:ring-1 focus:ring-[var(--brand)]"
              />
            </div>
            <button
              type="submit"
              disabled={isImporting || !importUrl.trim()}
              className="px-5 py-3 rounded-2xl bg-[var(--accent)] text-white text-xs font-bold hover:bg-[var(--accent-deep)] shadow-xs transition-colors disabled:opacity-60 flex items-center justify-center gap-1.5 flex-shrink-0"
            >
              <Sparkles className={`w-3.5 h-3.5 ${isImporting ? 'animate-spin' : ''}`} />
              <span>{isImporting ? (isAr ? 'جاري الاستيراد والتحليل...' : 'Importing & Parsing...') : (isAr ? 'استيراد الوصفة فوراً' : 'Import Recipe')}</span>
            </button>
          </form>

          {/* Quick-test Presets */}
          <div className="space-y-1.5">
            <span className="text-[11px] font-bold text-[var(--muted)]">
              {isAr ? 'أو جرّب استيراد روابط تجريبية شهيرة بضغطة واحدة:' : 'Or test quick presets with one click:'}
            </span>
            <div className="flex flex-wrap gap-2">
              {[
                { label: 'Allrecipes: كبسة دجاج عالمية', url: 'https://www.allrecipes.com/recipe/261947/saudi-arabian-kabsa/' },
                { label: 'BBC Good Food: معكرونة سريعة', url: 'https://www.bbcgoodfood.com/recipes/easy-one-pot-pasta' },
                { label: 'Tasty: كوكيز الشوكولاتة', url: 'https://tasty.co/recipe/3-ingredient-cookies' },
                { label: 'Cookpad: كفتة بطاطس اقتصادية', url: 'https://cookpad.com/eg/recipes/15291244-potato-kofta' },
              ].map((preset, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setImportUrl(preset.url);
                    handleImportUrl(undefined, preset.url);
                  }}
                  className="px-2.5 py-1.5 rounded-xl bg-[var(--surface)] border border-[var(--line)] text-[11px] text-[var(--brand)] hover:bg-[var(--bg)] font-semibold transition-colors flex items-center gap-1"
                >
                  <ExternalLink className="w-3 h-3 text-[var(--accent)]" />
                  <span>{preset.label}</span>
                </button>
              ))}
            </div>
          </div>

          {importError && (
            <div className="p-3 rounded-xl bg-[var(--danger-soft)] border border-[var(--danger-line)] text-[var(--danger-ink)] text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0" />
              <span>{importError}</span>
            </div>
          )}

          {/* Imported Recipe Preview Card */}
          {importedPreview && (
            <div className="bg-[var(--surface)] rounded-3xl p-5 border-2 border-emerald-500 shadow-md space-y-4 animate-fade-in">
              <div className="flex items-center justify-between border-b border-[var(--bg)] pb-3">
                <div className="flex items-center gap-2">
                  <span className="text-xs bg-[var(--brand-soft-strong)] text-[var(--brand-ink)] font-bold px-2.5 py-0.5 rounded-full">
                    {isAr ? 'تم الاستيراد بنجاح' : 'Successfully Imported'}
                  </span>
                  <span className="text-xs text-[var(--faint)] font-semibold">
                    المصدر: {importedPreview.sourcePlatform}
                  </span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleSaveImportedRecipe(importedPreview)}
                    className="px-3.5 py-1.5 rounded-xl bg-[var(--brand)] text-white text-xs font-bold hover:bg-[var(--brand-deep)] shadow-xs transition-colors flex items-center gap-1"
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                    <span>{isAr ? 'حفظ في مكتبتي' : 'Save to My Library'}</span>
                  </button>
                  <button
                    onClick={() => openCookMode(importedPreview)}
                    className="px-3.5 py-1.5 rounded-xl bg-[var(--accent)] text-white text-xs font-bold hover:bg-[var(--accent-deep)] shadow-xs transition-colors flex items-center gap-1"
                  >
                    <Flame className="w-3.5 h-3.5" />
                    <span>{isAr ? 'اطبخ الآن' : 'Cook Now'}</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="h-44 rounded-2xl overflow-hidden bg-[var(--surface-2)]">
                  <img
                    src={importedPreview.imageUrl}
                    alt={importedPreview.title}
                    className="w-full h-full object-cover"
                  />
                </div>

                <div className="md:col-span-2 space-y-2.5">
                  <h3 className="font-extrabold text-base text-[var(--brand)]">{importedPreview.title}</h3>
                  <p className="text-xs text-[var(--muted)]">{importedPreview.description}</p>

                  <div className="flex flex-wrap gap-2 text-xs">
                    <span className="bg-[var(--bg)] px-2.5 py-1 rounded-lg border border-[var(--line)] font-bold text-[var(--ink)]">
                      ⏱️ {importedPreview.prepTimeMinutes + importedPreview.cookTimeMinutes} دقيقة
                    </span>
                    <span className="bg-[var(--bg)] px-2.5 py-1 rounded-lg border border-[var(--line)] font-bold text-[var(--ink)]">
                      👥 {importedPreview.servings} حصص
                    </span>
                    <span className="bg-[var(--bg)] px-2.5 py-1 rounded-lg border border-[var(--line)] font-bold text-[var(--brand-ink)]">
                      💰 ~{importedPreview.estimatedCost} {currencySymbol(userPreferences.currency)}
                    </span>
                  </div>

                  {/* Missing ingredients preview */}
                  {(() => {
                    const ingNames = importedPreview.ingredients.map((i) => i.name);
                    const missing = computeMissingIngredients(ingNames, pantryNames).missing;
                    return (
                      <div className="pt-2">
                        <span className="text-xs font-bold text-[var(--muted)] block mb-1">
                          {isAr ? 'مقارنة المكونات مع مخزنك الحالي:' : 'Pantry Comparison:'}
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {importedPreview.ingredients.map((ing, iIdx) => {
                            const isAvailable = pantryNames.some((p) => p.includes(ing.name) || ing.name.includes(p));
                            return (
                              <span
                                key={iIdx}
                                className={`text-[11px] px-2 py-0.5 rounded-md font-medium border ${
                                  isAvailable
                                    ? 'bg-[var(--brand-soft)] text-[var(--brand-ink)] border-[var(--brand-line)]'
                                    : 'bg-[var(--warn-soft)] text-[var(--warn-ink)] border-[var(--warn-line)]'
                                }`}
                              >
                                {isAvailable ? '✓' : '+'} {ing.name} ({ing.quantity} {ing.unit})
                              </span>
                            );
                          })}
                        </div>

                        {missing.length > 0 && (
                          <button
                            onClick={() => handleAddMissing(importedPreview)}
                            className="mt-2 text-xs font-bold text-[var(--accent)] hover:underline flex items-center gap-1"
                          >
                            <Plus className="w-3.5 h-3.5" />
                            <span>{isAr ? `إضافة ${missing.length} مكونات ناقصة لقائمة التسوق` : 'Add missing to shopping list'}</span>
                          </button>
                        )}
                      </div>
                    );
                  })()}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 4: FAMOUS PLATFORMS DIRECTORY                                        */}
      {/* ========================================================================= */}
      {activeTab === 'platforms' && (
        <div className="space-y-4">
          <div className="bg-[var(--surface-2)] rounded-2xl p-4 border border-[var(--line)] text-xs text-purple-900 space-y-1">
            <div className="font-extrabold text-sm flex items-center gap-1.5 text-purple-950">
              <BookOpen className="w-4 h-4 text-purple-700" />
              <span>{isAr ? 'دليل أشهر مواقع ومكتبات الطهي العالمية المتخصصة' : 'Top International Culinary Platforms Directory'}</span>
            </div>
            <p className="text-[var(--muted)]">
              {isAr
                ? 'تصفح أكبر مواقع وتطبيقات الطبخ حول العالم. يمكنك فتح أي موقع، واختيار وصفتك المفضلة، ونسخ رابطها ولصقه في "مستورد الوصفات" في ذاد للطهي بها مباشرة!'
                : 'Browse the world’s leading recipe hubs. Pick any recipe, copy its link, and import it into ZAD for instant step-by-step cooking and pantry matching.'}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            {platformsCatalog.map((plat, idx) => (
              <div
                key={idx}
                className="bg-[var(--surface)] rounded-2xl p-4 border border-[var(--line)] shadow-xs hover:shadow-md transition-shadow flex flex-col justify-between space-y-3"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="font-extrabold text-sm text-[var(--brand)]">{plat.nameAr}</h3>
                    <span className="text-[10px] bg-[var(--surface-2)] text-[var(--muted)] font-bold px-2 py-0.5 rounded-full flex-shrink-0">
                      {plat.badge}
                    </span>
                  </div>
                  <p className="text-xs text-[var(--muted)] mt-1.5 leading-relaxed">{plat.description}</p>

                  <div className="flex flex-wrap gap-1.5 mt-2.5">
                    {plat.features.map((f, fIdx) => (
                      <span key={fIdx} className="text-[10px] bg-[var(--bg)] text-[var(--faint)] px-2 py-0.5 rounded border border-[var(--line)]">
                        • {f}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-[var(--bg)] flex items-center justify-between">
                  <a
                    href={plat.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs font-bold text-[var(--accent)] hover:underline"
                  >
                    <span>{isAr ? 'زيارة الموقع وتصفح الوصفات' : 'Visit Platform'}</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>

                  <button
                    onClick={() => {
                      setActiveTab('importer');
                      setImportUrl(plat.url);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-[var(--bg)] text-[var(--brand)] hover:bg-[var(--line)] text-xs font-bold transition-colors"
                  >
                    {isAr ? 'استيراد وصفة' : 'Import Recipe'}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* RECIPE DETAIL MODAL                                                      */}
      {/* ========================================================================= */}
      {activeRecipeDetail && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-fade-in">
          <div className="bg-[var(--bg)] rounded-3xl max-w-2xl w-full max-h-[92vh] overflow-y-auto border border-[var(--line)] shadow-2xl flex flex-col">
            {/* Header Image */}
            <div className="h-56 sm:h-64 relative overflow-hidden bg-[var(--surface-2)]">
              <img
                src={activeRecipeDetail.imageUrl}
                alt={activeRecipeDetail.title}
                className="w-full h-full object-cover"
              />
              <button
                onClick={() => setActiveRecipeDetail(null)}
                className="absolute top-3 left-3 w-8 h-8 rounded-full bg-[var(--surface)]/80 backdrop-blur-md text-[var(--ink)] hover:bg-[var(--surface)] flex items-center justify-center font-bold"
                aria-label="Close"
              >
                ✕
              </button>

              <div className="absolute bottom-3 right-3 flex items-center gap-2">
                <span className="bg-black/60 backdrop-blur-md text-white text-xs font-bold px-3 py-1 rounded-full">
                  ⏱️ {activeRecipeDetail.prepTimeMinutes + activeRecipeDetail.cookTimeMinutes} دقيقة
                </span>
                <span className="bg-[var(--brand)]/90 backdrop-blur-md text-white text-xs font-bold px-3 py-1 rounded-full">
                  💰 ~{Math.round((activeRecipeDetail.estimatedCost / activeRecipeDetail.servings) * servingsScale)} {currencySymbol(userPreferences.currency)}
                </span>
              </div>
            </div>

            {/* Content */}
            <div className="p-5 space-y-4">
              <div>
                <div className="flex items-center justify-between">
                  <h3 className="font-extrabold text-lg sm:text-xl text-[var(--brand)]">
                    {isAr ? activeRecipeDetail.title : activeRecipeDetail.titleEn}
                  </h3>
                  <button
                    onClick={() => toggleFavoriteRecipe(activeRecipeDetail.id)}
                    className="p-2 rounded-full hover:bg-[var(--surface)] text-red-500"
                  >
                    <Heart className={`w-5 h-5 ${activeRecipeDetail.isFavorite ? 'fill-red-500' : ''}`} />
                  </button>
                </div>
                <p className="text-xs text-[var(--muted)] mt-1">{activeRecipeDetail.description}</p>
              </div>

              {/* Servings Scaler */}
              <div className="bg-[var(--surface)] rounded-2xl p-3 border border-[var(--line)] flex items-center justify-between text-xs">
                <div className="flex items-center gap-1.5 font-bold text-[var(--ink)]">
                  <Users className="w-4 h-4 text-[var(--brand)]" />
                  <span>{isAr ? 'عدد الحصص والأشخاص:' : 'Servings:'}</span>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setServingsScale(Math.max(1, servingsScale - 1))}
                    className="w-7 h-7 rounded-lg bg-[var(--bg)] text-[var(--brand)] font-bold border border-[var(--line)] hover:bg-[var(--line)]"
                  >
                    -
                  </button>
                  <span className="font-extrabold text-sm w-6 text-center">{servingsScale}</span>
                  <button
                    onClick={() => setServingsScale(servingsScale + 1)}
                    className="w-7 h-7 rounded-lg bg-[var(--bg)] text-[var(--brand)] font-bold border border-[var(--line)] hover:bg-[var(--line)]"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Ingredients List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-bold text-xs text-[var(--brand)]">
                    {isAr ? 'المقادير والمكونات:' : 'Ingredients:'}
                  </h4>
                  <button
                    onClick={() => handleAddMissing(activeRecipeDetail)}
                    className="text-xs font-bold text-[var(--accent)] hover:underline flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{isAr ? 'إضافة النواقص للتسوق' : 'Add missing to list'}</span>
                  </button>
                </div>

                <div className="space-y-1.5">
                  {activeRecipeDetail.ingredients.map((ing, iIdx) => {
                    const scaledQuantity = Number(((ing.quantity / activeRecipeDetail.servings) * servingsScale).toFixed(1));
                    const isAvailable = pantryNames.some((p) => p.includes(ing.name) || ing.name.includes(p));

                    return (
                      <div
                        key={iIdx}
                        className="bg-[var(--surface)] p-2.5 rounded-xl border border-[var(--line)] flex items-center justify-between text-xs"
                      >
                        <div className="flex items-center gap-2">
                          <span className={`w-2 h-2 rounded-full ${isAvailable ? 'bg-emerald-500' : 'bg-amber-400'}`} />
                          <span className="font-semibold text-[var(--ink)]">{ing.name}</span>
                        </div>
                        <div className="text-[var(--muted)] font-bold">
                          {scaledQuantity} {ing.unit}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Steps List */}
              <div className="space-y-2">
                <h4 className="font-bold text-xs text-[var(--brand)]">
                  {isAr ? 'خطوات التحضير بالتفصيل:' : 'Preparation Steps:'}
                </h4>

                <div className="space-y-2">
                  {activeRecipeDetail.steps.map((step, sIdx) => (
                    <div key={sIdx} className="bg-[var(--surface)] p-3 rounded-2xl border border-[var(--line)] text-xs space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="w-5 h-5 rounded-full bg-[var(--brand)] text-white flex items-center justify-center text-[10px] font-bold flex-shrink-0">
                          {sIdx + 1}
                        </span>
                        <p className="font-medium text-[var(--ink)] leading-relaxed">{step.instruction}</p>
                      </div>
                      {step.timerSeconds && (
                        <div className="text-[10px] text-[var(--accent)] font-bold mr-7 flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          <span>مؤقت موصى به: {Math.round(step.timerSeconds / 60)} دقائق</span>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Actions Footer */}
              <div className="pt-3 border-t border-[var(--line)] flex items-center justify-between gap-2">
                <button
                  onClick={() => setActiveRecipeDetail(null)}
                  className="px-4 py-2.5 rounded-xl bg-[var(--surface)] text-[var(--muted)] border border-[var(--line)] text-xs font-bold hover:bg-[var(--bg)]"
                >
                  {isAr ? 'إغلاق' : 'Close'}
                </button>

                <button
                  onClick={() => {
                    const rec = activeRecipeDetail;
                    setActiveRecipeDetail(null);
                    openCookMode(rec);
                  }}
                  className="flex-1 px-4 py-2.5 rounded-xl bg-[var(--brand)] text-white text-xs font-bold hover:bg-[var(--brand-deep)] shadow-xs flex items-center justify-center gap-2"
                >
                  <Flame className="w-4 h-4 text-[var(--accent)]" />
                  <span>{isAr ? 'ابدأ وضع الطبخ التفاعلي خطوة بخطوة' : 'Start Step-by-Step Cook Mode'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
