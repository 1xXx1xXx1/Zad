/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import {
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Key,
  Trash2,
  ExternalLink,
  ChevronDown,
  ChevronUp,
  Cpu,
  RefreshCw,
  Info,
  X,
  Upload,
} from 'lucide-react';

export const AISettingsModal: React.FC = () => {
  const {
    isAISettingsOpen,
    setIsAISettingsOpen,
    aiConfig,
    testConnection,
    saveAIConfig,
    removeAICredentials,
    refreshAIConfig,
    language,
  } = useApp();

  const isAr = language === 'ar';

  const [provider, setProvider] = useState<'gemini' | 'openai' | 'custom'>('gemini');
  const [apiKey, setApiKey] = useState('');
  const [model, setModel] = useState('gemini-3.8-flash');
  const [fallbackModel, setFallbackModel] = useState('gemini-3.1-flash-lite');
  const [customEndpoint, setCustomEndpoint] = useState('');
  const [isByokActive, setIsByokActive] = useState(false);

  // Connection testing state
  const [isTesting, setIsTesting] = useState(false);
  const [testResult, setTestResult] = useState<{
    ok: boolean;
    message: string;
    latencyMs: number;
  } | null>(null);

  const [isSaving, setIsSaving] = useState(false);
  const [saveMessage, setSaveMessage] = useState<{ ok: boolean; text: string } | null>(null);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [showConfirmRemove, setShowConfirmRemove] = useState(false);

  // Sync state when config loads
  useEffect(() => {
    if (aiConfig) {
      setProvider(aiConfig.provider || 'gemini');
      setModel(aiConfig.model || 'gemini-3.8-flash');
      setFallbackModel(aiConfig.fallbackModel || 'gemini-3.1-flash-lite');
      setCustomEndpoint(aiConfig.customEndpoint || '');
      setIsByokActive(aiConfig.isByokActive || false);
    }
  }, [aiConfig]);

  if (!isAISettingsOpen) return null;

  const providerModels: { [key: string]: { id: string; label: string }[] } = {
    gemini: [
      { id: 'gemini-3.8-flash', label: 'Gemini 3.8 Flash (الموصى به - متوازن وفائق السرعة)' },
      { id: 'gemini-3.1-flash-lite', label: 'Gemini 3.1 Flash Lite (خفيف واقتصادي جداً)' },
      { id: 'gemini-4-argon', label: 'Gemini 4 Argon (استدلال متقدم للوصفات المعقدة)' },
    ],
    openai: [
      { id: 'gpt-4o-mini', label: 'GPT-4o Mini (سريع ومناسب للتكلفة)' },
      { id: 'gpt-4o', label: 'GPT-4o (نموذج رائد متعدد الوسائط)' },
    ],
    custom: [
      { id: 'custom-model', label: 'Custom Endpoint Model' },
    ],
  };

  const handleTestConnection = async () => {
    setIsTesting(true);
    setTestResult(null);
    setSaveMessage(null);

    try {
      const res = await testConnection({
        provider,
        apiKey: apiKey.trim() || undefined,
        model,
        customEndpoint: customEndpoint.trim() || undefined,
      });
      setTestResult(res);
    } catch (e: any) {
      setTestResult({
        ok: false,
        message: e?.message || 'تعذر الاتصال بالخادم لفحص المفتاح.',
        latencyMs: 0,
      });
    } finally {
      setIsTesting(false);
    }
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    setSaveMessage(null);

    try {
      const res = await saveAIConfig({
        provider,
        apiKey: apiKey.trim() || undefined,
        model,
        fallbackModel,
        customEndpoint: customEndpoint.trim() || undefined,
        isByokActive: Boolean(apiKey.trim() || aiConfig?.hasCustomKey),
      });

      setSaveMessage({
        ok: res.ok,
        text: res.ok
          ? isAr
            ? 'تم حفظ إعدادات النموذج بنجاح وتفعيلها فوراً!'
            : 'AI settings saved and activated successfully!'
          : res.message,
      });
      setApiKey(''); // Clear raw key input after saving, server keeps it masked
      await refreshAIConfig();
    } catch (err: any) {
      setSaveMessage({
        ok: false,
        text: err?.message || 'حدث خطأ أثناء حفظ الإعدادات.',
      });
    } finally {
      setIsSaving(false);
    }
  };

  const handleRemoveKey = async () => {
    await removeAICredentials();
    setShowConfirmRemove(false);
    setTestResult(null);
    setSaveMessage({
      ok: true,
      text: isAr ? 'تمت إزالة المفتاح الشخصي والعودة للإعدادات الأساسية.' : 'Credentials removed.',
    });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const json = JSON.parse(event.target?.result as string);
        if (json.provider) setProvider(json.provider);
        if (json.model) setModel(json.model);
        if (json.apiKey) setApiKey(json.apiKey);
        if (json.fallbackModel) setFallbackModel(json.fallbackModel);
        if (json.customEndpoint) setCustomEndpoint(json.customEndpoint);
        setSaveMessage({
          ok: true,
          text: isAr ? 'تم قراءة ملف الإعدادات بنجاح. افحص الاتصال ثم احفظ.' : 'Config file loaded successfully.',
        });
      } catch (err) {
        setSaveMessage({
          ok: false,
          text: isAr ? 'ملف التكوين غير صالح. يرجى التأكد من صيغة JSON.' : 'Invalid JSON config file.',
        });
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-fade-in">
      <div className="bg-[var(--bg)] rounded-3xl max-w-2xl w-full max-h-[92vh] overflow-y-auto border border-[var(--line)] shadow-2xl p-5 sm:p-7 space-y-5">
        {/* Header */}
        <div className="flex items-start justify-between border-b border-[var(--line)] pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[var(--brand)] text-white flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-[var(--accent)]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold text-[var(--brand)]">
                  {isAr ? 'نماذج الذكاء الاصطناعي وإدارة المزودين' : 'AI Models & Provider Settings'}
                </h2>
                <span className="text-[10px] bg-[var(--brand-soft)] text-[var(--brand-ink)] border border-[var(--brand-line)] px-2 py-0.5 rounded-full font-bold">
                  {isAr ? 'طبقة معمارية مرنة' : 'Provider Layer'}
                </span>
              </div>
              <p className="text-xs text-[var(--muted)] mt-0.5">
                {isAr
                  ? 'اختر مزود الذكاء، اختبر الاتصال بالنموذج، أو استخدم مفتاحك الخاص (BYOK) بكل أمان.'
                  : 'Manage AI models, test connection, or Bring Your Own Key securely.'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAISettingsOpen(false)}
            className="w-8 h-8 rounded-full bg-[var(--surface)] text-[var(--muted)] hover:bg-[var(--line)] flex items-center justify-center font-bold"
            aria-label={isAr ? 'إغلاق' : 'Close'}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current Provider Health & Diagnostics Card */}
        <div className="bg-[var(--surface)] rounded-2xl p-4 border border-[var(--line)] shadow-2xs space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-[var(--muted)]">
              {isAr ? 'حالة المزود الحالي:' : 'Current Provider Status:'}
            </span>
            <div className="flex items-center gap-1.5">
              <span
                className={`w-2 h-2 rounded-full ${
                  aiConfig?.lastStatus === 'connected' ? 'bg-emerald-500' : 'bg-amber-400'
                }`}
              />
              <span className="text-xs font-extrabold text-[var(--brand)]">
                {aiConfig?.hasCustomKey
                  ? isAr ? 'مفتاح مخصص مفعل (BYOK)' : 'Custom BYOK Active'
                  : aiConfig?.lastStatus === 'connected'
                  ? isAr ? 'متصل وجاهز للاستخدام' : 'Connected & Ready'
                  : isAr ? 'وضع المعرفة الذاتي (محفوظ)' : 'Curated Fallback'}
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 text-center text-[11px] pt-1">
            <div className="p-2 bg-[var(--bg)] rounded-xl border border-[var(--line)]">
              <span className="text-[var(--faint)] block">{isAr ? 'المزود' : 'Provider'}</span>
              <span className="font-bold text-[var(--ink)] uppercase">{aiConfig?.provider || 'gemini'}</span>
            </div>
            <div className="p-2 bg-[var(--bg)] rounded-xl border border-[var(--line)]">
              <span className="text-[var(--faint)] block">{isAr ? 'النموذج النشط' : 'Active Model'}</span>
              <span className="font-bold text-[var(--brand)] truncate block">{aiConfig?.model || 'gemini-3.8-flash'}</span>
            </div>
            <div className="p-2 bg-[var(--bg)] rounded-xl border border-[var(--line)]">
              <span className="text-[var(--faint)] block">{isAr ? 'زمن الاستجابة' : 'Latency'}</span>
              <span className="font-bold text-[var(--ink)]">
                {aiConfig?.lastLatencyMs ? `${aiConfig.lastLatencyMs} ms` : '-'}
              </span>
            </div>
            <div className="p-2 bg-[var(--bg)] rounded-xl border border-[var(--line)]">
              <span className="text-[var(--faint)] block">{isAr ? 'الطلبات الناجحة' : 'Requests'}</span>
              <span className="font-bold text-[var(--brand)]">
                {aiConfig?.successfulRequests || 0}/{aiConfig?.totalRequests || 0}
              </span>
            </div>
          </div>

          {/* Masked Key Display */}
          {aiConfig?.maskedKey && (
            <div className="p-2.5 bg-[var(--bg)] rounded-xl border border-[var(--line)] flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <Key className="w-3.5 h-3.5 text-[var(--brand)]" />
                <span className="text-[var(--muted)]">{isAr ? 'المفتاح المحفوظ في الخادم:' : 'Stored server key:'}</span>
                <code className="bg-[var(--surface)] px-2 py-0.5 rounded border border-[var(--line)] font-mono font-bold text-[var(--brand)]">
                  {aiConfig.maskedKey}
                </code>
              </div>

              {aiConfig.hasCustomKey && (
                <button
                  onClick={() => setShowConfirmRemove(true)}
                  className="text-xs text-red-600 hover:underline font-bold flex items-center gap-1"
                >
                  <Trash2 className="w-3 h-3" />
                  <span>{isAr ? 'حذف المفتاح' : 'Remove'}</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Guided Step Form */}
        <form onSubmit={handleSaveConfig} className="bg-[var(--surface)] rounded-3xl p-5 border border-[var(--line)] shadow-xs space-y-4">
          <h3 className="text-xs font-extrabold text-[var(--brand)] uppercase tracking-wider flex items-center gap-1.5">
            <span>⚙️</span>
            <span>{isAr ? 'إعداد مزود الذكاء الاصطناعي (خطوة بخطوة)' : 'Provider Configuration'}</span>
          </h3>

          {/* Step 1: Select Provider */}
          <div>
            <label className="text-xs font-bold text-[var(--muted)] block mb-1.5">
              1. {isAr ? 'اختر مزود الذكاء الاصطناعي:' : 'Choose AI Provider:'}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'gemini', label: 'Google Gemini', desc: 'الرسمي الموصى به' },
                { id: 'openai', label: 'OpenAI Compatible', desc: 'GPT-4o / Mini' },
                { id: 'custom', label: isAr ? 'مخصص (Custom)' : 'Custom Endpoint', desc: 'عنوان مخصص' },
              ].map((p) => (
                <button
                  type="button"
                  key={p.id}
                  onClick={() => {
                    setProvider(p.id as any);
                    setModel(providerModels[p.id]?.[0]?.id || 'gemini-3.8-flash');
                  }}
                  className={`p-3 rounded-2xl border text-start transition-all ${
                    provider === p.id
                      ? 'bg-[var(--brand)] text-white border-[var(--brand)] shadow-xs'
                      : 'bg-[var(--bg)] text-[var(--ink)] border-[var(--line)] hover:bg-[var(--surface-2)]'
                  }`}
                >
                  <div className="font-bold text-xs">{p.label}</div>
                  <div className="text-[10px] opacity-75">{p.desc}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Step 2: API Key Input & Security Notice */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-[var(--muted)]">
                2. {isAr ? 'مفتاح API الخاص بك (BYOK):' : 'API Key (Bring Your Own Key):'}
              </label>
              <a
                href={
                  provider === 'gemini'
                    ? 'https://aistudio.google.com/app/apikey'
                    : 'https://platform.openai.com/api-keys'
                }
                target="_blank"
                rel="noreferrer"
                className="text-[11px] font-bold text-[var(--accent)] hover:underline flex items-center gap-1"
              >
                <span>{isAr ? 'الحصول على مفتاح من الموقع الرسمي' : 'Get key from official site'}</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder={
                aiConfig?.hasCustomKey
                  ? isAr ? 'المفتاح مسجل بالفعل ومحمي بالخادم (اتركه فارغاً للإبقاء عليه)' : 'Key is saved. Leave blank to keep.'
                  : isAr ? 'أدخل أو الصق مفتاحك هنا (مثل: AIzaSy...)' : 'Paste API Key here...'
              }
              className="w-full text-xs sm:text-sm bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-2.5 text-[var(--ink)] font-mono focus:outline-none focus:ring-1 focus:ring-[var(--brand)]"
            />

            {/* BYOK Explanation Box */}
            <div className="mt-2 p-3 bg-[var(--brand-soft)]/70 rounded-xl border border-[var(--brand-line)] text-[11px] text-emerald-950 space-y-1">
              <div className="font-bold flex items-center gap-1.5 text-[var(--brand-ink)]">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>{isAr ? 'معايير الأمان وحماية المفتاح في ذاد:' : 'ZAD Security Commitment:'}</span>
              </div>
              <p className="leading-relaxed">
                {isAr
                  ? '• مفاتيح API تُرسل مشفرة إلى الخادم الداخلي حصراً ولا تُحفظ أبداً في متصفحك (localStorage).'
                  : '• Keys are encrypted and sent only to the isolated backend. Never exposed to browser storage.'}
              </p>
              <p className="leading-relaxed">
                {isAr
                  ? '• لا يتم استخدام مفتاحك إلا في طلبات الوصفات واقتراحات الطعام الخاصة بك، وتستطيع حذفه في أي لحظة.'
                  : '• Your key is used solely for your meal suggestions and can be deleted at any time.'}
              </p>
            </div>
          </div>

          {/* Step 3: Model Selection */}
          <div>
            <label className="text-xs font-bold text-[var(--muted)] block mb-1.5">
              3. {isAr ? 'اختر النموذج الأساسي:' : 'Select Default Model:'}
            </label>
            <select
              value={model}
              onChange={(e) => setModel(e.target.value)}
              className="w-full text-xs sm:text-sm bg-[var(--bg)] border border-[var(--line)] rounded-xl px-3 py-2.5 text-[var(--ink)] font-medium"
            >
              {providerModels[provider]?.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.label}
                </option>
              ))}
            </select>
          </div>

          {/* Advanced Collapsible Settings */}
          <div className="border-t border-[var(--bg)] pt-2">
            <button
              type="button"
              onClick={() => setShowAdvanced(!showAdvanced)}
              className="text-xs font-bold text-[var(--muted)] hover:text-[var(--brand)] flex items-center gap-1"
            >
              {showAdvanced ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
              <span>{isAr ? 'خيارات متقدمة (نموذج الطوارئ والـ Endpoint ورفع ملف التكوين)' : 'Advanced Configuration'}</span>
            </button>

            {showAdvanced && (
              <div className="mt-3 p-3.5 bg-[var(--bg)] rounded-2xl border border-[var(--line)] space-y-3 animate-fade-in">
                {/* Fallback Model */}
                <div>
                  <label className="text-xs font-bold text-[var(--muted)] block mb-1">
                    {isAr ? 'نموذج الطوارئ البديل (Fallback Model):' : 'Fallback Model:'}
                  </label>
                  <select
                    value={fallbackModel}
                    onChange={(e) => setFallbackModel(e.target.value)}
                    className="w-full text-xs bg-[var(--surface)] border border-[var(--line)] rounded-xl px-3 py-2 text-[var(--ink)]"
                  >
                    <option value="gemini-3.1-flash-lite">Gemini 3.1 Flash Lite</option>
                    <option value="gemini-3.8-flash">Gemini 3.8 Flash</option>
                  </select>
                </div>

                {/* Custom Endpoint */}
                {provider === 'custom' && (
                  <div>
                    <label className="text-xs font-bold text-[var(--muted)] block mb-1">
                      {isAr ? 'عنوان الـ API المخصص (Base URL):' : 'Custom Base URL:'}
                    </label>
                    <input
                      type="url"
                      value={customEndpoint}
                      onChange={(e) => setCustomEndpoint(e.target.value)}
                      placeholder="https://api.mycustomai.com/v1/chat/completions"
                      className="w-full text-xs bg-[var(--surface)] border border-[var(--line)] rounded-xl px-3 py-2 text-[var(--ink)]"
                    />
                  </div>
                )}

                {/* File Upload Configuration */}
                <div>
                  <label className="text-xs font-bold text-[var(--muted)] block mb-1">
                    {isAr ? 'رفع ملف إعدادات (JSON):' : 'Upload JSON Config File:'}
                  </label>
                  <input
                    type="file"
                    accept=".json"
                    onChange={handleFileUpload}
                    className="text-xs text-[var(--muted)] file:mr-2 file:py-1 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-[var(--brand)] file:text-white hover:file:bg-[var(--brand-deep)]"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Test Result Display */}
          {testResult && (
            <div
              className={`p-3.5 rounded-2xl border text-xs font-semibold flex items-start gap-2.5 ${
                testResult.ok
                  ? 'bg-[var(--brand-soft)] border-[var(--brand-line)] text-[var(--brand-ink)]'
                  : 'bg-[var(--danger-soft)] border-[var(--danger-line)] text-[var(--danger-ink)]'
              }`}
            >
              {testResult.ok ? (
                <CheckCircle2 className="w-4 h-4 text-[var(--brand-ink)] flex-shrink-0 mt-0.5" />
              ) : (
                <AlertCircle className="w-4 h-4 text-red-600 flex-shrink-0 mt-0.5" />
              )}
              <div className="leading-relaxed">
                <div>{testResult.message}</div>
                {testResult.ok && (
                  <div className="text-[10px] text-[var(--brand-ink)] mt-0.5 font-normal">
                    {isAr ? 'تم التحقق من النموذج وصلاحية المفتاح.' : 'Model validated successfully.'}
                  </div>
                )}
              </div>
            </div>
          )}

          {saveMessage && (
            <div
              className={`p-3 rounded-xl border text-xs font-bold text-center ${
                saveMessage.ok
                  ? 'bg-[var(--brand-soft)] border-[var(--brand-line)] text-[var(--brand-ink)]'
                  : 'bg-[var(--danger-soft)] border-[var(--danger-line)] text-[var(--danger-ink)]'
              }`}
            >
              {saveMessage.text}
            </div>
          )}

          {/* Action Buttons: Test Connection + Save Configuration */}
          <div className="pt-2 flex flex-col sm:flex-row items-center gap-2">
            <button
              type="button"
              onClick={handleTestConnection}
              disabled={isTesting}
              className="w-full sm:w-auto flex-1 py-2.5 px-4 rounded-xl bg-[var(--bg)] hover:bg-[var(--surface-2)] border border-[var(--line)] text-[var(--brand)] text-xs font-bold flex items-center justify-center gap-1.5 transition-colors"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isTesting ? 'animate-spin' : ''}`} />
              <span>{isTesting ? (isAr ? 'جارِ فحص الاتصال...' : 'Testing...') : isAr ? 'اختبار الاتصال بالنموذج' : 'Test Connection'}</span>
            </button>

            <button
              type="submit"
              disabled={isSaving}
              className="w-full sm:w-auto flex-1 py-2.5 px-5 rounded-xl bg-[var(--brand)] hover:bg-[var(--brand-deep)] text-white text-xs font-bold shadow-md transition-colors flex items-center justify-center gap-1.5"
            >
              <CheckCircle2 className="w-3.5 h-3.5 text-[var(--accent)]" />
              <span>{isSaving ? (isAr ? 'جارِ الحفظ...' : 'Saving...') : isAr ? 'حفظ وتفعيل النموذج' : 'Save & Activate'}</span>
            </button>
          </div>
        </form>

        {/* Confirmation modal for removing key */}
        {showConfirmRemove && (
          <div className="p-4 bg-[var(--danger-soft)] border border-[var(--danger-line)] rounded-2xl space-y-2 text-xs">
            <h4 className="font-bold text-red-950">
              {isAr ? 'هل أنت متأكد من حذف المفتاح الشخصي المحفوظ؟' : 'Remove saved credentials?'}
            </h4>
            <p className="text-[var(--danger-ink)]">
              {isAr
                ? 'سيتم حذف المفتاح من الخادم فوراً والعودة للإعدادات الأساسية لقاعدة معرفة ذاد.'
                : 'Your key will be removed from memory and ZAD will return to default settings.'}
            </p>
            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={handleRemoveKey}
                className="px-3 py-1.5 bg-red-600 text-white rounded-lg font-bold"
              >
                {isAr ? 'نعم، احذف المفتاح' : 'Yes, Remove'}
              </button>
              <button
                type="button"
                onClick={() => setShowConfirmRemove(false)}
                className="px-3 py-1.5 bg-[var(--surface)] border border-[var(--danger-line)] text-[var(--danger-ink)] rounded-lg font-semibold"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
