/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState, useMemo } from 'react';
import { useApp } from '../context/AppContext';
import {
  MapPin,
  Store,
  Phone,
  Clock,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  Tag,
  ArrowRight,
  ArrowLeft,
  X,
  Layers,
  Scale,
  Navigation,
  Crosshair,
  Search,
  ExternalLink,
  ShieldCheck,
} from 'lucide-react';
import L from 'leaflet';
import { StoreLocation } from '../types';
import { calculateUnitPrice, currencySymbol } from '../utils/rules';

function calculateHaversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth radius in km
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Number((R * c).toFixed(2));
}

export const StoreMapModal: React.FC = () => {
  const { isStoreMapOpen, setIsStoreMapOpen, stores, language, userPreferences } = useApp();
  const cur = currencySymbol(userPreferences.currency);
  const isAr = language === 'ar';

  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const accuracyCircleRef = useRef<L.Circle | null>(null);

  const [selectedStore, setSelectedStore] = useState<StoreLocation | null>(stores[0] || null);
  const [activeTab, setActiveTab] = useState<'map' | 'basket_compare'>('map');

  // Real Geolocation state
  const [userCoords, setUserCoords] = useState<{ lat: number; lng: number; accuracy?: number } | null>(null);
  const [userAddress, setUserAddress] = useState<string | null>(null);
  const [isLocating, setIsLocating] = useState<boolean>(false);
  const [geoError, setGeoError] = useState<string | null>(null);

  // Search location
  const [searchLocationQuery, setSearchLocationQuery] = useState('');
  const [isSearchingLocation, setIsSearchingLocation] = useState(false);

  // Fix Leaflet's default marker icons in webpack/vite environments
  useEffect(() => {
    delete (L.Icon.Default.prototype as any)._getIconUrl;
    L.Icon.Default.mergeOptions({
      iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
      iconUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
      shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
    });
  }, []);

  // Compute stores with dynamic distance if user coordinates are known
  const dynamicStores = useMemo(() => {
    if (!userCoords) return stores;
    return stores.map((s) => ({
      ...s,
      distanceKm: calculateHaversineDistance(userCoords.lat, userCoords.lng, s.lat, s.lng),
    }));
  }, [stores, userCoords]);

  // Reverse Geocoding helper using OpenStreetMap Nominatim
  const reverseGeocode = async (lat: number, lng: number) => {
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}&zoom=16&addressdetails=1`,
        { headers: { 'User-Agent': 'ZAD-Food-App/1.0' } }
      );
      if (res.ok) {
        const data = await res.json();
        const addr = data.address;
        const placeName =
          addr.road ||
          addr.suburb ||
          addr.neighbourhood ||
          addr.city ||
          addr.town ||
          addr.state ||
          data.display_name.split(',')[0];
        const cityName = addr.city || addr.town || addr.state || '';
        setUserAddress(cityName ? `${placeName}، ${cityName}` : placeName);
      }
    } catch {
      setUserAddress(isAr ? 'موقعك الفعلي المحدد' : 'Detected Real Location');
    }
  };

  // Trigger GPS Geolocation
  const handleLocateMe = () => {
    if (!navigator.geolocation) {
      setGeoError(isAr ? 'متصفحك لا يدعم تحديد الموقع الجغرافي.' : 'Geolocation is not supported by your browser.');
      return;
    }

    setIsLocating(true);
    setGeoError(null);

    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setIsLocating(false);
        const { latitude, longitude, accuracy } = pos.coords;
        const coords = { lat: latitude, lng: longitude, accuracy };
        setUserCoords(coords);
        reverseGeocode(latitude, longitude);

        if (mapInstanceRef.current) {
          mapInstanceRef.current.flyTo([latitude, longitude], 15, { duration: 1.5 });

          // Remove old markers if any
          if (userMarkerRef.current) userMarkerRef.current.remove();
          if (accuracyCircleRef.current) accuracyCircleRef.current.remove();

          // Add pulsing custom user marker
          const userIcon = L.divIcon({
            className: 'zad-user-pin',
            html: `
              <div style="position: relative; width: 28px; height: 28px;">
                <div style="position: absolute; inset: -4px; background-color: rgba(24, 78, 56, 0.25); border-radius: 9999px;"></div>
                <div style="width: 28px; height: 28px; background-color: #184E38; border: 3px solid #FAF7F2; border-radius: 9999px; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 12px rgba(0,0,0,0.3); color: white; font-size: 13px;">
                  📍
                </div>
              </div>
            `,
            iconSize: [28, 28],
            iconAnchor: [14, 14],
          });

          userMarkerRef.current = L.marker([latitude, longitude], { icon: userIcon })
            .addTo(mapInstanceRef.current)
            .bindPopup(
              `<div style="font-family: inherit; direction: ${isAr ? 'rtl' : 'ltr'}; font-weight: bold; color: #184E38;">` +
                (isAr ? '📍 أنت هنا (موقعك الفعلي المحدد)' : '📍 You are here (Real Position)') +
                `</div>`
            )
            .openPopup();

          if (accuracy && accuracy < 500) {
            accuracyCircleRef.current = L.circle([latitude, longitude], {
              radius: accuracy,
              color: '#184E38',
              fillColor: '#2A9D8F',
              fillOpacity: 0.15,
              weight: 1,
            }).addTo(mapInstanceRef.current);
          }
        }
      },
      (err) => {
        setIsLocating(false);
        setGeoError(
          isAr
            ? 'تعذر الوصول لموقعك. يرجى تفعيل إذن الموقع الجغرافي بالمتصفح أو البحث يدوياً باسم مدينتك.'
            : 'Could not access location. Please enable GPS permissions or search manually.'
        );
      },
      { enableHighAccuracy: true, timeout: 9000, maximumAge: 30000 }
    );
  };

  // Search Address / City
  const handleSearchLocation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchLocationQuery.trim()) return;

    setIsSearchingLocation(true);
    setGeoError(null);
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
          searchLocationQuery.trim()
        )}&limit=1`,
        { headers: { 'User-Agent': 'ZAD-Food-App/1.0' } }
      );
      if (res.ok) {
        const results = await res.json();
        if (results && results.length > 0) {
          const lat = parseFloat(results[0].lat);
          const lng = parseFloat(results[0].lon);
          setUserCoords({ lat, lng });
          setUserAddress(results[0].display_name.split(',').slice(0, 2).join('، '));

          if (mapInstanceRef.current) {
            mapInstanceRef.current.flyTo([lat, lng], 14, { duration: 1.5 });
          }
        } else {
          setGeoError(isAr ? 'لم نتمكن من العثور على هذا المكان. جرّب كتابة اسم المدينة أو الحي.' : 'Location not found.');
        }
      }
    } catch {
      setGeoError(isAr ? 'تعذر البحث عن العنوان حالياً.' : 'Search service unavailable.');
    } finally {
      setIsSearchingLocation(false);
    }
  };

  // Initialize Leaflet Map
  useEffect(() => {
    if (!isStoreMapOpen || activeTab !== 'map' || !mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      const initialLat = userCoords?.lat || 30.045;
      const initialLng = userCoords?.lng || 31.235;

      const map = L.map(mapContainerRef.current).setView([initialLat, initialLng], 14);
      mapInstanceRef.current = map;

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap contributors',
      }).addTo(map);

      // Add pins for stores
      stores.forEach((store) => {
        const marker = L.marker([store.lat, store.lng]).addTo(map);
        marker.bindPopup(`
          <div style="font-family: inherit; direction: ${isAr ? 'rtl' : 'ltr'}; text-align: ${isAr ? 'right' : 'left'}; min-width: 160px;">
            <b style="color: #184E38; font-size: 13px;">${isAr ? store.name : store.nameEn}</b><br/>
            <span style="font-size: 11px; color: #635A52;">${store.address}</span><br/>
            <span style="font-size: 10px; color: #E07A5F; font-weight: bold;">${store.openingHours}</span>
          </div>
        `);
        marker.on('click', () => {
          setSelectedStore(store);
        });
      });
    }

    const timer = setTimeout(() => {
      mapInstanceRef.current?.invalidateSize();
    }, 200);

    return () => {
      clearTimeout(timer);
    };
  }, [isStoreMapOpen, activeTab, stores]);

  // Clean up map when modal closes
  useEffect(() => {
    if (!isStoreMapOpen && mapInstanceRef.current) {
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
      userMarkerRef.current = null;
      accuracyCircleRef.current = null;
    }
  }, [isStoreMapOpen]);

  /* ✅ إصلاح جوهري: كانت مقارنة السلة بيانات ثابتة مكتوبة يدوياً لا علاقة لها بالمتاجر الفعلية.
     الآن تُبنى تلقائياً من كتالوجات المتاجر الحقيقية: نطابق المنتجات المشتركة بينها
     ونحسب سعر الوحدة لكل متجر ونحدد الأوفر فعلياً — وبعملة المستخدم. */
  const basketComparisonItems = React.useMemo(() => {
    const norm = (n: string) => n.toLowerCase().replace(/[أإآ]/g, 'ا').replace(/ة/g, 'ه').trim();
    const byName: { [name: string]: { storeId: string; storeName: string; storeNameEn: string; price: number; unitPrice: number }[] } = {};

    stores.forEach((st) => {
      st.products.forEach((prod) => {
        const key = norm(prod.name);
        if (!key) return;
        const unitCalc = calculateUnitPrice(prod.price, prod.packageSize, prod.unit);
        if (!byName[key]) byName[key] = [];
        byName[key].push({
          storeId: st.id,
          storeName: st.name,
          storeNameEn: st.nameEn,
          price: prod.price,
          unitPrice: Math.round(unitCalc.normalizedPrice * 10) / 10,
        });
      });
    });

    return Object.keys(byName)
      .filter((key) => byName[key].length >= 2) // نعرض فقط ما يمكن مقارنته فعلاً بين متجرين+
      .slice(0, 6)
      .map((key) => {
        const prices = byName[key];
        const best = Math.min(...prices.map((p) => p.unitPrice));
        return {
          name: stores.flatMap((st) => st.products).find((p) => norm(p.name) === key)?.name || key,
          size: stores
            .flatMap((st) => st.products)
            .find((p) => norm(p.name) === key)?.unit || '',
          prices: prices.map((p) => ({ ...p, isBest: p.unitPrice === best })),
        };
      });
  }, [stores]);


  if (!isStoreMapOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-5 overflow-y-auto animate-fade-in">
      <div className="bg-[var(--bg)] rounded-3xl max-w-4xl w-full max-h-[92vh] overflow-y-auto border border-[var(--line)] shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[var(--line)] bg-[var(--surface)] rounded-t-3xl flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-[var(--brand-soft-strong)] text-[var(--brand-ink)] flex items-center justify-center">
              <MapPin className="w-5 h-5 text-[var(--brand-ink)]" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base sm:text-lg font-extrabold text-[var(--brand)]">
                  {isAr ? 'الموقع الفعلي على الخريطة والمتاجر' : 'Real Location & Nearby Stores'}
                </h2>
                <span className="text-[10px] bg-[var(--brand-soft)] text-[var(--brand-ink)] border border-[var(--brand-line)] px-2 py-0.5 rounded-full font-bold">
                  {isAr ? 'GPS وتحديد حي' : 'GPS Live Detection'}
                </span>
              </div>
              <p className="text-xs text-[var(--muted)]">
                {isAr
                  ? 'حدد موقعك الفعلي بدقة وتعرّف على أقرب الأسواق وقارن أسعار السلع بالكيلو'
                  : 'Detect your actual location, find nearest supermarkets, and compare basket prices'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsStoreMapOpen(false)}
            className="w-8 h-8 rounded-full bg-[var(--bg)] text-[var(--muted)] hover:bg-[var(--line)] flex items-center justify-center font-bold"
            aria-label={isAr ? 'إغلاق' : 'Close'}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Real Location Controls Bar */}
        <div className="bg-[var(--surface-2)] px-4 py-3 border-b border-[var(--line)] flex flex-wrap items-center justify-between gap-3">
          {/* Quick Locate Button & Detected Address */}
          <div className="flex items-center gap-2 flex-1 min-w-[260px]">
            <button
              onClick={handleLocateMe}
              disabled={isLocating}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[var(--brand)] text-white text-xs font-bold hover:bg-[var(--brand-deep)] transition-all shadow-xs disabled:opacity-60 flex-shrink-0"
            >
              <Crosshair className={`w-3.5 h-3.5 ${isLocating ? 'animate-spin' : ''}`} />
              <span>{isLocating ? (isAr ? 'جاري تحديد موقعك...' : 'Locating...') : (isAr ? 'حدد موقعي الفعلي الآن' : 'Locate Me Now')}</span>
            </button>

            {userAddress ? (
              <div className="flex items-center gap-1.5 text-xs text-[var(--brand)] bg-[var(--surface)] px-3 py-1 rounded-xl border border-[var(--brand-line)]">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                <span className="font-bold">{isAr ? 'موقعك:' : 'Your Location:'}</span>
                <span className="truncate max-w-[200px] sm:max-w-xs">{userAddress}</span>
              </div>
            ) : (
              <span className="text-xs text-[var(--muted)]">
                {isAr ? 'انقر على الزر لتحديد مكانك الفعلي عبر الـ GPS' : 'Click to detect your real GPS location'}
              </span>
            )}
          </div>

          {/* Search Location Form */}
          <form onSubmit={handleSearchLocation} className="flex items-center gap-1 flex-shrink-0">
            <input
              type="text"
              placeholder={isAr ? 'ابحث عن مدينة أو حي...' : 'Search city or district...'}
              value={searchLocationQuery}
              onChange={(e) => setSearchLocationQuery(e.target.value)}
              className="px-3 py-1.5 rounded-xl bg-[var(--surface)] border border-[var(--line)] text-xs text-[var(--ink)] w-40 sm:w-48 focus:outline-none focus:ring-1 focus:ring-[var(--brand)]"
            />
            <button
              type="submit"
              disabled={isSearchingLocation}
              className="p-1.5 rounded-xl bg-[var(--surface)] border border-[var(--line)] text-[var(--brand)] hover:bg-[var(--bg)] text-xs font-bold transition-colors"
              title={isAr ? 'بحث' : 'Search'}
            >
              <Search className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>

        {geoError && (
          <div className="mx-4 mt-3 p-2.5 rounded-xl bg-[var(--warn-soft)] border border-[var(--warn-line)] text-[var(--warn-ink)] text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 flex-shrink-0 text-[var(--warn-ink)]" />
            <span>{geoError}</span>
          </div>
        )}

        {/* View Switcher Tabs */}
        <div className="px-5 pt-3 flex gap-2">
          <button
            onClick={() => setActiveTab('map')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'map'
                ? 'bg-[var(--brand)] text-white shadow-xs'
                : 'bg-[var(--surface)] text-[var(--muted)] border border-[var(--line)]'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>{isAr ? 'الخريطة والأسواق القريبة' : 'Map & Stores'}</span>
          </button>

          <button
            onClick={() => setActiveTab('basket_compare')}
            className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'basket_compare'
                ? 'bg-[var(--brand)] text-white shadow-xs'
                : 'bg-[var(--surface)] text-[var(--muted)] border border-[var(--line)]'
            }`}
          >
            <Scale className="w-3.5 h-3.5" />
            <span>{isAr ? 'مقارنة سعر السلة وسعر الكيلو' : 'Basket & Unit Price Compare'}</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-4 sm:p-5 flex-1">
          {activeTab === 'map' ? (
            <div className="space-y-4">
              {/* Map Container */}
              <div className="h-64 sm:h-80 w-full rounded-2xl overflow-hidden border border-[var(--line)] shadow-inner relative z-10">
                <div ref={mapContainerRef} className="w-full h-full" />
              </div>

              {/* Stores Horizontal Picker */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-[var(--muted)]">
                    {isAr ? 'المتاجر والأسواق في منطقتك (اختر لعرض الكتالوج والأسعار):' : 'Select a store to view items:'}
                  </span>
                  {userCoords && (
                    <span className="text-[11px] text-[var(--brand-ink)] font-bold bg-[var(--brand-soft)] px-2 py-0.5 rounded-md border border-[var(--brand-line)]">
                      {isAr ? 'المسافات محسوبة من موقعك الفعلي' : 'Distances calculated from your GPS'}
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-2.5">
                  {dynamicStores.map((st) => (
                    <div
                      key={st.id}
                      onClick={() => {
                        setSelectedStore(st);
                        if (mapInstanceRef.current) {
                          mapInstanceRef.current.setView([st.lat, st.lng], 16);
                        }
                      }}
                      className={`p-3 rounded-2xl border cursor-pointer transition-all ${
                        selectedStore?.id === st.id
                          ? 'bg-[var(--surface)] border-[var(--brand)] ring-2 ring-[var(--brand)]/20 shadow-xs'
                          : 'bg-[var(--surface)]/80 border-[var(--line)] hover:bg-[var(--surface)]'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <h4 className="font-bold text-xs text-[var(--ink)] line-clamp-1">{isAr ? st.name : st.nameEn}</h4>
                        <span className="text-[10px] font-bold text-[var(--brand-ink)] bg-[var(--brand-soft)] px-1.5 py-0.5 rounded">
                          {st.distanceKm} {isAr ? 'كم' : 'km'}
                        </span>
                      </div>
                      <div className="text-[10px] text-[var(--faint)] mt-1 line-clamp-1">{st.address}</div>
                      <div className="text-[10px] text-[var(--accent)] font-semibold mt-1">{st.openingHours}</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Selected Store Catalog */}
              {selectedStore && (
                <div className="bg-[var(--surface)] rounded-2xl p-4 border border-[var(--line)] space-y-3">
                  <div className="flex flex-wrap items-center justify-between border-b border-[var(--bg)] pb-3 gap-2">
                    <div>
                      <div className="flex items-center gap-2">
                        <h3 className="font-extrabold text-sm sm:text-base text-[var(--brand)]">
                          {isAr ? selectedStore.name : selectedStore.nameEn}
                        </h3>
                        <span className="text-[10px] bg-[var(--brand-soft)] text-[var(--brand-ink)] border border-[var(--brand-line)] px-2 py-0.5 rounded-full font-semibold">
                          {selectedStore.verifiedTag === 'verified_live'
                            ? isAr ? 'بيانات أسعار موثقة ومحدثة' : 'Verified Live Data'
                            : isAr ? 'أسعار استرشادية' : 'Estimated Pricing'}
                        </span>
                      </div>
                      <p className="text-xs text-[var(--muted)] mt-0.5">{selectedStore.address}</p>
                    </div>

                    {/* Navigation Button */}
                    <a
                      href={`https://www.google.com/maps/dir/?api=1&destination=${selectedStore.lat},${selectedStore.lng}${
                        userCoords ? `&origin=${userCoords.lat},${userCoords.lng}` : ''
                      }`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[var(--accent)] text-white text-xs font-bold hover:bg-[var(--accent-deep)] shadow-xs transition-colors"
                    >
                      <Navigation className="w-3.5 h-3.5" />
                      <span>{isAr ? 'الاتجاهات (Google Maps)' : 'Directions'}</span>
                      <ExternalLink className="w-3 h-3 opacity-80" />
                    </a>
                  </div>

                  {/* Store Products */}
                  <div className="space-y-2">
                    <h4 className="text-xs font-bold text-[var(--muted)]">
                      {isAr ? 'عروض وأسعار السلع المتوفرة بالمتجر:' : 'Store Catalog & Unit Prices:'}
                    </h4>

                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
                      {selectedStore.products.map((item) => {
                        const unitCalc = calculateUnitPrice(item.price, item.packageSize, item.unit);
                        return (
                          <div
                            key={item.id}
                            className="p-2.5 rounded-xl bg-[var(--bg)] border border-[var(--line)] flex items-center justify-between text-xs"
                          >
                            <div>
                              <div className="font-bold text-[var(--ink)]">{item.name}</div>
                              <div className="text-[10px] text-[var(--faint)]">{item.packageSize} {item.unit}</div>
                              {unitCalc.standardUnit && (
                                <div className="text-[10px] text-[var(--brand-ink)] font-semibold mt-0.5">
                                  {Math.round(unitCalc.normalizedPrice)} {cur} / {unitCalc.standardUnit}
                                </div>
                              )}
                            </div>
                            <div className="text-right">
                              <span className="font-extrabold text-[var(--brand)] text-sm">
                                {item.price} {cur}
                              </span>
                              {item.isOffer && (
                                <div className="text-[10px] text-[var(--brand-ink)] font-bold">
                                  {isAr ? 'عرض خاص' : 'Special Offer'}
                                </div>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ) : (
            /* Basket & Unit Price Comparison View */
            <div className="space-y-4">
              <div className="bg-[var(--brand-soft)] rounded-2xl p-3.5 border border-[var(--brand-line)] text-xs text-[var(--brand-ink)] flex items-start gap-2">
                <ShieldCheck className="w-4 h-4 flex-shrink-0 text-[var(--brand-ink)] mt-0.5" />
                <div>
                  <div className="font-bold">
                    {isAr ? 'أداة مقارنة السلة وسعر الكيلو الشفافة' : 'Transparent Basket & Unit-Price Comparator'}
                  </div>
                  <div className="text-[11px] text-[var(--brand-ink)] mt-0.5">
                    {isAr
                      ? 'تقارن هذه الأداة سعر السلع الأساسية بين المتاجر القريبة منك، وتحسب لك السعر الفعلي لكل كجم أو لتر لمساعدتك في اتخاذ القرار الأوفر دون تضليل بأحجام العبوات.'
                      : 'Compares real shelf prices and normalizes to standard unit prices (per kg / per liter) to reveal real value.'}
                  </div>
                </div>
              </div>

              {/* Comparison Table */}
              <div className="bg-[var(--surface)] rounded-2xl border border-[var(--line)] overflow-hidden shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-xs text-right">
                    <thead className="bg-[var(--bg)] text-[var(--muted)] border-b border-[var(--line)] font-bold">
                      <tr>
                        <th className="p-3 text-right">{isAr ? 'السلعة والعبوة' : 'Item & Size'}</th>
                        {stores.map((st) => (
                          <th key={st.id} className="p-3 text-center">
                            <div>{isAr ? st.name : st.nameEn}</div>
                            <div className="text-[10px] font-normal text-[var(--faint)]">{st.distanceKm} كم</div>
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-[var(--bg)]">
                      {basketComparisonItems.map((item, idx) => (
                        <tr key={idx} className="hover:bg-[var(--warn-soft)]/30 transition-colors">
                          <td className="p-3">
                            <div className="font-bold text-[var(--ink)]">{item.name}</div>
                            <div className="text-[10px] text-[var(--faint)]">{item.size}</div>
                          </td>
                          {item.prices.map((p, pIdx) => (
                            <td key={pIdx} className="p-3 text-center">
                              <div
                                className={`inline-block px-2.5 py-1 rounded-lg ${
                                  p.isBest
                                    ? 'bg-[var(--brand-soft-strong)] text-[var(--brand-ink)] font-extrabold border border-[var(--brand-line)]'
                                    : 'text-[var(--ink)]'
                                }`}
                              >
                                <div>{p.price} {cur}</div>
                                <div className="text-[10px] opacity-75">
                                  ({p.unitPrice} {cur})
                                </div>
                                {p.isBest && (
                                  <span className="text-[9px] text-[var(--brand-ink)] font-bold block">
                                    {isAr ? 'الأوفر' : 'Best'}
                                  </span>
                                )}
                              </div>
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
