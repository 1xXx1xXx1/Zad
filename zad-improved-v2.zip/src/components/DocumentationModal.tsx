/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { FileText, CheckCircle2, Shield, Compass, BookOpen, Layers, X } from 'lucide-react';

export const DocumentationModal: React.FC = () => {
  const { isDeliverablesOpen, setIsDeliverablesOpen, language } = useApp();
  const isAr = language === 'ar';

  const [activeSection, setActiveSection] = useState<number>(1);

  if (!isDeliverablesOpen) return null;

  const deliverables = [
    {
      id: 1,
      title: isAr ? '1. وثيقة متطلبات المنتج (PRD)' : '1. Product Requirements (PRD)',
      content: isAr ? `
### وثيقة متطلبات المنتج — ذاد (ZAD)
- **الرؤية:** أن لا يحتار أحد أمام سؤال «هآكل إيه؟»، ولا يشعر أن الأكل الجيد رفاهية لا يقدر عليها.
- **الرسالة:** نساعد كل شخص أن يصنع من المتاح له ما يكفيه ويسعده — باختيارات أذكى، ومصاريف أوضح، وطعام لا يضيع.
- **الشعار الأساسي:** ذاد — الخير في اللي عندك.
- **الوعد الداعم:** ذاد معك، من أول فكرة لحد آخر لقمة.
- **الجمهور المستهدف:** الطلاب والمغتربون، من يعيشون بمفردهم، أصحاب المطابخ المحدودة (بدون نار/بدون فرن)، والأسر الباحثة عن ضبط ميزانية الطعام وتقليل الهدر.
- **النطاق الشامل:** 18 متطلباً رئيساً متصلين بدون جزر معزولة (المخزن، الاقتراحات، الطبخ خطوة بخطوة، النواقص، قائمة التسوق، خريطة المتاجر، مقارنة السلة وسعر الكيلو، الميزانية، وتفضيلات المستخدم).
      ` : `
### Product Requirements Document (PRD) — ZAD
- **Vision:** To make everyday food decisions easier, so no one feels that eating well is out of reach.
- **Mission:** We help people make the most of what they have through smarter food choices, clearer spending, and less waste.
- **Primary Slogan:** ZAD — There is goodness in what you have.
- **Promise:** ZAD is with you, from the first idea to the last bite.
- **18 Core Requirements:** Connected journey from pantry items to recipes, cook mode, missing ingredients, shopping list, nearby store map, and spending tracking.
      `,
    },
    {
      id: 2,
      title: isAr ? '2. رحلة المستخدم وهندسة المعلومات (IA)' : '2. User Flows & IA',
      content: isAr ? `
### رحلة المستخدم المتصلة (End-to-End User Journey)
1. **المخزن والمكونات:** إدخال المكونات المتاحة (نصياً، أزرار سريعة، أو فحص بالصورة).
2. **اقتراح الوجبة الذكية:** «أنقذني بوجبة» يقدم 3 خيارات عملية (الأسرع تحضيراً، الأوفر تكلفة، والأفضل استغلالاً للمتاح).
3. **طريقة التحضير (وضع الطاهي):** عرض خطوة بخطوة، خط كبير مريح، قراءة صوتية، ومؤقت طهي ذكي.
4. **النواقص والتسوق:** حساب المكونات الناقصة تلقائياً وإضافتها لقائمة التسوق دون تكرار.
5. **المتاجر والأسعار:** عرض المتاجر القريبة على خريطة حية تفاعلية ومقارنة سعر الكيلو والسلة الإجمالية.
6. **الميزانية والمصروفات:** تسجيل النفقات، مقارنة المخطط بالفعلي، واحتساب تكلفة الحصة بروح مطمئنة لا تُشعر المستخدم بالذنب.
      ` : `
### Connected User Journey
1. **Ingredients:** Fast entry or photo recognition.
2. **AI Suggestion:** "Save Me a Meal" 3 flows (Fastest, Cheapest, Best Pantry Use).
3. **Cook Mode:** Step-by-step with large readable font, audio speech, and timer.
4. **Missing to List:** Smart difference calculation (Recipe - Pantry).
5. **Stores & Map:** Real Leaflet map, verified catalogs, and basket comparison.
6. **Budget & Spending:** Planned vs actual tracker with dignity.
      `,
    },
    {
      id: 3,
      title: isAr ? '3. الهوية البصرية ونظام التصميم' : '3. Brand & Design Tokens',
      content: isAr ? `
### الهوية البصرية ونظام التصميم
- **اسم العلامة:** ذاد (ZAD) — مستوحى من الزاد وما يتقوى به المسافر في رحلته.
- **الألوان الأساسية:**
  - **الأخضر الغابي العميق (#184E38):** يمثل الذكاء الغذائي، الأمان، والثقة.
  - **البيج الدافئ (#FAF7F2 / #F5EFE6):** يوفر خلفية مريحة للعين تبث الدفء والسكينة.
  - **المشمشي الهادئ (#E07A5F):** للإجراءات الرئيسية واللمسات الحيوية المشجعة.
  - **الرمادي الفحمي الداكن (#2C2621):** للنصوص المقروءة بوضوح وتباين عالي.
- **الخطوط:** خط 'Tajawal' العربي الأصيل مع دعم كامل وفوري لاتجاه اليمين لليسار (RTL) و'Plus Jakarta Sans' للإنجليزية.
      ` : `
### Brand Identity & Design Tokens
- **Palette:** Forest Green (#184E38), Warm Cream (#FAF7F2), Apricot Accent (#E07A5F).
- **Typography:** Tajawal (Arabic RTL) and Plus Jakarta Sans (English LTR).
- **Voice:** Warm, reassuring, empathetic human companion.
      `,
    },
    {
      id: 4,
      title: isAr ? '4. معمارية الخادم وتكامل الذكاء الاصطناعي' : '4. Architecture & AI Integration',
      content: isAr ? `
### معمارية الخادم وتكامل الذكاء الاصطناعي الآمن
- **فصل الخادم والعميل (Client/Server Separation):** يتم استدعاء نماذج الذكاء الاصطناعي حصرياً من جانب الخادم (Express في \`server.ts\` و\`server/aiProvider.ts\`).
- **حظر تام لتسريب المفاتيح:** لا يتم تخزين مفاتيح API إطلاقاً في متصفح العميل (localStorage / sessionStorage) ولا تظهر في الحزم المترجمة.
- **طبقة التجريد (Provider Abstraction Layer):** تدعم Google Gemini (\`@google/genai\`)، نماذج OpenAI-compatible، والعناوين المخصصة (Custom Endpoints).
- **وضع BYOK الشفاف:** إمكانية إدخال المفتاح الشخصي مع اختبار الاتصال الحي وقياس زمن الاستجابة (Latency ms) قبل الحفظ.
- **قاعدة المعرفة الذاتية (Curated Fallback):** في حال عدم توفر اتصال بالإنترنت أو عدم ضبط مفتاح، يقدم ذاد اقتراحات موثقة ومجربة مع إشعار شفاف بوضعية البيانات.
      ` : `
### Server Architecture & AI Provider Layer
- Full-stack Express + Vite architecture.
- Server-side only GoogleGenAI SDK calls; keys never exposed to browser.
- Multi-provider abstraction: Google Gemini, OpenAI, custom endpoints.
- Bring Your Own Key (BYOK) with live ping test, latency measurement, and masking.
- Graceful offline curated culinary knowledge fallback.
      `,
    },
    {
      id: 5,
      title: isAr ? '5. خطة الجودة ونتائج الفحص (QA & Testing)' : '5. QA & Unit Test Results',
      content: isAr ? `
### خطة الجودة والفحص الآلي (QA & Unit Tests)
- **فحص المنطق المجرد (Unit Testing):** تم بناء واختبار المنطق النقي في \`src/utils/rules.ts\` عبر \`node:test\` و\`node:assert/strict\`، ونجحت جميع الاختبارات بنسبة 100%:
  - حساب الميزانية المخططة والفعلية ونسبة الاستهلاك.
  - حساب وتوحيد سعر الكيلو واللتر (Unit-Price comparison).
  - تحديد حالة صلاحية المكونات (منتهية، تنتهي خلال يومين، طازجة).
  - استنتاج النواقص ومطابقة المخزن مع مكونات الوصفات.
- **فحص الأجهزة والشاشات:** دعم كامل لشاشات الهواتف المحمولة والأجهزة اللوحية والمكتبية.
      ` : `
### QA & Test Results
- Pure rules tested with node:test (100% pass rate in 379ms).
- Budget status, unit price normalization, expiry classification, and missing ingredient deduction verified.
      `,
    },
    {
      id: 6,
      title: isAr ? '6. خارطة الطريق والمراحل القادمة' : '6. Roadmap & Future Scope',
      content: isAr ? `
### خارطة طريق منتج ذاد (Product Roadmap)
- **المرحلة 1 (المنفذة بالكامل):** الهوية، المخزن، مكتبة الوصفات، اسأل ذاد، وضع الطاهي، قائمة التسوق، ميزانية الطعام، الخريطة التفاعلية، وإدارة مزودي الذكاء الاصطناعي.
- **المرحلة 2:** مزامنة الحسابات السحابية ومشاركة سلة التسوق بين أفراد المنزل وسكان السكن المشترك.
- **المرحلة 3:** شراكات استيراد عروض المتاجر الحية ومنافذ بيع الفائض الغذائي بتخفيضات كبرى (Surplus Food Reduction).
- **المرحلة 4:** التحكم الصوتي الكامل بدون لمس أثناء الطهي (Voice Hands-Free Cook Mode).
      ` : `
### Product Roadmap
- Phase 1 (Complete): Core Brand, Pantry, Recipes, Ask ZAD, Cook Mode, Shopping, Budget, Store Map, AI Provider Management.
- Phase 2: Cloud sync and multi-user household lists.
- Phase 3: Retailer partnerships & surplus food reduction.
- Phase 4: Hands-free voice-activated cook mode.
      `,
    },
  ];

  const currentDeliv = deliverables.find((d) => d.id === activeSection) || deliverables[0];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-6 overflow-y-auto animate-fade-in">
      <div className="bg-[var(--bg)] rounded-3xl max-w-3xl w-full max-h-[92vh] overflow-y-auto border border-[var(--line)] shadow-2xl flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-[var(--line)] bg-[var(--surface)] rounded-t-3xl flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-[var(--brand)] text-white flex items-center justify-center">
              <FileText className="w-5 h-5 text-[var(--accent)]" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-[var(--brand)]">
                {isAr ? 'مستندات وتوثيق مشروع ذاد (المخرجات الـ 12)' : 'ZAD Master Product Deliverables'}
              </h2>
              <p className="text-xs text-[var(--muted)]">
                {isAr ? 'الوثائق الكاملة للرؤية، المعمارية، الأمان، والاختبارات' : 'Full specification, architecture, QA, and roadmap'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsDeliverablesOpen(false)}
            className="w-8 h-8 rounded-full bg-[var(--bg)] text-[var(--muted)] hover:bg-[var(--line)] flex items-center justify-center font-bold"
            aria-label={isAr ? 'إغلاق' : 'Close'}
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Tab Selector */}
        <div className="p-3 border-b border-[var(--line)] bg-white/70 overflow-x-auto flex gap-1.5 scrollbar-none">
          {deliverables.map((d) => (
            <button
              key={d.id}
              onClick={() => setActiveSection(d.id)}
              className={`flex-shrink-0 px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeSection === d.id
                  ? 'bg-[var(--brand)] text-white shadow-xs'
                  : 'bg-[var(--bg)] text-[var(--muted)] hover:bg-[var(--surface-2)]'
              }`}
            >
              {d.title}
            </button>
          ))}
        </div>

        {/* Content Viewer */}
        <div className="p-5 sm:p-6 flex-1 overflow-y-auto">
          <div className="bg-[var(--surface)] rounded-2xl p-5 border border-[var(--line)] shadow-xs text-xs sm:text-sm text-[var(--ink)] leading-relaxed whitespace-pre-line">
            {currentDeliv.content}
          </div>
        </div>

        {/* Footer */}
        <div className="p-3.5 bg-[var(--surface)] border-t border-[var(--line)] rounded-b-3xl text-center text-xs text-[var(--muted)] font-semibold">
          {isAr ? 'ذاد — الخير في اللي عندك' : 'ZAD — There is goodness in what you have.'}
        </div>
      </div>
    </div>
  );
};
