/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  Volume2,
  VolumeX,
  Play,
  Pause,
  RotateCcw,
  ChevronRight,
  ChevronLeft,
  X,
  Clock,
  Lightbulb,
  PartyPopper,
  AlertTriangle,
} from 'lucide-react';

export const CookModeModal: React.FC = () => {
  const { isCookModeOpen, activeCookRecipe, closeCookMode, language, rateRecipe, recordCookedMeal } = useApp();
  const isAr = language === 'ar';

  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [timerSecondsLeft, setTimerSecondsLeft] = useState<number | null>(null);
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [isFinished, setIsFinished] = useState(false);
  const [userRating, setUserRating] = useState<number>(0);

  const wakeLockRef = useRef<any>(null);
  const steps = activeCookRecipe?.steps || [];
  const currentStep = steps[currentStepIndex];
  const hasRecipe = Boolean(activeCookRecipe);
  const hasSteps = steps.length > 0;

  /* Reset when recipe opens */
  useEffect(() => {
    if (isCookModeOpen) {
      setCurrentStepIndex(0);
      setIsFinished(false);
      setIsTimerRunning(false);
      // ✅ استعادة التقييم السابق إن وجد (كان دائماً يبدأ من 5)
      setUserRating(activeCookRecipe?.userRating || 0);
      setTimerSecondsLeft(activeCookRecipe?.steps?.[0]?.timerSeconds || null);
    }
  }, [isCookModeOpen, activeCookRecipe]);

  /* Timer per step */
  useEffect(() => {
    if (currentStep?.timerSeconds) {
      setTimerSecondsLeft(currentStep.timerSeconds);
      setIsTimerRunning(false);
    } else {
      setTimerSecondsLeft(null);
      setIsTimerRunning(false);
    }
  }, [currentStepIndex]);

  /* Countdown */
  useEffect(() => {
    let interval: any = null;
    if (isTimerRunning && timerSecondsLeft !== null && timerSecondsLeft > 0) {
      interval = setInterval(() => {
        setTimerSecondsLeft((prev) => (prev !== null && prev > 0 ? prev - 1 : 0));
      }, 1000);
    } else if (timerSecondsLeft === 0 && isTimerRunning) {
      setIsTimerRunning(false);
      try {
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = audioCtx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(587.33, audioCtx.currentTime);
        osc.connect(audioCtx.destination);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.5);
      } catch {
        /* audio unavailable */
      }
    }
    return () => clearInterval(interval);
  }, [isTimerRunning, timerSecondsLeft]);

  /* ✅ جديد: Wake Lock — الشاشة لا تنطفئ أثناء الطبخ */
  useEffect(() => {
    const requestWakeLock = async () => {
      try {
        if ('wakeLock' in navigator && isCookModeOpen) {
          wakeLockRef.current = await (navigator as any).wakeLock.request('screen');
        }
      } catch {
        /* wake lock unsupported/denied */
      }
    };
    requestWakeLock();
    return () => {
      try {
        wakeLockRef.current?.release?.();
        wakeLockRef.current = null;
      } catch {
        /* noop */
      }
    };
  }, [isCookModeOpen]);

  /* إيقاف القراءة الصوتية عند الخروج */
  useEffect(() => {
    if (!isCookModeOpen && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  }, [isCookModeOpen]);

  if (!isCookModeOpen) return null;

  /* ✅ حماية: وصفة بدون خطوات (مستوردة ناقصة مثلاً) */
  if (!hasRecipe || !hasSteps) {
    return (
      <div className="fixed inset-0 z-50 bg-[var(--brand-deep)]/95 backdrop-blur-md flex items-center justify-center p-6 text-white">
        <div className="max-w-sm text-center space-y-4 bg-white/10 border-2 border-white/20 rounded-3xl p-6">
          <AlertTriangle className="w-10 h-10 mx-auto text-[var(--accent)]" />
          <h3 className="text-lg font-black">
            {isAr ? 'الوصفة دي ناقصة الخطوات' : 'This recipe has no steps'}
          </h3>
          <p className="text-sm text-white/80 leading-relaxed">
            {isAr
              ? 'يبدو أن الوصفة المستوردة لا تحتوي على خطوات واضحة. جرب استيرادها من مصدر آخر أو اطلب من ذاد وصفة بديلة.'
              : 'This imported recipe has no clear steps. Try importing from another source or ask ZAD for an alternative.'}
          </p>
          <button
            onClick={() => closeCookMode(false)}
            className="px-6 py-2.5 rounded-xl bg-white text-[var(--brand-deep)] font-black text-sm border-2 border-[var(--line-strong)]"
          >
            {isAr ? 'حسناً' : 'OK'}
          </button>
        </div>
      </div>
    );
  }

  const speakCurrentStep = () => {
    if (!('speechSynthesis' in window) || !currentStep) return;

    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    const textToSpeak = `${isAr ? 'الخطوة رقم' : 'Step'} ${currentStepIndex + 1}: ${currentStep.instruction}. ${
      currentStep.tip ? (isAr ? 'نصيحة ذاد: ' + currentStep.tip : 'Tip: ' + currentStep.tip) : ''
    }`;

    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    utterance.lang = isAr ? 'ar-SA' : 'en-US';
    utterance.rate = 0.95;

    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    setIsSpeaking(true);
    window.speechSynthesis.speak(utterance);
  };

  const handleFinish = () => {
    setIsFinished(true);
    recordCookedMeal();
    if (activeCookRecipe) rateRecipe(activeCookRecipe.id, userRating || 5);
  };

  const handleNext = () => {
    if (currentStepIndex < steps.length - 1) {
      setCurrentStepIndex((prev) => prev + 1);
    } else {
      handleFinish();
    }
  };

  const handlePrev = () => {
    if (currentStepIndex > 0) setCurrentStepIndex((prev) => prev - 1);
  };

  const formatTimer = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div
      className="fixed inset-0 z-50 flex flex-col justify-between text-white p-4 sm:p-8 animate-fade-in"
      style={{ background: 'linear-gradient(160deg, var(--brand-deep) 0%, #0E2E1E 100%)' }}
    >
      {/* الشريط العلوي */}
      <div className="flex items-center justify-between border-b-2 border-white/15 pb-4">
        <div className="min-w-0">
          <span className="text-[11px] font-black tracking-wider text-[var(--accent)]">
            {isAr ? 'وضع الطاهي — خطوة بخطوة' : 'Cook Mode'}
          </span>
          <h2 className="text-base sm:text-xl font-black truncate max-w-sm sm:max-w-md">
            {isAr ? activeCookRecipe!.title : activeCookRecipe!.titleEn}
          </h2>
        </div>

        <div className="flex items-center gap-2.5 flex-shrink-0">
          <button
            onClick={speakCurrentStep}
            className={`p-2.5 rounded-full border-2 transition-all ${
              isSpeaking ? 'bg-[var(--accent)] border-white/40' : 'bg-white/10 hover:bg-white/20 border-white/20'
            }`}
            title={isAr ? 'قراءة الخطوة بصوت عالي' : 'Read aloud'}
            aria-label={isAr ? 'قراءة صوتية' : 'Read aloud'}
          >
            {isSpeaking ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </button>

          <button
            onClick={() => closeCookMode(isFinished)}
            className="p-2.5 rounded-full bg-white/10 hover:bg-white/20 border-2 border-white/20"
            aria-label={isAr ? 'إغلاق' : 'Close'}
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* المحتوى */}
      <div className="max-w-2xl mx-auto w-full my-auto py-6 space-y-6">
        {!isFinished ? (
          <div className="space-y-6">
            <div className="flex items-center justify-between text-white/70 text-sm">
              <span className="font-black text-[var(--accent)]">
                {isAr ? `الخطوة ${currentStepIndex + 1} من ${steps.length}` : `Step ${currentStepIndex + 1} of ${steps.length}`}
              </span>
              <div className="flex gap-1.5">
                {steps.map((_, i) => (
                  <span
                    key={i}
                    className={`h-1.5 rounded-full transition-all ${
                      i === currentStepIndex ? 'w-7 bg-[var(--accent)]' : i < currentStepIndex ? 'w-2.5 bg-white' : 'w-2.5 bg-white/25'
                    }`}
                  />
                ))}
              </div>
            </div>

            <div className="bg-white/10 rounded-3xl p-6 sm:p-8 backdrop-blur-lg border-2 border-white/15 space-y-4 shadow-[6px_6px_0_0_rgba(0,0,0,0.35)]">
              <p className="text-2xl sm:text-3xl font-black leading-relaxed tracking-wide">
                {currentStep.instruction}
              </p>

              {currentStep.tip && (
                <div className="bg-black/25 p-3.5 rounded-2xl border border-white/10 text-xs sm:text-sm text-amber-200 flex items-start gap-2.5">
                  <Lightbulb className="w-4 h-4 flex-shrink-0 mt-0.5" />
                  <div className="leading-relaxed">
                    <span className="font-black">{isAr ? 'نصيحة ذاد: ' : 'ZAD tip: '}</span>
                    {currentStep.tip}
                  </div>
                </div>
              )}
            </div>

            {timerSecondsLeft !== null && (
              <div className="bg-white/10 rounded-2xl p-4 border-2 border-white/15 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-[var(--accent)]" />
                  <div>
                    <div className="text-xs text-white/70 font-bold">{isAr ? 'مؤقت الخطوة' : 'Step timer'}</div>
                    <div className="text-3xl font-mono font-black tracking-widest text-[var(--accent)]">
                      {formatTimer(timerSecondsLeft)}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setIsTimerRunning(!isTimerRunning)}
                    className="px-4 py-2 rounded-xl bg-[var(--accent)] hover:bg-[var(--accent-deep)] text-white text-xs font-black flex items-center gap-1.5 border-2 border-white/25"
                  >
                    {isTimerRunning ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    <span>{isTimerRunning ? (isAr ? 'إيقاف' : 'Pause') : (isAr ? 'تشغيل' : 'Start')}</span>
                  </button>

                  <button
                    onClick={() => {
                      setIsTimerRunning(false);
                      setTimerSecondsLeft(currentStep?.timerSeconds || 0);
                    }}
                    className="p-2 rounded-xl bg-white/10 hover:bg-white/20 border-2 border-white/20"
                    aria-label={isAr ? 'إعادة ضبط' : 'Reset'}
                  >
                    <RotateCcw className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}
          </div>
        ) : (
          <div className="bg-white/10 rounded-3xl p-8 backdrop-blur-lg border-2 border-white/15 text-center space-y-5 shadow-[6px_6px_0_0_rgba(0,0,0,0.35)] animate-pop">
            <div className="w-16 h-16 rounded-2xl bg-[var(--accent)] mx-auto flex items-center justify-center border-2 border-white/30">
              <PartyPopper className="w-8 h-8" />
            </div>
            <div className="space-y-2">
              <h3 className="text-2xl font-black">
                {isAr ? 'بالهناء والشفاء!' : 'Bon appétit!'}
              </h3>
              <p className="text-sm text-white/80 max-w-md mx-auto leading-relaxed">
                {isAr
                  ? '«الخير في اللي عندك» — عملت وجبة حلوة من المتاح، ووفرت مالك ووقتك.'
                  : 'You made the most of what you have — saved money and enjoyed good food.'}
              </p>
            </div>

            <div className="pt-1 space-y-2">
              <div className="text-xs font-bold text-white/70">
                {isAr ? 'قيّم التجربة (بتغذي اقتراحات ذاد):' : 'Rate this recipe:'}
              </div>
              <div className="flex justify-center gap-2" dir="ltr">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => setUserRating(star)}
                    className={`text-3xl transition-transform hover:scale-125 ${
                      star <= userRating ? 'opacity-100' : 'opacity-40'
                    }`}
                    aria-label={`${star} / 5`}
                  >
                    ⭐
                  </button>
                ))}
              </div>
            </div>

            <div className="pt-2">
              <button
                onClick={() => closeCookMode(true)}
                className="px-8 py-3 rounded-2xl bg-white text-[var(--brand-deep)] font-black text-sm border-2 border-[var(--line-strong)] shadow-[4px_4px_0_0_rgba(0,0,0,0.4)]"
              >
                {isAr ? 'تمام، يلا نرجع' : 'Done & return'}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* التنقل بين الخطوات */}
      {!isFinished && (
        <div className="flex items-center justify-between border-t-2 border-white/15 pt-4">
          <button
            onClick={handlePrev}
            disabled={currentStepIndex === 0}
            className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 disabled:opacity-30 text-xs font-black border-2 border-white/15"
          >
            {isAr ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            <span>{isAr ? 'السابقة' : 'Prev'}</span>
          </button>

          <button
            onClick={handleNext}
            className="flex items-center gap-1.5 px-6 py-2.5 rounded-xl bg-[var(--accent)] text-xs font-black border-2 border-white/25 shadow-[4px_4px_0_0_rgba(0,0,0,0.35)]"
          >
            <span>
              {currentStepIndex === steps.length - 1
                ? isAr ? 'إنهاء 🎉' : 'Finish 🎉'
                : isAr ? 'التالية' : 'Next'}
            </span>
            {isAr ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
        </div>
      )}
    </div>
  );
};
