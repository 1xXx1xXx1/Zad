/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  Sparkles,
  Camera,
  PackagePlus,
  CalendarDays,
  Receipt,
  Flame,
  ArrowRight,
  ArrowLeft,
  AlertTriangle,
  Heart,
  MapPin,
  Globe,
  Dices,
  CookingPot,
  Wallet,
  PiggyBank,
  RefreshCw,
  TrendingDown,
  CheckCircle2,
  Clock,
} from 'lucide-react';
import { checkPantryExpiry, calculateBudgetStatus, computeMissingIngredients, currencySymbol } from '../utils/rules';
import { Recipe } from '../types';

export const HomeScreen: React.FC = () => {
  const {
    language,
    setActiveTab,
    openCookMode,
    recipes,
    pantry,
    userPreferences,
    mealPlan,
    shoppingList,
    toggleFavoriteRecipe,
    setIsStoreMapOpen,
    sumExpensesInPeriod,
    stats,
    generateMealPlan,
  } = useApp();

  const isAr = language === 'ar';
  const Arrow = isAr ? ArrowLeft : ArrowRight;

  /* ── تحية حسب وقت اليوم ── */
  const currentHour = new Date().getHours();
  const timeGreetingAr =
    currentHour >= 5 && currentHour < 12
      ? 'صباح الخير والبركة'
      : currentHour >= 12 && currentHour < 17
      ? 'طاب يومك بكل خير'
      : currentHour >= 17 && currentHour < 22
      ? 'مساء الراحة والطعام الهنيء'
      : 'سهرة هادئة وخفيفة';

  const recommendedCategory =
    currentHour >= 5 && currentHour < 12
      ? 'breakfast'
      : currentHour >= 12 && currentHour < 17
      ? 'lunch'
      : currentHour >= 17 && currentHour < 22
      ? 'dinner'
      : 'snack';

  const pantryNames = pantry.map((p) => p.name);

  /* ── عجلة «فاجئني» ✨ فكرة جديدة ── */
  const [wheelRecipe, setWheelRecipe] = useState<Recipe | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);
  const spinRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (spinRef.current) window.clearInterval(spinRef.current);
    };
  }, []);

  const handleSurprise = () => {
    if (isSpinning || recipes.length === 0) return;
    setIsSpinning(true);
    let ticks = 0;
    const wellMatched = recipes.filter(
      (r) => computeMissingIngredients(r.ingredients.map((i) => i.name), pantryNames).matchPercent >= 50
    );
    const candidates = wellMatched.length > 0 ? wellMatched : recipes;

    spinRef.current = window.setInterval(() => {
      ticks++;
      setWheelRecipe(recipes[Math.floor(Math.random() * recipes.length)]);
      if (ticks >= 12) {
        if (spinRef.current) window.clearInterval(spinRef.current);
        setWheelRecipe(candidates[Math.floor(Math.random() * candidates.length)]);
        setIsSpinning(false);
      }
    }, 75);
  };

  const featuredRecipe =
    wheelRecipe || recipes.find((r) => r.category === recommendedCategory) || recipes[0];

  /* ── صندوق الإنقاذ: وصفات تستغل المكونات القريبة من الانتهاء فوراً بدون AI ── */
  const expiringItems = pantry.filter((item) => {
    const { status } = checkPantryExpiry(item.expiryDate);
    return status === 'expiring_soon' || status === 'expired';
  });

  const rescueRecipes = useMemo(() => {
    if (expiringItems.length === 0) return [];
    const expiringNames = expiringItems.map((i) => i.name);
    return recipes
      .map((r) => {
        const fromExpiring = computeMissingIngredients(r.ingredients.map((i) => i.name), expiringNames);
        const fromPantry = computeMissingIngredients(r.ingredients.map((i) => i.name), pantryNames);
        return { recipe: r, expiringUsed: fromExpiring.available, pantryMatch: fromPantry.matchPercent };
      })
      .filter((x) => x.expiringUsed.length > 0)
      .sort((a, b) => b.expiringUsed.length - a.expiringUsed.length || b.pantryMatch - a.pantryMatch)
      .slice(0, 4);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pantry, recipes]);

  /* ── الميزانية الأسبوعية (مُصلَّحة: آخر 7 أيام فعلاً) ── */
  const weeklySpent = sumExpensesInPeriod('weekly');
  const budgetStatus = calculateBudgetStatus(userPreferences.budgetWeekly, weeklySpent);

  /* ── إجراءات سريعة ── */
  const quickActions = [
    {
      id: 'rescue_meal',
      title: isAr ? 'أنقذني بوجبة' : 'Rescue Meal',
      icon: Sparkles,
      tile: 'bg-[var(--accent)] text-white',
      action: () => setActiveTab('ask_zad'),
    },
    {
      id: 'scan_pantry',
      title: isAr ? 'صوّر الثلاجة' : 'Scan Fridge',
      icon: Camera,
      tile: 'bg-[var(--brand)] text-white',
      action: () => setActiveTab('pantry'),
    },
    {
      id: 'add_pantry',
      title: isAr ? 'أضف للمخزن' : 'Add Item',
      icon: PackagePlus,
      tile: 'bg-[var(--surface)] text-[var(--ink)]',
      action: () => setActiveTab('pantry'),
    },
    {
      id: 'plan_week',
      title: isAr ? 'خطط أسبوعك' : 'Plan Week',
      icon: CalendarDays,
      tile: 'bg-[var(--surface)] text-[var(--ink)]',
      action: () => setActiveTab('recipes'),
    },
    {
      id: 'global_recipes',
      title: isAr ? 'وصفات العالم' : 'World Recipes',
      icon: Globe,
      tile: 'bg-[var(--brand)] text-white',
      action: () => setActiveTab('recipes'),
    },
    {
      id: 'locate_map',
      title: isAr ? 'المتاجر القريبة' : 'Nearby Stores',
      icon: MapPin,
      tile: 'bg-[var(--surface)] text-[var(--ink)]',
      action: () => setIsStoreMapOpen(true),
    },
    {
      id: 'log_expense',
      title: isAr ? 'سجّل مصروف' : 'Log Expense',
      icon: Receipt,
      tile: 'bg-[var(--surface)] text-[var(--ink)]',
      action: () => setActiveTab('budget'),
    },
  ];

  const heroDate = new Date().toLocaleDateString(isAr ? 'ar-EG' : 'en-GB', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
  });

  return (
    <div className="space-y-6 pb-24 pt-1 animate-fade-in">
      {/* ═══ البطاقة البطلة: تحية + إحصائيات حية ═══ */}
      <section
        className="relative rounded-3xl border-2 border-[var(--line-strong)] p-5 overflow-hidden text-white"
        style={{
          background: 'linear-gradient(135deg, var(--brand-deep) 0%, var(--brand) 60%, var(--brand-2) 100%)',
          boxShadow: '5px 5px 0 0 var(--shadow-card)',
        }}
      >
        <div
          className="absolute inset-0 opacity-20 pointer-events-none"
          style={{ backgroundImage: 'radial-gradient(rgba(255,255,255,0.5) 1px, transparent 1px)', backgroundSize: '18px 18px' }}
        />
        <div className="relative z-10 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-white/15 border border-white/25 text-[11px] font-bold backdrop-blur-sm">
              <span className="w-1.5 h-1.5 rounded-full bg-[var(--accent)] animate-pulse" />
              {heroDate}
            </span>
            <button
              onClick={handleSurprise}
              disabled={isSpinning}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-[var(--accent)] border-2 border-white/30 text-[11px] font-extrabold transition-all hover:-translate-y-0.5 ${
                isSpinning ? 'opacity-80' : ''
              }`}
              title={isAr ? 'عجلة «فاجئني» — وجبة من المتاح' : 'Surprise me'}
            >
              <Dices className={`w-4 h-4 ${isSpinning ? 'animate-spin-slow' : ''}`} />
              <span>{isAr ? 'فاجئني' : 'Surprise me'}</span>
            </button>
          </div>

          <h1 className="text-2xl sm:text-3xl font-black tracking-tight drop-shadow-sm">
            {isAr ? timeGreetingAr : 'Welcome back to ZAD'}
          </h1>
          <p className="text-white/85 text-sm max-w-lg font-medium leading-relaxed">
            {isAr
              ? 'خلّينا نشوف الموجود عندك، ونعمل منه وجبة حلوة بدون حيرة ولا مصاريف زيادة.'
              : 'Let us see what you have, and turn it into a great meal — no stress, no extra spend.'}
          </p>

          {/* إحصائيات حية */}
          <div className="grid grid-cols-3 gap-2 pt-1">
            <div className="rounded-xl bg-white/12 border border-white/20 px-2.5 py-2 backdrop-blur-sm">
              <div className="flex items-center gap-1 text-[10px] font-bold text-white/75">
                <Wallet className="w-3 h-3" />
                {isAr ? 'متبقي الأسبوع' : 'Week left'}
              </div>
              <div className="text-base font-black mt-0.5">
                {Math.max(0, budgetStatus.remaining)}{' '}
                <span className="text-[10px] font-bold opacity-80">{currencySymbol(userPreferences.currency)}</span>
              </div>
            </div>
            <div className="rounded-xl bg-white/12 border border-white/20 px-2.5 py-2 backdrop-blur-sm">
              <div className="flex items-center gap-1 text-[10px] font-bold text-white/75">
                <PiggyBank className="w-3 h-3" />
                {isAr ? 'وفرته من الهدر' : 'Rescue savings'}
              </div>
              <div className="text-base font-black mt-0.5">
                {Math.round(stats.savedMoney)}{' '}
                <span className="text-[10px] font-bold opacity-80">{currencySymbol(userPreferences.currency)}</span>
              </div>
            </div>
            <div className="rounded-xl bg-white/12 border border-white/20 px-2.5 py-2 backdrop-blur-sm">
              <div className="flex items-center gap-1 text-[10px] font-bold text-white/75">
                <CookingPot className="w-3 h-3" />
                {isAr ? 'وجبات اطبختها' : 'Meals cooked'}
              </div>
              <div className="text-base font-black mt-0.5">{stats.cookedMeals}</div>
            </div>
          </div>
        </div>
      </section>

      {/* ═══ صندوق الإنقاذ ✨ فكرة جديدة: وصفات لحظية للمكونات القريبة من الانتهاء ═══ */}
      {rescueRecipes.length > 0 && (
        <section className="rounded-3xl border-2 border-[var(--warn-line)] bg-[var(--warn-soft)] p-4 space-y-3 shadow-[4px_4px_0_0_var(--shadow-card)]">
          <div className="flex items-start justify-between gap-3">
            <div className="flex items-start gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-[var(--warn-mid)] border-2 border-[var(--warn-line)] flex items-center justify-center flex-shrink-0 text-[var(--warn-ink)]">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm font-black text-[var(--warn-ink)]">
                  {isAr ? '🚑 صندوق الإنقاذ — استغلها قبل ما تضيع' : 'Rescue Box — use them first'}
                </h3>
                <p className="text-[11px] text-[var(--warn-ink)] opacity-80 mt-0.5">
                  {isAr
                    ? `${expiringItems.length} مكونات قربت على صلاحيتها. ذاد لقى لك وصفات تستغلها فوراً:`
                    : `${expiringItems.length} items nearing expiry. Instant recipes to use them up:`}
                </p>
              </div>
            </div>
            <button
              onClick={() => setActiveTab('ask_zad')}
              className="flex-shrink-0 px-3 py-1.5 rounded-xl bg-[var(--accent)] text-white text-[11px] font-extrabold border-2 border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)] hover:-translate-y-0.5 transition-transform flex items-center gap-1"
            >
              <span>{isAr ? 'اقتراح ذكي أكثر' : 'AI ideas'}</span>
              <Arrow className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="flex flex-wrap gap-1.5">
            {expiringItems.slice(0, 6).map((it) => (
              <span
                key={it.id}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-lg bg-[var(--surface)] text-[var(--warn-ink)] border border-[var(--warn-line)] text-[11px] font-bold"
              >
                {it.name}
                <span className="text-[9px] opacity-70">
                  ({checkPantryExpiry(it.expiryDate).status === 'expired'
                    ? isAr ? 'انتهت!' : 'expired'
                    : isAr ? `${checkPantryExpiry(it.expiryDate).daysRemaining} أيام` : `${checkPantryExpiry(it.expiryDate).daysRemaining}d`})
                </span>
              </span>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
            {rescueRecipes.map(({ recipe, expiringUsed, pantryMatch }) => (
              <div
                key={recipe.id}
                className="rounded-2xl border-2 border-[var(--line-strong)] bg-[var(--surface)] p-3 space-y-2 shadow-[3px_3px_0_0_var(--shadow-card)] hover:-translate-y-0.5 transition-transform"
              >
                <div className="flex items-center justify-between gap-2">
                  <h4 className="font-extrabold text-xs text-[var(--ink)] line-clamp-1">
                    {isAr ? recipe.title : recipe.titleEn}
                  </h4>
                  <span className="flex-shrink-0 text-[9px] font-black px-1.5 py-0.5 rounded-md bg-[var(--brand-soft)] text-[var(--brand-ink)] border border-[var(--brand-line)]">
                    {isAr ? `يستغل ${expiringUsed.length} مكونات` : `saves ${expiringUsed.length}`}
                  </span>
                </div>
                <div className="flex items-center gap-2 text-[10px] text-[var(--muted)] font-semibold">
                  <span className="flex items-center gap-0.5">
                    <Clock className="w-3 h-3" />
                    {recipe.prepTimeMinutes + recipe.cookTimeMinutes} {isAr ? 'د' : 'm'}
                  </span>
                  <span>·</span>
                  <span>
                    {isAr ? 'متوفر عندك' : 'pantry'} {pantryMatch}%
                  </span>
                </div>
                {/* شريط نسبة التوافق */}
                <div className="w-full h-1.5 rounded-full bg-[var(--surface-2)] border border-[var(--line)] overflow-hidden">
                  <div
                    className="h-full rounded-full bg-[var(--brand)]"
                    style={{ width: `${pantryMatch}%` }}
                  />
                </div>
                <div className="flex items-center gap-1.5 pt-0.5">
                  <button
                    onClick={() => openCookMode(recipe)}
                    className="flex-1 py-1.5 rounded-lg bg-[var(--brand)] text-white text-[11px] font-extrabold border-2 border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)]"
                  >
                    {isAr ? 'ابدأ الطهي' : 'Cook now'}
                  </button>
                  <button
                    onClick={() => toggleFavoriteRecipe(recipe.id)}
                    className="w-8 h-8 rounded-lg border-2 border-[var(--line-strong)] bg-[var(--surface-2)] flex items-center justify-center"
                    aria-label={isAr ? 'مفضلة' : 'Favorite'}
                  >
                    <Heart className={`w-3.5 h-3.5 ${recipe.isFavorite ? 'fill-[var(--accent)] text-[var(--accent)]' : 'text-[var(--muted)]'}`} />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* ═══ الإجراءات السريعة ═══ */}
      <section aria-label={isAr ? 'إجراءات سريعة' : 'Quick Actions'}>
        <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
          {quickActions.map((qa) => {
            const Icon = qa.icon;
            return (
              <button
                key={qa.id}
                onClick={qa.action}
                className={`flex flex-col items-center gap-1.5 px-1.5 py-2.5 rounded-2xl border-2 border-[var(--line-strong)] shadow-[3px_3px_0_0_var(--shadow-card)] hover:-translate-y-1 active:translate-y-0.5 active:shadow-[1px_1px_0_0_var(--shadow-card)] transition-all ${qa.tile}`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px] font-extrabold leading-tight text-center">{qa.title}</span>
              </button>
            );
          })}
        </div>
      </section>

      {/* ═══ اقتراح ذاد (مع نتيجة العجلة إن وجدت) ═══ */}
      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-black text-[var(--brand-ink)] tracking-tight flex items-center gap-2">
              {isAr ? 'ذاد يقترح عليك الآن' : 'ZAD suggests now'}
              {wheelRecipe && !isSpinning && (
                <span className="text-[9px] font-black px-1.5 py-0.5 rounded-md bg-[var(--accent)] text-white border border-[var(--line-strong)]">
                  {isAr ? '🎲 من العجلة' : '🎲 Wheel pick'}
                </span>
              )}
            </h2>
            <p className="text-xs text-[var(--muted)]">
              {isAr ? 'وجبة متناسبة مع وقتك والمتاح بمخزنك' : 'Tailored to your time and pantry'}
            </p>
          </div>
          <button
            onClick={() => setActiveTab('recipes')}
            className="text-xs font-extrabold text-[var(--accent)] hover:underline flex items-center gap-1"
          >
            <span>{isAr ? 'عرض الكل' : 'View all'}</span>
            <Arrow className="w-3.5 h-3.5" />
          </button>
        </div>

        {featuredRecipe && (
          <div
            key={featuredRecipe.id}
            className="rounded-3xl border-2 border-[var(--line-strong)] overflow-hidden animate-pop"
            style={{ background: 'var(--surface)', boxShadow: '5px 5px 0 0 var(--shadow-card)' }}
          >
            <div className="grid grid-cols-1 md:grid-cols-12">
              <div className="md:col-span-5 h-48 md:h-full relative overflow-hidden border-b-2 md:border-b-0 md:border-l-2 border-[var(--line-strong)]">
                <img
                  src={featuredRecipe.imageUrl}
                  alt={featuredRecipe.title}
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
                <div className="absolute top-3 right-3 flex items-center gap-1 bg-[var(--ink)] text-[var(--bg)] text-[11px] font-extrabold px-2 py-0.5 rounded-lg border-2 border-[var(--surface)]">
                  <Flame className="w-3 h-3 text-[var(--accent)]" />
                  <span>
                    {featuredRecipe.prepTimeMinutes + featuredRecipe.cookTimeMinutes} {isAr ? 'دقيقة' : 'min'}
                  </span>
                </div>
                <button
                  onClick={() => toggleFavoriteRecipe(featuredRecipe.id)}
                  className="absolute top-3 left-3 w-8 h-8 rounded-lg bg-[var(--surface)] border-2 border-[var(--line-strong)] flex items-center justify-center hover:scale-110 transition-transform"
                  aria-label={isAr ? 'حفظ في المفضلة' : 'Favorite'}
                >
                  <Heart className={`w-4 h-4 ${featuredRecipe.isFavorite ? 'fill-[var(--accent)] text-[var(--accent)]' : 'text-[var(--ink)]'}`} />
                </button>
              </div>

              <div className="md:col-span-7 p-4 sm:p-5 flex flex-col justify-between gap-3">
                <div className="space-y-2">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[10px] font-black text-white bg-[var(--brand)] px-2 py-0.5 rounded-md border border-[var(--line-strong)]">
                      {isAr ? 'مقترح ذكي' : 'Smart pick'}
                    </span>
                    {featuredRecipe.equipment?.[0] && (
                      <span className="text-[10px] font-bold text-[var(--muted)] bg-[var(--surface-2)] border border-[var(--line)] px-2 py-0.5 rounded-md">
                        {featuredRecipe.equipment[0]}
                      </span>
                    )}
                    <span className="text-[10px] font-bold text-[var(--brand-ink)] bg-[var(--brand-soft)] border border-[var(--brand-line)] px-1.5 py-0.5 rounded-md">
                      {isAr ? 'موثقة' : 'Verified'}
                    </span>
                  </div>

                  <h3 className="text-base sm:text-lg font-black text-[var(--ink)]">
                    {isAr ? featuredRecipe.title : featuredRecipe.titleEn}
                  </h3>

                  <p className="text-xs text-[var(--muted)] line-clamp-2 leading-relaxed">
                    {featuredRecipe.description}
                  </p>

                  <div className="flex items-center gap-4 text-xs pt-0.5">
                    <div>
                      <span className="text-[var(--faint)]">{isAr ? 'التكلفة التقديرية:' : 'Est. cost:'} </span>
                      <span className="font-black text-[var(--brand-ink)]">
                        ~{featuredRecipe.estimatedCost} {userPreferences.currency}
                      </span>
                    </div>
                    <div>
                      <span className="text-[var(--faint)]">{isAr ? 'الحصص:' : 'Servings:'} </span>
                      <span className="font-black text-[var(--ink)]">{featuredRecipe.servings}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => openCookMode(featuredRecipe)}
                    className="flex-1 py-2.5 px-4 rounded-xl bg-[var(--accent)] text-white text-xs font-extrabold border-2 border-[var(--line-strong)] flex items-center justify-center gap-1.5"
                  >
                    <CookingPot className="w-4 h-4" />
                    <span>{isAr ? 'ابدأ الطبخ (وضع الطاهي)' : 'Start cooking'}</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('recipes')}
                    className="py-2.5 px-3 rounded-xl border-2 border-[var(--line-strong)] bg-[var(--surface-2)] text-[var(--ink)] text-xs font-extrabold"
                  >
                    {isAr ? 'المكونات' : 'Ingredients'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </section>

      {/* ═══ ميزانية + تسوق ═══ */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        <div className="rounded-3xl border-2 border-[var(--line-strong)] bg-[var(--surface)] p-4 space-y-2.5 shadow-[4px_4px_0_0_var(--shadow-card)]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-[var(--muted)] flex items-center gap-1.5">
              <Wallet className="w-3.5 h-3.5 text-[var(--brand-ink)]" />
              {isAr ? 'ميزانية الأسبوع (آخر 7 أيام)' : 'Weekly budget (last 7d)'}
            </span>
            <button
              onClick={() => setActiveTab('budget')}
              className="text-[11px] font-extrabold text-[var(--accent)] hover:underline"
            >
              {isAr ? 'التفاصيل' : 'Details'}
            </button>
          </div>

          <div className="flex items-baseline justify-between">
            <div className="text-xl font-black text-[var(--brand-ink)]">
              {budgetStatus.remaining >= 0 ? budgetStatus.remaining : 0} {userPreferences.currency}
              <span className="text-xs font-bold text-[var(--faint)] mx-1">{isAr ? 'متبقي' : 'left'}</span>
            </div>
            <div className="text-xs font-extrabold text-[var(--muted)]">
              {budgetStatus.percentSpent}% {isAr ? 'مستهلك' : 'spent'}
            </div>
          </div>

          <div className="w-full rounded-full h-2.5 overflow-hidden bg-[var(--surface-2)] border border-[var(--line)]">
            <div
              className={`h-full transition-all duration-500 rounded-full ${
                budgetStatus.isOverBudget
                  ? 'bg-[var(--danger-ink)]'
                  : budgetStatus.percentSpent > 80
                  ? 'bg-[var(--warn-line)]'
                  : 'bg-[var(--brand)]'
              }`}
              style={{ width: `${Math.min(100, budgetStatus.percentSpent)}%` }}
            />
          </div>

          <p className="text-[11px] text-[var(--muted)] font-bold leading-relaxed flex items-center gap-1.5">
            <TrendingDown className="w-3.5 h-3.5 flex-shrink-0" />
            {budgetStatus.statusText}
          </p>
        </div>

        <div className="rounded-3xl border-2 border-[var(--line-strong)] bg-[var(--surface)] p-4 space-y-2.5 flex flex-col justify-between shadow-[4px_4px_0_0_var(--shadow-card)]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-black text-[var(--muted)]">
              {isAr ? 'قائمة النواقص والتسوق' : 'Shopping list'}
            </span>
            <button
              onClick={() => setActiveTab('shopping')}
              className="text-[11px] font-extrabold text-[var(--accent)] hover:underline"
            >
              {isAr ? 'فتح القائمة' : 'Open'}
            </button>
          </div>

          <div className="space-y-1.5 min-h-[52px]">
            {shoppingList.slice(0, 3).map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between text-xs py-1 border-b border-[var(--line)] last:border-0"
              >
                <div className="flex items-center gap-2">
                  <span className={`w-2 h-2 rounded-full ${item.checked ? 'bg-[var(--line)]' : 'bg-[var(--accent)]'}`} />
                  <span className={item.checked ? 'line-through text-[var(--faint)]' : 'text-[var(--ink)] font-bold'}>
                    {item.name}
                  </span>
                </div>
                <span className="text-[11px] text-[var(--faint)]">
                  {item.quantity} {item.unit}
                </span>
              </div>
            ))}
            {shoppingList.length === 0 && (
              <p className="text-[11px] text-[var(--faint)]">{isAr ? 'القائمة فاضية — تمام!' : 'Empty list — nice!'}</p>
            )}
          </div>

          <button
            onClick={() => setActiveTab('shopping')}
            className="w-full py-1.5 rounded-xl bg-[var(--surface-2)] hover:bg-[var(--line)] border-2 border-[var(--line-strong)] text-[var(--ink)] text-xs font-extrabold transition-colors flex items-center justify-center gap-1"
          >
            <span>{isAr ? 'عرض الكل ومقارنة الأسعار' : 'View all & compare'}</span>
            <Arrow className="w-3.5 h-3.5" />
          </button>
        </div>
      </section>

      {/* ═══ خطة الأسبوع ═══ */}
      <section className="rounded-3xl border-2 border-[var(--line-strong)] bg-[var(--surface-2)] p-4 space-y-3 shadow-[4px_4px_0_0_var(--shadow-card)]">
        <div className="flex items-center justify-between gap-2">
          <div>
            <h3 className="text-sm font-black text-[var(--brand-ink)]">
              {isAr ? 'مخطط الوجبات القادمة' : 'Upcoming meal plan'}
            </h3>
            <p className="text-[11px] text-[var(--muted)]">
              {isAr ? 'خطة متنوعة تتجدد حول تاريخ اليوم' : 'A varied plan that follows today'}
            </p>
          </div>
          <button
            onClick={() => generateMealPlan(3)}
            className="flex items-center gap-1 text-xs font-extrabold text-[var(--accent)] hover:underline"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>{isAr ? 'جدّد الخطة' : 'Refresh'}</span>
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          {mealPlan.slice(0, 3).map((day, idx) => (
            <div
              key={idx}
              className="rounded-2xl border-2 border-[var(--line-strong)] bg-[var(--surface)] p-3 space-y-1.5 shadow-[3px_3px_0_0_var(--shadow-card)]"
            >
              <div className="text-xs font-black text-[var(--brand-ink)] flex items-center justify-between">
                <span>{isAr ? day.dayName : day.dayNameEn}</span>
                <span className="text-[9px] text-[var(--faint)] font-bold">{day.date}</span>
              </div>
              <div className="text-xs text-[var(--ink)]">
                <div className="text-[10px] text-[var(--faint)] font-bold">{isAr ? 'الغداء:' : 'Lunch:'}</div>
                <div className="font-extrabold truncate">
                  {day.lunch ? (isAr ? day.lunch.title : day.lunch.titleEn) : '-'}
                </div>
              </div>
              <div className="text-[10px] font-bold text-[var(--brand-ink)] bg-[var(--brand-soft)] border border-[var(--brand-line)] px-2 py-0.5 rounded-lg flex items-center justify-between">
                <span>{isAr ? 'تكلفة اليوم:' : 'Day cost:'}</span>
                <span className="font-black">
                  {(day.breakfast?.estimatedCost || 0) + (day.lunch?.estimatedCost || 0)} {userPreferences.currency}
                </span>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* شارة الإنجاز الصغيرة */}
      {stats.rescuedItems > 0 && (
        <section className="flex items-center justify-center gap-2 text-xs font-extrabold text-[var(--brand-ink)]">
          <CheckCircle2 className="w-4 h-4" />
          <span>
            {isAr
              ? `إنجاز رائع: أنقذت ${stats.rescuedItems} مكونات من الهدر (~${Math.round(stats.wasteAvoidedKg)} كجم طعام)`
              : `Great: rescued ${stats.rescuedItems} items (~${stats.wasteAvoidedKg}kg food saved)`}
          </span>
        </section>
      )}
    </div>
  );
};
