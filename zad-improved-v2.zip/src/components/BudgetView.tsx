/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Plus,
  Trash2,
  Calendar,
  TrendingUp,
  Gauge,
  Wallet,
  Sparkles,
  Store,
} from 'lucide-react';
import { calculateBudgetStatus, currencySymbol } from '../utils/rules';
import { ExpenseRecord } from '../types';

export const BudgetView: React.FC = () => {
  const {
    language,
    expenses,
    addExpense,
    deleteExpense,
    userPreferences,
    updatePreferences,
    sumExpensesInPeriod,
    stats,
  } = useApp();

  const isAr = language === 'ar';

  const [activeBudgetPeriod, setActiveBudgetPeriod] = useState<'daily' | 'weekly' | 'monthly'>('weekly');
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);

  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState<number>(50);
  const [category, setCategory] = useState<ExpenseRecord['category']>('groceries');
  const [storeName, setStoreName] = useState('');
  const [notes, setNotes] = useState('');

  const targetBudget =
    activeBudgetPeriod === 'daily'
      ? userPreferences.budgetDaily
      : activeBudgetPeriod === 'weekly'
      ? userPreferences.budgetWeekly
      : userPreferences.budgetMonthly;

  /* ✅ الإصلاح الجوهري: فلترة فعلية حسب الفترة (آخر 1/7/30 يوم) */
  const totalActual = sumExpensesInPeriod(activeBudgetPeriod);
  const budgetStatus = calculateBudgetStatus(targetBudget, totalActual);

  /* ✅ تحليلات ذكية: مبنية على الأسبوع المصري (السبت→الجمعة) والشهر التقويمي الفعلي */
  const periodMeta = (() => {
    const now = new Date();
    if (activeBudgetPeriod === 'daily') return { daysInPeriod: 1, elapsedDays: 1, daysLeft: 1 };
    if (activeBudgetPeriod === 'weekly') {
      // بداية الأسبوع في مصر السبت (6) — الأحد يعد اليوم الثاني
      const elapsed = ((now.getDay() - 6 + 7) % 7) + 1; // السبت=1
      return { daysInPeriod: 7, elapsedDays: elapsed, daysLeft: 7 - elapsed + 1 };
    }
    const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
    return { daysInPeriod: daysInMonth, elapsedDays: now.getDate(), daysLeft: daysInMonth - now.getDate() + 1 };
  })();

  const burnPerDay = Math.round(totalActual / periodMeta.elapsedDays);
  const safeDailyAllowance = Math.max(0, Math.round(Math.max(0, targetBudget - totalActual) / periodMeta.daysLeft));
  const projectedTotal = burnPerDay * periodMeta.daysInPeriod;

  const periodDaysWindow = activeBudgetPeriod === 'daily' ? 1 : activeBudgetPeriod === 'weekly' ? 7 : 30;
  const periodExpenses = expenses
    .filter((e) => {
      const d = new Date(e.date + 'T00:00:00');
      const cutoff = new Date();
      cutoff.setHours(0, 0, 0, 0);
      cutoff.setDate(cutoff.getDate() - (periodDaysWindow - 1));
      return d >= cutoff;
    })
    .sort((a, b) => (a.date < b.date ? 1 : -1));

  const categoryTotals: { [key: string]: number } = {
    groceries: 0,
    vegetables_fruits: 0,
    butcher_poultry: 0,
    bakery: 0,
    quick_meal: 0,
  };

  periodExpenses.forEach((e) => {
    if (categoryTotals[e.category] !== undefined) categoryTotals[e.category] += e.amount;
    else categoryTotals['groceries'] += e.amount;
  });

  const categoryLabels: { [key: string]: { ar: string; en: string } } = {
    groceries: { ar: 'بقالة أساسية', en: 'Groceries' },
    vegetables_fruits: { ar: 'خضار وفاكهة', en: 'Produce' },
    butcher_poultry: { ar: 'لحوم ودواجن', en: 'Meat & Poultry' },
    bakery: { ar: 'مخبوزات وعيش', en: 'Bakery' },
    quick_meal: { ar: 'وجبات سريعة', en: 'Quick Meals' },
  };

  const handleLogSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || amount <= 0) return;

    addExpense({
      title: title.trim(),
      amount: Number(amount),
      date: new Date().toISOString().split('T')[0],
      category,
      storeName: storeName.trim() || undefined,
      notes: notes.trim() || undefined,
      verifiedTag: 'user_provided',
    });

    setTitle('');
    setStoreName('');
    setNotes('');
    setAmount(50);
    setIsLogModalOpen(false);
  };

  return (
    <div className="space-y-5 pb-24 pt-1 animate-fade-in">
      {/* الهيدر */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-black text-[var(--brand-ink)] tracking-tight flex items-center gap-2">
            <Wallet className="w-5 h-5" />
            {isAr ? 'ميزانية الطعام' : 'Food Budget'}
          </h2>
          <p className="text-xs text-[var(--muted)] font-semibold">
            {isAr ? 'حسابات واضحة بدون تعقيد وبدون أي لوم — تكة واحدة تسجل مصروفك' : 'Clear numbers, zero judgment'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={currencySymbol(userPreferences.currency)}
            onChange={(e) => updatePreferences({ currency: e.target.value as any })}
            aria-label={isAr ? 'عملة الحساب' : 'Currency'}
            className="text-xs bg-[var(--surface)] border-2 border-[var(--line-strong)] rounded-xl px-2.5 py-2 font-extrabold text-[var(--brand-ink)] shadow-[2px_2px_0_0_var(--shadow-card)]"
          >
            <option value="EGP">ج.م (EGP)</option>
            <option value="SAR">ر.س (SAR)</option>
            <option value="AED">د.إ (AED)</option>
            <option value="USD">$ (USD)</option>
          </select>

          <button
            onClick={() => setIsLogModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[var(--brand)] text-white text-xs font-extrabold border-2 border-[var(--line-strong)]"
          >
            <Plus className="w-4 h-4" />
            <span>{isAr ? 'تسجيل مصروف' : 'Log expense'}</span>
          </button>
        </div>
      </div>

      {/* تبويبات الفترة */}
      <div className="flex bg-[var(--surface-2)] p-1 rounded-2xl border-2 border-[var(--line-strong)] max-w-sm shadow-[3px_3px_0_0_var(--shadow-card)]">
        {(['daily', 'weekly', 'monthly'] as const).map((period) => (
          <button
            key={period}
            onClick={() => setActiveBudgetPeriod(period)}
            className={`flex-1 py-1.5 rounded-xl text-xs font-extrabold transition-all ${
              activeBudgetPeriod === period
                ? 'bg-[var(--surface)] text-[var(--brand-ink)] border-2 border-[var(--brand)]'
                : 'text-[var(--muted)]'
            }`}
          >
            {period === 'daily'
              ? isAr ? 'اليوم' : 'Daily'
              : period === 'weekly'
              ? isAr ? 'آخر 7 أيام' : 'Weekly'
              : isAr ? 'آخر 30 يوم' : 'Monthly'}
          </button>
        ))}
      </div>

      {/* بطاقة الميزانية الرئيسية */}
      <div className="rounded-3xl border-2 border-[var(--line-strong)] bg-[var(--surface)] p-5 space-y-4 shadow-[4px_4px_0_0_var(--shadow-card)]">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3 rounded-2xl border-2 border-[var(--line)] bg-[var(--surface-2)]">
            <span className="text-[11px] font-extrabold text-[var(--faint)] block">
              {isAr ? 'الميزانية المخططة' : 'Planned'}
            </span>
            <div className="text-xl sm:text-2xl font-black text-[var(--brand-ink)] mt-1">
              {targetBudget} {currencySymbol(userPreferences.currency)}
            </div>
          </div>

          <div className="p-3 rounded-2xl border-2 border-[var(--line)] bg-[var(--surface-2)]">
            <span className="text-[11px] font-extrabold text-[var(--faint)] block">
              {isAr ? 'المصروف الفعلي' : 'Actual spent'}
            </span>
            <div className="text-xl sm:text-2xl font-black text-[var(--ink)] mt-1">
              {budgetStatus.actual} {currencySymbol(userPreferences.currency)}
            </div>
          </div>

          <div
            className={`p-3 rounded-2xl border-2 ${
              budgetStatus.isOverBudget
                ? 'bg-[var(--danger-soft)] border-[var(--danger-line)] text-[var(--danger-ink)]'
                : 'bg-[var(--brand-soft)] border-[var(--brand-line)] text-[var(--brand-ink)]'
            }`}
          >
            <span className="text-[11px] font-extrabold block opacity-80">
              {budgetStatus.isOverBudget ? (isAr ? 'تجاوزت بـ' : 'Over by') : isAr ? 'المتبقي' : 'Remaining'}
            </span>
            <div className="text-xl sm:text-2xl font-black mt-1">
              {Math.abs(budgetStatus.remaining)} {currencySymbol(userPreferences.currency)}
            </div>
          </div>
        </div>

        <div className="space-y-1.5">
          <div className="flex justify-between text-xs font-extrabold text-[var(--muted)]">
            <span>
              {isAr ? 'نسبة الاستهلاك:' : 'Spent:'} {budgetStatus.percentSpent}%
            </span>
            <span>
              {targetBudget} {currencySymbol(userPreferences.currency)}
            </span>
          </div>
          <div className="w-full bg-[var(--surface-2)] rounded-full h-3.5 overflow-hidden border-2 border-[var(--line-strong)]">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                budgetStatus.isOverBudget
                  ? 'bg-[var(--danger-ink)]'
                  : budgetStatus.percentSpent >= 80
                  ? 'bg-[var(--warn-line)]'
                  : 'bg-[var(--brand)]'
              }`}
              style={{ width: `${Math.min(100, budgetStatus.percentSpent)}%` }}
            />
          </div>
        </div>

        {/* ✅ تحليلات ذكية جديدة: المسموح اليومي + توقع نهاية الفترة */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <div className="p-3 rounded-2xl border-2 border-[var(--brand-line)] bg-[var(--brand-soft)] flex items-start gap-2.5">
            <Gauge className="w-5 h-5 text-[var(--brand-ink)] flex-shrink-0 mt-0.5" />
            <div className="text-xs leading-relaxed">
              <div className="font-black text-[var(--brand-ink)]">
                {isAr ? 'المسموح لك اليوم تقريباً' : 'Safe daily allowance'}
              </div>
              <div className="text-[var(--muted)] font-bold mt-0.5">
                {budgetStatus.isOverBudget
                  ? isAr
                    ? 'تجاوزت حدود الفترة — خلينا نعتمد على المخزن النهاردة 😉'
                    : 'Over budget — lean on your pantry today 😉'
                  : `${safeDailyAllowance} ${currencySymbol(userPreferences.currency)} ${isAr ? 'لليوم/الباقي من الفترة' : '/ day left in period'}`}
              </div>
            </div>
          </div>

          <div className="p-3 rounded-2xl border-2 border-[var(--line)] bg-[var(--surface-2)] flex items-start gap-2.5">
            <TrendingUp className="w-5 h-5 text-[var(--muted)] flex-shrink-0 mt-0.5" />
            <div className="text-xs leading-relaxed">
              <div className="font-black text-[var(--ink)]">{isAr ? 'إيقاع صرفك' : 'Spending pace'}</div>
              <div className="text-[var(--muted)] font-bold mt-0.5">
                {isAr
                  ? `~${burnPerDay} ${currencySymbol(userPreferences.currency)} يومياً — توقع نهاية الفترة: ~${projectedTotal} ${currencySymbol(userPreferences.currency)}`
                  : `~${burnPerDay} ${currencySymbol(userPreferences.currency)}/day — projected: ~${projectedTotal} ${currencySymbol(userPreferences.currency)}`}
              </div>
            </div>
          </div>
        </div>

        <div className="p-3 rounded-xl border-2 border-[var(--line)] bg-[var(--surface)] text-xs text-[var(--muted)] flex items-center gap-2 font-bold">
          <Sparkles className="w-4 h-4 text-[var(--accent)] flex-shrink-0" />
          <span className="leading-relaxed">{budgetStatus.statusText}</span>
        </div>
      </div>

      {/* توزيع الأقسام */}
      <div className="rounded-3xl border-2 border-[var(--line-strong)] bg-[var(--surface)] p-5 space-y-3 shadow-[4px_4px_0_0_var(--shadow-card)]">
        <h3 className="text-xs font-black text-[var(--brand-ink)]">
          {isAr ? 'توزيع مصروفات هذه الفترة' : 'Spending by category (period)'}
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {Object.keys(categoryTotals).map((catKey) => {
            const catAmount = categoryTotals[catKey];
            const catPercent = totalActual > 0 ? Math.round((catAmount / totalActual) * 100) : 0;

            return (
              <div key={catKey} className="p-3 rounded-2xl border-2 border-[var(--line)] bg-[var(--surface-2)] space-y-1.5">
                <div className="flex items-center justify-between text-xs font-extrabold text-[var(--ink)]">
                  <span>{categoryLabels[catKey] ? (isAr ? categoryLabels[catKey].ar : categoryLabels[catKey].en) : catKey}</span>
                  <span className="text-[var(--brand-ink)]">
                    {catAmount} {currencySymbol(userPreferences.currency)}
                  </span>
                </div>
                <div className="w-full rounded-full h-2 overflow-hidden bg-[var(--surface)] border border-[var(--line)]">
                  <div className="h-full bg-[var(--accent)] rounded-full" style={{ width: `${catPercent}%` }} />
                </div>
                <div className="text-[10px] text-[var(--faint)] font-bold text-end">
                  {catPercent}% {isAr ? 'من الإجمالي' : 'of total'}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* سجل المصروفات */}
      <div className="space-y-3">
        <h3 className="text-xs font-black text-[var(--brand-ink)] px-1">
          {isAr ? 'سجل مصروفات الفترة المختارة' : 'Expenses in selected period'}
        </h3>

        {periodExpenses.length === 0 ? (
          <div className="rounded-3xl border-2 border-[var(--line-strong)] bg-[var(--surface)] p-8 text-center space-y-2 shadow-[4px_4px_0_0_var(--shadow-card)]">
            <Wallet className="w-10 h-10 text-[var(--faint)] mx-auto opacity-50" />
            <p className="text-sm font-extrabold text-[var(--ink)]">
              {isAr ? 'لا مصروفات مسجلة في هذه الفترة' : 'No expenses in this period'}
            </p>
            <p className="text-xs text-[var(--muted)] font-semibold">
              {isAr ? 'سجّل أول مصروف بزر «تسجيل مصروف» فوق ☝️' : 'Log your first expense above ☝️'}
            </p>
          </div>
        ) : (
          <div className="rounded-3xl border-2 border-[var(--line-strong)] bg-[var(--surface)] divide-y divide-[var(--line)] shadow-[4px_4px_0_0_var(--shadow-card)] overflow-hidden">
            {periodExpenses.map((exp) => (
              <div key={exp.id} className="p-4 flex items-center justify-between hover:bg-[var(--surface-2)] transition-colors">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-xs sm:text-sm text-[var(--ink)]">{exp.title}</span>
                    <span className="text-[9px] bg-[var(--surface-2)] text-[var(--muted)] border border-[var(--line)] px-1.5 py-0.5 rounded font-extrabold">
                      {isAr ? 'يدوي' : 'Manual'}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-[11px] text-[var(--faint)] font-bold">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      <span>{exp.date}</span>
                    </span>
                    {exp.storeName && (
                      <span className="flex items-center gap-1">
                        <Store className="w-3 h-3" />
                        {exp.storeName}
                      </span>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="text-sm sm:text-base font-black text-[var(--brand-ink)]">
                    {exp.amount} {currencySymbol(userPreferences.currency)}
                  </span>
                  <button
                    onClick={() => deleteExpense(exp.id)}
                    className="text-[var(--faint)] hover:text-[var(--danger-ink)] p-1 transition-colors"
                    aria-label={isAr ? 'حذف المصروف' : 'Delete expense'}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* مودال تسجيل مصروف */}
      {isLogModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="rounded-3xl max-w-md w-full p-5 space-y-4 border-2 border-[var(--line-strong)] bg-[var(--surface)] shadow-[6px_6px_0_0_var(--shadow-card)] animate-pop">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-black text-[var(--brand-ink)]">
                {isAr ? 'تسجيل مصروف جديد' : 'Log new expense'}
              </h3>
              <button
                onClick={() => setIsLogModalOpen(false)}
                className="w-7 h-7 rounded-lg bg-[var(--surface-2)] border-2 border-[var(--line-strong)] text-[var(--muted)] flex items-center justify-center font-bold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleLogSubmit} className="space-y-3">
              <div>
                <label className="text-xs font-extrabold text-[var(--muted)] block mb-1">
                  {isAr ? 'بيان المشتريات:' : 'Title:'}
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder={isAr ? 'مثال: خضار من عم صبحي، كرتونة بيض...' : 'e.g. Eggs and veggies'}
                  className="w-full text-xs sm:text-sm bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-xl px-3 py-2 text-[var(--ink)]"
                />
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label className="text-xs font-extrabold text-[var(--muted)] block mb-1">
                    {isAr ? 'المبلغ:' : 'Amount:'}
                  </label>
                  <input
                    type="number"
                    required
                    min="1"
                    value={amount}
                    onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
                    className="w-full text-xs sm:text-sm bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-xl px-3 py-2 text-[var(--ink)]"
                  />
                </div>
                <div>
                  <label className="text-xs font-extrabold text-[var(--muted)] block mb-1">
                    {isAr ? 'القسم:' : 'Category:'}
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full text-xs sm:text-sm bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-xl px-3 py-2 text-[var(--ink)]"
                  >
                    <option value="groceries">{isAr ? 'بقالة وسلع' : 'Groceries'}</option>
                    <option value="vegetables_fruits">{isAr ? 'خضار وفاكهة' : 'Produce'}</option>
                    <option value="butcher_poultry">{isAr ? 'لحوم ودواجن' : 'Meat'}</option>
                    <option value="bakery">{isAr ? 'مخبوزات' : 'Bakery'}</option>
                    <option value="quick_meal">{isAr ? 'وجبة سريعة' : 'Quick meal'}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-extrabold text-[var(--muted)] block mb-1">
                  {isAr ? 'اسم المتجر (اختياري):' : 'Store (optional):'}
                </label>
                <input
                  type="text"
                  value={storeName}
                  onChange={(e) => setStoreName(e.target.value)}
                  placeholder={isAr ? 'سوبرماركت البركة، سوق الخضار...' : 'Store name'}
                  className="w-full text-xs sm:text-sm bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-xl px-3 py-2 text-[var(--ink)]"
                />
              </div>

              <div className="pt-1 flex items-center gap-2">
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-xl bg-[var(--brand)] text-white text-xs font-extrabold border-2 border-[var(--line-strong)]"
                >
                  {isAr ? 'حفظ المصروف' : 'Save expense'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsLogModalOpen(false)}
                  className="py-2.5 px-4 rounded-xl border-2 border-[var(--line-strong)] bg-[var(--surface-2)] text-[var(--muted)] text-xs font-extrabold"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
