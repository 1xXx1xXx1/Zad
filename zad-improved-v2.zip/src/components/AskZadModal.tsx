/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import {
  Sparkles,
  Send,
  Camera,
  Flame,
  Clock,
  Coins,
  CheckCircle2,
  ShoppingBag,
  CookingPot,
} from 'lucide-react';
import { EquipmentMode } from '../types';
import { currencySymbol } from '../utils/rules';

interface ChatMessage {
  sender: 'user' | 'zad';
  text: string;
  provider?: string;
  model?: string;
  isCuratedFallback?: boolean;
  recipeCard?: {
    title?: string;
    timeMinutes?: number;
    costEstimate?: number;
    servings?: number;
    steps?: string[];
    missing?: string[];
    tips?: string;
  } | null;
}

export const AskZadModal: React.FC = () => {
  const {
    language,
    pantry,
    userPreferences,
    askZadAssistant,
    scanIngredientsPhoto,
    openCookMode,
    addShoppingItem,
  } = useApp();

  const isAr = language === 'ar';

  const [inputQuery, setInputQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [selectedPantryPills, setSelectedPantryPills] = useState<string[]>(() =>
    pantry.slice(0, 4).map((p) => p.name)
  );

  const [timeAvailable, setTimeAvailable] = useState<number>(15);
  const [equipmentChoice, setEquipmentChoice] = useState<EquipmentMode>(userPreferences.equipment);

  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      sender: 'zad',
      text: isAr
        ? 'أهلاً بك! أنا ذاد، رفيقك للطعام والتوفير. «الخير في اللي عندك» — اختر مكوناتك أو اكتب سؤالك، وهنطلع وجبة حلوة من المتاح.'
        : 'Welcome! I am ZAD. Pick ingredients below or just ask — we will make something good from what you have.',
    },
  ]);

  const [addedToListMessage, setAddedToListMessage] = useState<string | null>(null);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, [messages, isLoading]);

  const togglePill = (name: string) => {
    setSelectedPantryPills((prev) =>
      prev.includes(name) ? prev.filter((n) => n !== name) : [...prev, name]
    );
  };

  const handleSend = async (customPrompt?: string) => {
    const textToSend = customPrompt || inputQuery.trim();
    if (!textToSend && selectedPantryPills.length === 0) return;

    const fullPrompt = textToSend
      ? `${textToSend} (المكونات المتاحة: ${selectedPantryPills.join('، ') || 'لا شيء محدد'})`
      : `اقترح وجبة باستخدام: ${selectedPantryPills.join('، ')}. الوقت المتاح: ${timeAvailable} دقيقة.`;

    setMessages((prev) => [
      ...prev,
      { sender: 'user', text: textToSend || (isAr ? 'اقترح لي وجبة من المكونات المختارة' : 'Suggest a meal') },
    ]);
    setInputQuery('');
    setIsLoading(true);

    try {
      const res = await askZadAssistant(fullPrompt);

      let parsedRecipe: ChatMessage['recipeCard'] = null;
      try {
        const trimmed = res.reply.trim();
        if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
          parsedRecipe = JSON.parse(trimmed);
        }
      } catch {
        parsedRecipe = null;
      }

      setMessages((prev) => [
        ...prev,
        {
          sender: 'zad',
          text: parsedRecipe
            ? parsedRecipe.tips || (isAr ? 'إليك الوجبة المقترحة المناسبة لما تملكه:' : 'Here is your suggested meal:')
            : res.reply,
          provider: res.provider,
          model: res.model,
          isCuratedFallback: res.isCuratedFallback,
          recipeCard: parsedRecipe,
        },
      ]);
    } catch {
      setMessages((prev) => [
        ...prev,
        {
          sender: 'zad',
          text: isAr
            ? 'نعتذر عن انقطاع مؤقت. الخير في اللي عندك: جرب شكشوكة سريعة أو سلطة تونة بالزبادي وحدك هتكسب.'
            : 'Temporary connection issue. Try a quick shakshuka or a no-fire tuna bowl.',
          isCuratedFallback: true,
        },
      ]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleRescueMeal = (strategy: 'fastest' | 'cheapest' | 'best_use') => {
    const strategyText =
      strategy === 'fastest'
        ? 'الأسرع تحضيراً'
        : strategy === 'cheapest'
        ? 'الأوفر تكلفة'
        : 'الأفضل استغلالاً للمكونات المتوفرة';
    handleSend(`أنقذني بوجبة! المطلوب: ${strategyText}. الوقت المتاح: ${timeAvailable} دقيقة. المعدات: ${equipmentChoice}.`);
  };

  /* ✅ كاميرا حقيقية بدل المحاكاة */
  const fileInputRef = useRef<HTMLInputElement>(null);
  const handlePhotoSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsLoading(true);
    try {
      const base64 = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const result = String(reader.result || '');
          resolve(result.includes(',') ? result.split(',')[1] : result);
        };
        reader.onerror = () => reject(new Error('read-error'));
        reader.readAsDataURL(file);
      });

      const res = await scanIngredientsPhoto(base64, file.type || 'image/jpeg');
      if (res.ingredients.length > 0) {
        setSelectedPantryPills((prev) => Array.from(new Set([...prev, ...res.ingredients])));
        setMessages((prev) => [
          ...prev,
          {
            sender: 'zad',
            text: isAr
              ? `اتعرفت على المكونات دي من الصورة (${res.source}): ${res.ingredients.join('، ')}. ${res.notes}`
              : `Detected via ${res.source}: ${res.ingredients.join(', ')}.`,
          },
        ]);
      } else {
        setMessages((prev) => [
          ...prev,
          {
            sender: 'zad',
            text: isAr
              ? 'ماقدرتش أحدد مكونات واضحة من الصورة. جرب إضاءة أحسن أو اكتب المكونات بنفسك.'
              : 'Could not detect clear ingredients. Try better lighting or type them.',
          },
        ]);
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        { sender: 'zad', text: isAr ? 'تعذر تحليل الصورة الآن — جرب تاني.' : 'Photo analysis failed — try again.' },
      ]);
    } finally {
      setIsLoading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-4 pb-28 pt-1 animate-fade-in">
      {/* الهيدر */}
      <div
        className="rounded-3xl border-2 border-[var(--line-strong)] text-white p-4 sm:p-5 relative overflow-hidden"
        style={{
          background: 'linear-gradient(135deg, var(--brand-deep) 0%, var(--brand) 100%)',
          boxShadow: '5px 5px 0 0 var(--shadow-card)',
        }}
      >
        <div
          className="absolute inset-0 opacity-15 pointer-events-none"
          style={{ backgroundImage: 'radial-gradient(rgba(255,255,255,0.6) 1px, transparent 1px)', backgroundSize: '16px 16px' }}
        />
        <div className="relative z-10 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-white/15 border-2 border-white/30 flex items-center justify-center font-bold">
              <Sparkles className="w-5 h-5 text-[var(--accent)]" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black">{isAr ? 'اسأل ذاد' : 'Ask ZAD'}</h2>
              <p className="text-[11px] text-white/80 font-semibold">
                {isAr ? '«الخير في اللي عندك» — نسأل عن المتاح لنصنع الأفضل' : 'Crafting good food from what you have'}
              </p>
            </div>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            className="hidden"
            onChange={handlePhotoSelected}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={isLoading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[var(--accent)] border-2 border-white/30 text-white text-xs font-extrabold disabled:opacity-60"
            title={isAr ? 'التقاط صورة للثلاجة' : 'Scan ingredients photo'}
          >
            <Camera className="w-3.5 h-3.5" />
            <span>{isAr ? 'صوّر المتاح' : 'Scan'}</span>
          </button>
        </div>
      </div>

      {/* مسار الأنقذني بوجبة */}
      <div className="rounded-3xl border-2 border-[var(--line-strong)] bg-[var(--surface)] p-4 space-y-3.5 shadow-[4px_4px_0_0_var(--shadow-card)]">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-black text-[var(--brand-ink)] flex items-center gap-1.5">
            <Flame className="w-4 h-4 text-[var(--accent)]" />
            <span>{isAr ? 'مسار «أنقذني بوجبة»' : 'Rescue me a meal'}</span>
          </h3>
          <span className="text-[10px] text-[var(--faint)] font-bold">
            {isAr ? 'حدد المتاح والباقي علينا' : 'Select what you have'}
          </span>
        </div>

        <div>
          <label className="text-[11px] font-extrabold text-[var(--muted)] block mb-1.5">
            {isAr ? 'المكونات المتاحة (اضغط للاختيار):' : 'Available ingredients:'}
          </label>
          <div className="flex flex-wrap gap-1.5 max-h-28 overflow-y-auto">
            {pantry.map((item) => {
              const isSelected = selectedPantryPills.includes(item.name);
              return (
                <button
                  key={item.id}
                  onClick={() => togglePill(item.name)}
                  className={`text-xs px-2.5 py-1 rounded-lg border-2 font-bold transition-all ${
                    isSelected
                      ? 'bg-[var(--brand)] text-white border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)]'
                      : 'bg-[var(--surface-2)] text-[var(--ink)] border-[var(--line)] hover:border-[var(--line-strong)]'
                  }`}
                >
                  {isSelected ? '✓ ' : '+ '}
                  {item.name}
                </button>
              );
            })}
            {pantry.length === 0 && (
              <span className="text-[11px] text-[var(--faint)] font-bold">
                {isAr ? 'المخزن فاضي — أضف مكونات أولاً من تبويب المخزن.' : 'Pantry is empty — add items first.'}
              </span>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <div>
            <label className="text-[11px] font-extrabold text-[var(--muted)] block mb-1">
              {isAr ? 'معدات الطهي المتوفرة:' : 'Cooking equipment:'}
            </label>
            <select
              value={equipmentChoice}
              onChange={(e) => setEquipmentChoice(e.target.value as EquipmentMode)}
              className="w-full text-xs bg-[var(--surface-2)] border-2 border-[var(--line)] rounded-xl px-3 py-2 text-[var(--ink)] font-bold"
            >
              <option value="limited_equipment">{isAr ? 'مقلاة أو حلة واحدة' : 'One pot/pan only'}</option>
              <option value="no_fire">{isAr ? 'بدون نار نهائياً' : 'No fire / No cook'}</option>
              <option value="no_kitchen">{isAr ? 'غلاية / ميكروويف فقط' : 'Kettle / Microwave'}</option>
              <option value="full_kitchen">{isAr ? 'مطبخ كامل' : 'Full kitchen'}</option>
            </select>
          </div>

          <div>
            <label className="text-[11px] font-extrabold text-[var(--muted)] block mb-1">
              {isAr ? 'الوقت الأقصى المتاح:' : 'Time available:'}
            </label>
            <div className="flex gap-1.5">
              {[10, 15, 25, 40].map((mins) => (
                <button
                  key={mins}
                  onClick={() => setTimeAvailable(mins)}
                  className={`flex-1 py-1.5 rounded-lg text-xs font-extrabold border-2 transition-all ${
                    timeAvailable === mins
                      ? 'bg-[var(--accent)] text-white border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)]'
                      : 'bg-[var(--surface-2)] text-[var(--muted)] border-[var(--line)]'
                  }`}
                >
                  {mins} {isAr ? 'د' : 'm'}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="pt-2 border-t-2 border-[var(--line)] grid grid-cols-1 sm:grid-cols-3 gap-2">
          <button
            onClick={() => handleRescueMeal('fastest')}
            disabled={isLoading}
            className="py-2 px-3 rounded-xl bg-[var(--surface-2)] border-2 border-[var(--line-strong)] text-xs font-extrabold text-[var(--ink)] flex items-center justify-center gap-1.5 hover:-translate-y-0.5 transition-transform disabled:opacity-50"
          >
            <Clock className="w-3.5 h-3.5 text-[var(--accent)]" />
            <span>{isAr ? '⚡ الأسرع' : 'Fastest'}</span>
          </button>
          <button
            onClick={() => handleRescueMeal('cheapest')}
            disabled={isLoading}
            className="py-2 px-3 rounded-xl bg-[var(--surface-2)] border-2 border-[var(--line-strong)] text-xs font-extrabold text-[var(--ink)] flex items-center justify-center gap-1.5 hover:-translate-y-0.5 transition-transform disabled:opacity-50"
          >
            <Coins className="w-3.5 h-3.5 text-[var(--brand-ink)]" />
            <span>{isAr ? '💰 الأوفر' : 'Cheapest'}</span>
          </button>
          <button
            onClick={() => handleRescueMeal('best_use')}
            disabled={isLoading}
            className="py-2 px-3 rounded-xl bg-[var(--brand)] text-white border-2 border-[var(--line-strong)] text-xs font-extrabold flex items-center justify-center gap-1.5 shadow-[2px_2px_0_0_var(--shadow-card)] hover:-translate-y-0.5 transition-transform disabled:opacity-50"
          >
            <Sparkles className="w-3.5 h-3.5 text-[var(--accent)]" />
            <span>{isAr ? '🌟 أفضل استغلال' : 'Best use'}</span>
          </button>
        </div>
      </div>

      {/* سجل المحادثة */}
      <div className="space-y-3 pt-1">
        {messages.map((msg, index) => (
          <div key={index} className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'} animate-fade-in`}>
            <div
              className={`max-w-[92%] sm:max-w-[85%] rounded-2xl p-3.5 space-y-2.5 border-2 ${
                msg.sender === 'user'
                  ? 'bg-[var(--brand)] text-white border-[var(--line-strong)] shadow-[3px_3px_0_0_var(--shadow-card)]'
                  : 'bg-[var(--surface)] text-[var(--ink)] border-[var(--line-strong)] shadow-[3px_3px_0_0_var(--shadow-card)]'
              }`}
            >
              <div className="flex items-center justify-between gap-2 border-b-2 border-black/5 pb-1">
                <span className="text-[11px] font-black opacity-80">
                  {msg.sender === 'user' ? (isAr ? 'أنت' : 'You') : isAr ? 'ذاد' : 'ZAD'}
                </span>
                {msg.sender === 'zad' && msg.provider && (
                  <span
                    className={`text-[9px] px-2 py-0.5 rounded-full font-extrabold ${
                      msg.isCuratedFallback
                        ? 'bg-[var(--warn-soft)] text-[var(--warn-ink)] border border-[var(--warn-line)]'
                        : 'bg-[var(--brand-soft)] text-[var(--brand-ink)] border border-[var(--brand-line)]'
                    }`}
                  >
                    {msg.isCuratedFallback
                      ? isAr ? 'قاعدة معرفة ذاد' : 'ZAD knowledge'
                      : `${msg.model || 'AI'}`}
                  </span>
                )}
              </div>

              <p className="text-xs sm:text-sm leading-relaxed whitespace-pre-line font-medium">{msg.text}</p>

              {msg.recipeCard && (
                <div className="bg-[var(--surface-2)] p-3.5 rounded-xl border-2 border-[var(--line)] space-y-2.5 mt-1">
                  <div className="flex items-start justify-between gap-2">
                    <h4 className="font-black text-sm text-[var(--brand-ink)]">{msg.recipeCard.title}</h4>
                  </div>
                  <div className="flex items-center gap-3 text-[11px] text-[var(--muted)] font-bold">
                    {msg.recipeCard.timeMinutes && (
                      <span className="flex items-center gap-1">
                        <Clock className="w-3 h-3" /> {msg.recipeCard.timeMinutes} {isAr ? 'دقيقة' : 'min'}
                      </span>
                    )}
                    {msg.recipeCard.costEstimate !== undefined && (
                      <span>~{msg.recipeCard.costEstimate} {currencySymbol(userPreferences.currency)}</span>
                    )}
                    {msg.recipeCard.servings && (
                      <span>🍽️ {msg.recipeCard.servings} {isAr ? 'حصص' : 'servings'}</span>
                    )}
                  </div>

                  {msg.recipeCard.steps && msg.recipeCard.steps.length > 0 && (
                    <div className="space-y-1.5 text-xs text-[var(--ink)]">
                      <div className="font-black text-[11px] text-[var(--muted)]">
                        {isAr ? 'خطوات التحضير:' : 'Instructions:'}
                      </div>
                      <ol className="list-decimal list-inside space-y-1">
                        {msg.recipeCard.steps.map((st, idx) => (
                          <li key={idx} className="leading-snug">{st}</li>
                        ))}
                      </ol>
                    </div>
                  )}

                  {/* أزرار العمل على بطاقة الوصفة */}
                  <div className="flex flex-wrap items-center gap-1.5 pt-1">
                    {msg.recipeCard.steps && msg.recipeCard.steps.length > 0 && (
                      <button
                        onClick={() =>
                          openCookMode({
                            id: `ai-recipe-${Date.now()}`,
                            title: msg.recipeCard?.title || (isAr ? 'وجبة مقترحة' : 'Suggested meal'),
                            titleEn: msg.recipeCard?.title || 'Suggested meal',
                            description: msg.recipeCard?.tips || '',
                            category: 'lunch',
                            prepTimeMinutes: msg.recipeCard?.timeMinutes || 15,
                            cookTimeMinutes: 0,
                            servings: msg.recipeCard?.servings || 1,
                            estimatedCost: msg.recipeCard?.costEstimate || 0,
                            costBasis: 'تقدير ذاد الذكي',
                            equipment: [],
                            equipmentMode: 'limited_equipment',
                            ingredients: [],
                            steps: (msg.recipeCard?.steps || []).map((s) => ({ instruction: s })),
                            tags: ['ذكاء اصطناعي'],
                            imageUrl: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=600&auto=format&fit=crop&q=80',
                            verifiedTag: 'estimated',
                          } as any)
                        }
                        className="flex items-center gap-1 text-[11px] font-extrabold px-2.5 py-1.5 rounded-lg bg-[var(--accent)] text-white border-2 border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)]"
                      >
                        <CookingPot className="w-3.5 h-3.5" />
                        {isAr ? 'وضع الطاهي' : 'Cook mode'}
                      </button>
                    )}
                    {msg.recipeCard.missing && msg.recipeCard.missing.length > 0 && (
                      <button
                        onClick={() => {
                          msg.recipeCard?.missing?.forEach((m: string) => {
                            addShoppingItem({
                              name: m,
                              quantity: 1,
                              unit: 'حبة',
                              category: 'مكونات مقترحة',
                              notes: isAr ? 'أضيفت من اقتراح ذاد' : 'From ZAD suggestion',
                            });
                          });
                          setAddedToListMessage(isAr ? 'تمت إضافة النواقص لقائمة التسوق!' : 'Added missing items to shopping list!');
                          setTimeout(() => setAddedToListMessage(null), 3000);
                        }}
                        className="flex items-center gap-1 text-[11px] font-extrabold px-2.5 py-1.5 rounded-lg bg-[var(--surface)] border-2 border-[var(--line-strong)] text-[var(--ink)]"
                      >
                        <ShoppingBag className="w-3.5 h-3.5 text-[var(--brand-ink)]" />
                        {isAr ? `أضف النواقص (${msg.recipeCard.missing.length})` : `Add missing (${msg.recipeCard.missing.length})`}
                      </button>
                    )}
                  </div>

                  {msg.recipeCard.missing && msg.recipeCard.missing.length > 0 && (
                    <div className="text-[11px] bg-[var(--warn-soft)] text-[var(--warn-ink)] p-2 rounded-lg border border-[var(--warn-line)] font-bold">
                      {isAr
                        ? `نواقص خفيفة: ${msg.recipeCard.missing.join('، ')}`
                        : `Missing: ${msg.recipeCard.missing.join(', ')}`}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex items-center gap-2 p-3 bg-[var(--surface)] rounded-2xl border-2 border-[var(--line-strong)] w-fit shadow-[3px_3px_0_0_var(--shadow-card)]">
            <Sparkles className="w-4 h-4 text-[var(--accent)] animate-spin" />
            <span className="text-xs text-[var(--muted)] font-extrabold">
              {isAr ? 'ذاد يفكر في أنسب وجبة من المتاح...' : 'ZAD is finding the best meal...'}
            </span>
          </div>
        )}

        {addedToListMessage && (
          <div className="p-2 bg-[var(--brand-soft)] text-[var(--brand-ink)] border-2 border-[var(--brand-line)] rounded-xl text-xs font-extrabold text-center flex items-center justify-center gap-1.5">
            <CheckCircle2 className="w-4 h-4" />
            {addedToListMessage}
          </div>
        )}
        <div ref={chatEndRef} />
      </div>

      {/* شريط الإدخال */}
      <div className="sticky bottom-20 bg-transparent pt-1">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="flex items-center gap-2 bg-[var(--surface)] p-1.5 rounded-2xl border-2 border-[var(--line-strong)] shadow-[4px_4px_0_0_var(--shadow-card)]"
        >
          <input
            type="text"
            value={inputQuery}
            onChange={(e) => setInputQuery(e.target.value)}
            placeholder={
              isAr
                ? 'اسأل ذاد: «هآكل إيه النهاردة؟» أو «عشاء بـ 20 جنيه»...'
                : 'Ask ZAD: "What can I eat tonight?"...'
            }
            className="flex-1 bg-transparent px-3 text-xs sm:text-sm text-[var(--ink)] placeholder-[var(--faint)] font-medium"
          />
          <button
            type="submit"
            disabled={isLoading || (!inputQuery.trim() && selectedPantryPills.length === 0)}
            className="w-9 h-9 rounded-xl bg-[var(--accent)] disabled:opacity-40 text-white flex items-center justify-center flex-shrink-0 border-2 border-[var(--line-strong)] shadow-[2px_2px_0_0_var(--shadow-card)]"
            aria-label={isAr ? 'إرسال' : 'Send'}
          >
            <Send className={`w-4 h-4 ${isAr ? 'rotate-180' : ''}`} />
          </button>
        </form>
      </div>
    </div>
  );
};
