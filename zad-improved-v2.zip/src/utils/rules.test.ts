/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateBudgetStatus,
  calculateUnitPrice,
  checkPantryExpiry,
  computeMissingIngredients,
  normalizeIngredient,
} from './rules.ts';

test('calculateBudgetStatus computes accurate remaining and percentage', () => {
  const result = calculateBudgetStatus(1000, 450);
  assert.equal(result.planned, 1000);
  assert.equal(result.actual, 450);
  assert.equal(result.remaining, 550);
  assert.equal(result.percentSpent, 45);
  assert.equal(result.isOverBudget, false);
});

test('calculateBudgetStatus handles overbudget with compassionate text', () => {
  const result = calculateBudgetStatus(500, 620);
  assert.equal(result.remaining, -120);
  assert.equal(result.isOverBudget, true);
  assert.match(result.statusText, /تجاوزت الميزانية/);
});

test('calculateUnitPrice converts grams to per-kg price', () => {
  // 500g for 30 EGP -> 60 EGP per kg
  const unitKg = calculateUnitPrice(30, 500, 'جرام');
  assert.equal(unitKg.normalizedPrice, 60);
  assert.equal(unitKg.standardUnit, 'kg');
});

test('calculateUnitPrice converts ml to per-L price', () => {
  // 250ml for 15 EGP -> 60 EGP per L
  const unitL = calculateUnitPrice(15, 250, 'ml');
  assert.equal(unitL.normalizedPrice, 60);
  assert.equal(unitL.standardUnit, 'L');
});

test('checkPantryExpiry accurately identifies expired, expiring soon, and fresh', () => {
  const today = '2026-11-02';
  assert.equal(checkPantryExpiry('2026-11-01', today).status, 'expired');
  assert.equal(checkPantryExpiry('2026-11-03', today).status, 'expiring_soon');
  assert.equal(checkPantryExpiry('2026-11-04', today).status, 'expiring_soon');
  assert.equal(checkPantryExpiry('2026-11-15', today).status, 'fresh');
});

test('computeMissingIngredients matches ingredients accurately against pantry', () => {
  const recipe = ['بيض', 'طماطم طازجة', 'زيت زيتون', 'جبنة فيتا'];
  const pantry = ['بيض بلدي', 'زيت زيتون بكر', 'خيار'];
  
  const result = computeMissingIngredients(recipe, pantry);
  assert.equal(result.available.length, 2); // بيض, زيت زيتون
  assert.equal(result.missing.length, 2); // طماطم, جبنة
  assert.equal(result.matchPercent, 50);
});
