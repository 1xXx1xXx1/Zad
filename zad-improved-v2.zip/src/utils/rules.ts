/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface PantryItem {
  id: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  expiryDate: string; // ISO date YYYY-MM-DD
  storageLocation: 'fridge' | 'pantry' | 'freezer';
  photoUrl?: string;
  purchasePrice?: number;
}

export interface BudgetStatus {
  planned: number;
  actual: number;
  remaining: number;
  percentSpent: number;
  isOverBudget: boolean;
  statusText: string;
}

/**
 * Calculates budget planned vs actual spending and health status.
 */
export function calculateBudgetStatus(planned: number, actual: number): BudgetStatus {
  const safePlanned = Math.max(0, planned);
  const safeActual = Math.max(0, actual);
  const remaining = safePlanned - safeActual;
  const percentSpent = safePlanned > 0 ? Math.round((safeActual / safePlanned) * 100) : 0;
  const isOverBudget = remaining < 0;

  let statusText = 'ميزانيتك متوازنة وبخير';
  if (isOverBudget) {
    statusText = 'تجاوزت الميزانية المحددة، خلّينا نركز على المتاح في المخزن';
  } else if (percentSpent >= 80) {
    statusText = 'اقتربت من حد الميزانية، اقتراحات التوفير جاهزة لمساعدتك';
  } else if (percentSpent >= 50) {
    statusText = 'أداؤك ممتاز ومصروفك محسوب بدقة';
  }

  return {
    planned: safePlanned,
    actual: safeActual,
    remaining,
    percentSpent,
    isOverBudget,
    statusText,
  };
}

/**
 * Normalizes quantity and price to price per standard unit (kg, L, or piece).
 */
export function calculateUnitPrice(
  price: number,
  quantity: number,
  unit: string
): { normalizedPrice: number; standardUnit: string } {
  if (price <= 0 || quantity <= 0) {
    return { normalizedPrice: 0, standardUnit: unit };
  }

  const u = unit.toLowerCase().trim();
  if (u === 'g' || u === 'جرام' || u === 'غرام') {
    // Convert to per kg
    return { normalizedPrice: (price / quantity) * 1000, standardUnit: 'kg' };
  }
  if (u === 'kg' || u === 'كجم' || u === 'كيلو') {
    return { normalizedPrice: price / quantity, standardUnit: 'kg' };
  }
  if (u === 'ml' || u === 'مل' || u === 'مليلتر') {
    // Convert to per L
    return { normalizedPrice: (price / quantity) * 1000, standardUnit: 'L' };
  }
  if (u === 'l' || u === 'لتر') {
    return { normalizedPrice: price / quantity, standardUnit: 'L' };
  }

  return { normalizedPrice: price / quantity, standardUnit: unit };
}

/**
 * Classifies pantry item shelf life.
 */
export type ExpiryStatus = 'expired' | 'expiring_soon' | 'fresh';

export function checkPantryExpiry(expiryDateStr: string, referenceDateStr?: string): {
  status: ExpiryStatus;
  daysRemaining: number;
} {
  const refDate = referenceDateStr ? new Date(referenceDateStr) : new Date();
  refDate.setHours(0, 0, 0, 0);

  const expDate = new Date(expiryDateStr);
  expDate.setHours(0, 0, 0, 0);

  const diffTime = expDate.getTime() - refDate.getTime();
  const daysRemaining = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (daysRemaining < 0) {
    return { status: 'expired', daysRemaining };
  }
  if (daysRemaining <= 2) {
    return { status: 'expiring_soon', daysRemaining };
  }
  return { status: 'fresh', daysRemaining };
}

/**
 * Normalizes ingredient names for fuzzy comparison.
 */
export function normalizeIngredient(name: string): string {
  return name
    .toLowerCase()
    .trim()
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/[^\w\s\u0600-\u06FF]/gi, '');
}

/**
 * Computes missing ingredients for a recipe given the user's pantry.
 */
export function computeMissingIngredients(
  recipeIngredients: string[],
  pantryItems: string[]
): { available: string[]; missing: string[]; matchPercent: number } {
  if (!recipeIngredients.length) {
    return { available: [], missing: [], matchPercent: 100 };
  }

  const normalizedPantry = pantryItems.map(normalizeIngredient);

  const available: string[] = [];
  const missing: string[] = [];

  for (const rawIng of recipeIngredients) {
    const norm = normalizeIngredient(rawIng);
    const hasMatch = normalizedPantry.some(
      (p) => p.includes(norm) || norm.includes(p) || p === norm
    );
    if (hasMatch) {
      available.push(rawIng);
    } else {
      missing.push(rawIng);
    }
  }

  const matchPercent = Math.round((available.length / recipeIngredients.length) * 100);

  return { available, missing, matchPercent };
}

/**
 * ✅ جديد: رمز عملة موحّد — كانت بعض الشاشات تعرض "ج.م" ثابتة حتى مع تغيير العملة.
 */
export function currencySymbol(code: string): string {
  switch (code) {
    case 'EGP': return 'ج.م';
    case 'SAR': return 'ر.س';
    case 'AED': return 'د.إ';
    case 'USD': return '$';
    default: return code;
  }
}

/**
 * ✅ جديد: معدلات تحويل استرشادية تقريبية لعرض التكاليف بالعملة المختارة.
 * (التكاليف الأساسية مبنية بالجنيه المصري كعملة مرجعية)
 */
export const EGP_REFERENCE_RATES: Record<string, number> = {
  EGP: 1,
  SAR: 1 / 12.5,
  AED: 1 / 12.8,
  USD: 1 / 48,
};

export function convertFromEGP(amountEgp: number, currency: string): number {
  const rate = EGP_REFERENCE_RATES[currency] ?? 1;
  return Math.round(amountEgp * rate * 10) / 10;
}
