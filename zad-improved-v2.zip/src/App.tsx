/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Navigation } from './components/Navigation';
import { HomeScreen } from './components/HomeScreen';
import { RecipeLibrary } from './components/RecipeLibrary';
import { AskZadModal } from './components/AskZadModal';
import { ShoppingView } from './components/ShoppingView';
import { BudgetView } from './components/BudgetView';
import { PantryView } from './components/PantryView';
import { CookModeModal } from './components/CookModeModal';
import { StoreMapModal } from './components/StoreMapModal';
import { AISettingsModal } from './components/AISettingsModal';
import { DocumentationModal } from './components/DocumentationModal';

const AppContent: React.FC = () => {
  const { activeTab } = useApp();

  return (
    <div className="min-h-screen bg-[var(--bg)] text-[var(--ink)] flex flex-col font-sans">
      <Header />

      <main key={activeTab} className="flex-1 max-w-5xl w-full mx-auto px-3.5 sm:px-6 pt-1 pb-24">
        {activeTab === 'home' && <HomeScreen />}
        {activeTab === 'recipes' && <RecipeLibrary />}
        {activeTab === 'ask_zad' && <AskZadModal />}
        {activeTab === 'shopping' && <ShoppingView />}
        {activeTab === 'budget' && <BudgetView />}
        {activeTab === 'pantry' && <PantryView />}
      </main>

      {/* Global Modals */}
      <CookModeModal />
      <StoreMapModal />
      <AISettingsModal />
      <DocumentationModal />

      <Navigation />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
