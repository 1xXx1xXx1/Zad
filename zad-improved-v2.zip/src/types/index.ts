/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type EquipmentMode = 'full_kitchen' | 'limited_equipment' | 'no_fire' | 'no_kitchen';
export type HouseholdType = 'solo' | 'student_expat' | 'couple' | 'family';
export type VerificationTag = 'verified_live' | 'store_provided' | 'user_provided' | 'community' | 'recently_updated' | 'estimated' | 'demo' | 'open_recipe_api' | 'web_import';
export type MealType = 'breakfast' | 'lunch' | 'dinner' | 'snack' | 'drink' | 'dessert';

export interface Recipe {
  id: string;
  title: string;
  titleEn: string;
  description: string;
  category: MealType;
  prepTimeMinutes: number;
  cookTimeMinutes: number;
  servings: number;
  estimatedCost: number; // in active currency
  costBasis: string;
  equipment: string[];
  equipmentMode: EquipmentMode;
  ingredients: {
    name: string;
    quantity: number;
    unit: string;
    isOptional?: boolean;
    substitute?: string;
  }[];
  steps: {
    instruction: string;
    timerSeconds?: number;
    tip?: string;
  }[];
  nutrition?: {
    calories: number;
    proteinGrams: number;
    carbsGrams: number;
    fatGrams: number;
    source: string;
  };
  tags: string[];
  imageUrl: string;
  isFavorite?: boolean;
  userRating?: number; // 1-5
  verifiedTag: VerificationTag;
  sourceUrl?: string;
  youtubeUrl?: string;
  cuisine?: string;
  sourcePlatform?: string;
}

export interface PantryItemData {
  id: string;
  name: string;
  category: string;
  quantity: number;
  unit: string;
  purchaseDate: string;
  expiryDate: string;
  storageLocation: 'fridge' | 'pantry' | 'freezer';
  purchasePrice?: number;
  isExpiringSoon?: boolean;
  notes?: string;
}

export interface ShoppingItem {
  id: string;
  name: string;
  quantity: number;
  unit: string;
  category: string;
  checked: boolean;
  estimatedPrice?: number;
  notes?: string;
  recipeSource?: string;
}

export interface ExpenseRecord {
  id: string;
  title: string;
  amount: number;
  date: string;
  category: 'groceries' | 'vegetables_fruits' | 'butcher_poultry' | 'bakery' | 'quick_meal';
  storeName?: string;
  notes?: string;
  verifiedTag: VerificationTag;
}

export interface StoreProduct {
  id: string;
  name: string;
  price: number;
  unit: string;
  packageSize: number;
  brand?: string;
  isOffer?: boolean;
  discountPrice?: number;
  verifiedTag: VerificationTag;
  lastUpdated: string;
}

export interface StoreLocation {
  id: string;
  name: string;
  nameEn: string;
  type: 'supermarket' | 'greengrocer' | 'butcher' | 'bakery' | 'wholesale';
  lat: number;
  lng: number;
  distanceKm: number;
  address: string;
  openingHours: string;
  phone: string;
  hasDelivery: boolean;
  products: StoreProduct[];
  basketCostEstimate?: number;
  verifiedTag: VerificationTag;
}

export interface MealPlanDay {
  date: string;
  dayName: string;
  dayNameEn: string;
  breakfast?: Recipe;
  lunch?: Recipe;
  dinner?: Recipe;
  snack?: Recipe;
}

export interface UserPreferences {
  household: HouseholdType;
  equipment: EquipmentMode;
  dietaryRestrictions: string[];
  preferredCuisines: string[];
  maxPrepTime: number;
  currency: 'EGP' | 'SAR' | 'AED' | 'USD';
  budgetDaily: number;
  budgetWeekly: number;
  budgetMonthly: number;
}
